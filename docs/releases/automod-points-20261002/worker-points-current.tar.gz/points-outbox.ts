import { mkdir,readFile,writeFile,rename,readdir,appendFile } from "node:fs/promises";
import path from "node:path";
import type { SessionDataEvent } from "./session-data-journal.js";
export interface PointsTransport { shopRequest<T>(method:"GET"|"POST",path:string,body?:unknown):Promise<T>; }
export class PointsOutbox {
 private tail:Promise<unknown>=Promise.resolve();private pending=new Map<string,SessionDataEvent>();private acknowledged=new Set<string>();
 private since=Date.now();private flushing=false;private ready=false;
 constructor(private root:string,private transport:PointsTransport){}
 private eligible(e:SessionDataEvent){
  if(!e.item?.requestedByRumbleId||!/^[1-9][0-9]{0,19}$/.test(e.item.requestedByRumbleId)||Date.parse(e.recordedAt)<this.since)return false;
  if(['first-spin-settled','bonus-started','bonus-ended'].includes(e.kind))return true;
  return e.kind==='round'&&!e.data.bonusActive&&typeof e.data.gainCents==='number'&&typeof e.data.baseStakeCents==='number'&&e.data.gainCents>=100*e.data.baseStakeCents;
 }
 async initialize(){
  await mkdir(path.join(this.root,'points'),{recursive:true});
  const file=path.join(this.root,'points','state.json');
  const state=await readFile(file,'utf8').then(JSON.parse).catch(e=>{if(e.code==='ENOENT')return null;throw e;});
  if(state){this.since=state.since;this.acknowledged=new Set(state.acknowledged);}
  else await this.persist();
  // The session journal is authoritative: recover the append-to-outbox crash gap.
  for(const name of await readdir(path.join(this.root,'session-data')).catch(e=>{if(e.code==='ENOENT')return [];throw e;})){
   if(!name.endsWith('.jsonl'))continue;
   const text=await readFile(path.join(this.root,'session-data',name),'utf8');
   const lines=text.split(/\r?\n/);
   for(let index=0;index<lines.length;index++){
    const line=lines[index]!;if(!line)continue;
    let e:SessionDataEvent;
    try{e=JSON.parse(line) as SessionDataEvent;}
    catch(error){
     // A crash may leave an unfinished append. Preserve the file and recover its complete records.
     // Corruption of a newline-terminated record is not silently ignored.
     if(index===lines.length-1&&!text.endsWith('\n'))continue;
     throw error;
    }
    if(this.eligible(e)&&!this.acknowledged.has(e.id))this.pending.set(e.id,e);
   }
  }
  this.ready=true;
 }
 async record(e:SessionDataEvent){
  const operation=this.tail.then(async()=>{
   if(!this.ready)await this.initialize();
   if(!this.eligible(e)||this.acknowledged.has(e.id)||this.pending.has(e.id))return;
   await appendFile(path.join(this.root,'points','outbox.jsonl'),JSON.stringify(e)+'\n',{mode:0o600,flush:true});
   this.pending.set(e.id,e);
  });this.tail=operation.catch(()=>{});return operation;
 }
 private async persist(){
  const file=path.join(this.root,'points','state.json');
  await writeFile(file+'.tmp',JSON.stringify({since:this.since,acknowledged:[...this.acknowledged]}),{mode:0o600,flush:true});await rename(file+'.tmp',file);
 }
 async flush(){
  if(this.flushing)return;this.flushing=true;
  try{
   await this.tail;if(!this.ready)await this.initialize();
   const events=[...this.pending.values()].slice(0,50);
   if(events.length){const r=await this.transport.shopRequest<{accepted:string[]}>('POST','events',{events});
    for(const id of r.accepted){if(this.pending.has(id)){this.acknowledged.add(id);this.pending.delete(id);}}await this.persist();}
   return await this.transport.shopRequest<{rain:unknown}>('POST','tick',{});
  }finally{this.flushing=false;}
 }
}
