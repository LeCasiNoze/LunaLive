import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import path from "node:path";
import type { ProviderKey } from "./provider-capabilities.js";

export interface AutomodConfig {
  enabled: boolean;
  audioMode?: "spotify" | "game";
  lunaLiveApiBaseUrl: string;
  streamerSlug: string;
  allowedProviders: ProviderKey[];
  randomWhenQueueEmpty: boolean;
  queuePollMs: number;
  slotDurationMs: number;
  stakeCents: number;
  /** Paid boosts must select the available stake at or below the quote. */
  stakeAtOrBelow?: boolean;
  spinMode: "finite" | "infinite";
  maxSpinsPerSlot: number | null;
  stopAfterFirstBonus: boolean;
  bigWinThresholdMultiplier: number;
  enhancedSpins: {
    pragmatic: { enabled: boolean; maxMultiplier: number; maxTotalStakeCents: number };
    hacksaw: { enabled: boolean; maxMultiplier: number; maxTotalStakeCents: number };
    nolimit: { enabled: boolean; maxMultiplier: number; maxTotalStakeCents: number };
  };
  bonusHunt: {
    enabled: boolean;
    autoOpenWhenQueueEmpty: boolean;
  };
}

export const defaultAutomodConfig: AutomodConfig = {
  enabled: false,
  audioMode: "spotify",
  lunaLiveApiBaseUrl: "https://lunalive-api.onrender.com",
  streamerSlug: "LeCasiNoze",
  allowedProviders: ["pragmatic", "nolimit", "hacksaw"],
  randomWhenQueueEmpty: true,
  queuePollMs: 5_000,
  slotDurationMs: 7 * 60_000,
  stakeCents: 20,
  spinMode: "infinite",
  maxSpinsPerSlot: null,
  stopAfterFirstBonus: false,
  bigWinThresholdMultiplier: 500,
  enhancedSpins: {
    pragmatic: { enabled: true, maxMultiplier: 5, maxTotalStakeCents: 100 },
    hacksaw: { enabled: true, maxMultiplier: 5, maxTotalStakeCents: 100 },
    // Le plafond total est prioritaire par défaut : à 0,20 €, 0,50 € est
    // admissible mais 2,00 € ne l'est pas (comparaison stricte dans le driver).
    nolimit: { enabled: true, maxMultiplier: 5, maxTotalStakeCents: 100 },
  },
  bonusHunt: { enabled: false, autoOpenWhenQueueEmpty: false },
};

function integer(value: unknown, name: string, min: number, max: number): number {
  if (!Number.isSafeInteger(value) || (value as number) < min || (value as number) > max) {
    throw new Error(`${name} doit être un entier entre ${min} et ${max}.`);
  }
  return value as number;
}

function multiplier(value: unknown, name: string): number {
  if (typeof value !== "number" || !Number.isFinite(value) || value < 1 || value > 100) {
    throw new Error(`${name} doit être compris entre 1 et 100.`);
  }
  return value;
}

function bigWinMultiplier(value: unknown): number {
  if (typeof value !== "number" || !Number.isFinite(value) || value < 1 || value > 100_000) {
    throw new Error("bigWinThresholdMultiplier doit être compris entre 1 et 100000.");
  }
  return value;
}

export function validateAutomodConfig(input: unknown): AutomodConfig {
  if (typeof input !== "object" || input === null || Array.isArray(input)) throw new Error("Configuration Automod invalide.");
  const row = input as Record<string, unknown>;
  if (row.audioMode !== undefined && row.audioMode !== "spotify" && row.audioMode !== "game") throw Error("audioMode doit valoir spotify ou game.");
  const providers = row.allowedProviders;
  const allowed = new Set<ProviderKey>(["pragmatic", "hacksaw", "nolimit"]);
  if (!Array.isArray(providers) || providers.length === 0 || providers.some((value) => !allowed.has(value as ProviderKey))) {
    throw new Error("allowedProviders doit contenir uniquement Pragmatic, Hacksaw et/ou Nolimit.");
  }
  const url = new URL(String(row.lunaLiveApiBaseUrl ?? ""));
  if (url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname))) {
    throw new Error("L'API LunaLive doit être HTTPS, sauf en développement local.");
  }
  const enhanced = row.enhancedSpins as Record<string, unknown> | undefined;
  const policy = (provider: ProviderKey) => {
    const value = enhanced?.[provider] as Record<string, unknown> | undefined;
    return {
      enabled: value?.enabled === true,
      maxMultiplier: multiplier(value?.maxMultiplier, `enhancedSpins.${provider}.maxMultiplier`),
      maxTotalStakeCents: integer(value?.maxTotalStakeCents, `enhancedSpins.${provider}.maxTotalStakeCents`, 1, 100_000),
    };
  };
  if (row.spinMode !== "finite" && row.spinMode !== "infinite") {
    throw new Error("spinMode doit valoir finite ou infinite.");
  }
  const spinMode = row.spinMode;
  if (spinMode === "infinite" && row.maxSpinsPerSlot !== null) {
    throw new Error("maxSpinsPerSlot doit être null en mode infini.");
  }
  if (spinMode === "finite" && row.maxSpinsPerSlot === null) {
    throw new Error("maxSpinsPerSlot est requis en mode fini.");
  }
  const bonusHunt = row.bonusHunt as Record<string, unknown> | undefined;
  return {
    enabled: row.enabled === true,
    audioMode: row.audioMode === "game" ? "game" : "spotify",
    lunaLiveApiBaseUrl: url.toString().replace(/\/$/, ""),
    streamerSlug: String(row.streamerSlug ?? "").trim() || "LeCasiNoze",
    allowedProviders: [...new Set(providers as ProviderKey[])],
    randomWhenQueueEmpty: row.randomWhenQueueEmpty !== false,
    queuePollMs: integer(row.queuePollMs, "queuePollMs", 1_000, 60_000),
    slotDurationMs: integer(row.slotDurationMs, "slotDurationMs", 10_000, 24 * 60 * 60_000),
    stakeCents: integer(row.stakeCents, "stakeCents", 1, 100_000),
    spinMode,
    maxSpinsPerSlot: spinMode === "infinite" ? null : integer(row.maxSpinsPerSlot, "maxSpinsPerSlot", 1, 10_000),
    stopAfterFirstBonus: row.stopAfterFirstBonus === true,
    bigWinThresholdMultiplier: bigWinMultiplier(row.bigWinThresholdMultiplier),
    enhancedSpins: { pragmatic: policy("pragmatic"), hacksaw: policy("hacksaw"), nolimit: policy("nolimit") },
    bonusHunt: {
      enabled: bonusHunt?.enabled === true,
      autoOpenWhenQueueEmpty: bonusHunt?.autoOpenWhenQueueEmpty === true,
    },
  };
}

export class AutomodConfigStore {
  private readonly destination: string;
  private serial: Promise<unknown> = Promise.resolve();
  public constructor(runtimeDir: string) { this.destination = path.join(runtimeDir, "automod-config.json"); }

  public async load(): Promise<AutomodConfig> {
    try {
      const parsed = JSON.parse(await readFile(this.destination, "utf8")) as Record<string, unknown>;
      const migrated = {
        ...structuredClone(defaultAutomodConfig),
        ...parsed,
        allowedProviders: (() => {
          const configured = (Array.isArray(parsed.allowedProviders) ? parsed.allowedProviders : defaultAutomodConfig.allowedProviders)
            .filter((provider) => provider === "pragmatic" || provider === "nolimit" || provider === "hacksaw");
          return configured.length > 0 ? configured : defaultAutomodConfig.allowedProviders;
        })(),
        spinMode: parsed.spinMode ?? (parsed.maxSpinsPerSlot === null ? "infinite" : "finite"),
        enhancedSpins: { ...structuredClone(defaultAutomodConfig.enhancedSpins), ...(parsed.enhancedSpins as object | undefined) },
        bonusHunt: { ...defaultAutomodConfig.bonusHunt, ...(parsed.bonusHunt as object | undefined) },
      };
      return validateAutomodConfig(migrated);
    }
    catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return structuredClone(defaultAutomodConfig);
      throw error;
    }
  }

  public async save(config: AutomodConfig): Promise<void> {
    const operation = this.serial.then(async () => {
      const valid = validateAutomodConfig(config);
      await mkdir(path.dirname(this.destination), { recursive: true });
      const temporary = `${this.destination}.${process.pid}.${Date.now()}.tmp`;
      await writeFile(temporary, `${JSON.stringify(valid, null, 2)}\n`, "utf8");
      await rename(temporary, this.destination);
    });
    this.serial = operation.catch(() => undefined);
    await operation;
  }
}
