/** Read-only evidence for the native free-spins introduction, independent of OCR. */
export function pragmaticFreeSpinStartContext(runtime: any): { pending: boolean; windowVisible: boolean } {
  const absent = {pending:false,windowVisible:false};
  try {
    const scene = runtime.globalRuntime?.sceneRoots?.[1]?.transform;
    if (!scene || typeof runtime.UILabel !== 'function') return absent;
    const windows = new Set<any>();
    for (const label of scene.GetComponentsInChildren(runtime.UILabel,true)) {
      if (!(label.gameObject?.activeInHierarchy === true && label.enabled !== false) || !/^PRESS ANYWHERE TO CONTINUE$/i.test(String(label.text??'').trim())) continue;
      let transform = label.transform;
      for (let depth=0; transform && depth<12; depth++,transform=transform.parent) {
        if (/^(?:FSStart|FSStartWindow(?:_[A-Za-z0-9]+)?|FreeSpinsStartWindow|FreeSpinsWindowStart|FreeSpins)$/i.test(transform.gameObject?.name??'') && transform.gameObject?.activeInHierarchy===true) {
          windows.add(transform);
          break;
        }
      }
    }
    if (windows.size !== 1) return absent;
    const window = [...windows][0];
    const labels = window.GetComponentsInChildren(runtime.UILabel,true).filter((label:any)=>label.gameObject?.activeInHierarchy === true && label.enabled !== false).map((label:any)=>String(label.text??'').trim().toUpperCase());
    if (!labels.includes('YOU HAVE WON') || !labels.includes('FREE SPINS') || labels.some((text:string)=>/GAMBLE|BUY|PURCHASE/.test(text))) return absent;
    // IN + played count belongs to the final recap, not the introduction.
    if (labels.includes('IN') && labels.some((text:string)=>/^[1-9][0-9]*$/.test(text))) return absent;
    // An explicitly transparent panel is not a visible window.
    if ((window.GetComponentsInChildren(runtime.UIPanel,true)??[]).some((panel:any)=>typeof panel.alpha==='number'&&panel.alpha<=0.05)) return absent;
    const visible={pending:false,windowVisible:true};
    const event=runtime.Vars?.Evt_DataToCode_ConfirmFSStart;
    const callback=runtime.StageResultFreeSpin?.prototype?.OnConfirmFSStart;
    const left=runtime.XT?.GetInt?.(runtime.Vars?.FreeSpinsLeftDisplayed);
    if (typeof event!=='string'||typeof callback!=='function'||!Number.isSafeInteger(left)||left<=0) return visible;
    if (runtime.XT?.GetBool?.(runtime.Vars?.WaitInResultForBigWin)===true) return visible;
    const handlers=(runtime.XT?.variablesEvent?.[event]??[]).flatMap((record:any)=>Array.from(record.OnValueChanged??[]));
    const waiting=handlers.filter((handler:any)=>handler.callback===callback&&handler.isEnabled===true&&handler.object?.GetStageName?.()===runtime.UHTStageName?.ResultFreeSpin);
    return {pending:waiting.length===1,windowVisible:true};
  }catch{return absent;}
}
/** Final recap can remain visible after its provider stage was already collected. */
export function pragmaticFreeSpinRecapContext(runtime:any): {visible:boolean;played:number|null} {
 const absent={visible:false,played:null};
 try {
  const scene=runtime.globalRuntime?.sceneRoots?.[1]?.transform;
  if(!scene||typeof runtime.UILabel!=='function')return absent;
  const windows=new Set<any>();
  for(const label of scene.GetComponentsInChildren(runtime.UILabel,true)){
   if(label.gameObject?.activeInHierarchy!==true||label.enabled===false||!/^PRESS ANYWHERE TO CONTINUE$/i.test(String(label.text??'').trim()))continue;
   let transform=label.transform;
   for(let depth=0;transform&&depth<12;depth++,transform=transform.parent)if(/^(?:FreeSpins|FSWindow|FSResult|FSResultWindow(?:_[A-Za-z0-9]+)?|FreeSpinsResultWindow|FreeSpinsEndWindow|FSEndWindow)$/i.test(transform.gameObject?.name??'')&&transform.gameObject?.activeInHierarchy===true){windows.add(transform);break;}
  }
  if(windows.size!==1)return absent;
  const window=[...windows][0];
  const labels=window.GetComponentsInChildren(runtime.UILabel,true).filter((label:any)=>label.gameObject?.activeInHierarchy===true&&label.enabled!==false).map((label:any)=>String(label.text??'').trim().toUpperCase());
  const counts=labels.filter((text:string)=>/^[1-9][0-9]*$/.test(text));
  const classic=['FSResult','FSEndWindow'].includes(window.gameObject?.name)&&labels.some((text:string)=>/^CONGRATULATIONS!?$/.test(text));
  if(!labels.includes('YOU HAVE WON')||(!classic&&!labels.includes('IN'))||!labels.includes('FREE SPINS')||counts.length>1||(!classic&&counts.length!==1)||labels.some((text:string)=>/GAMBLE|BUY|PURCHASE/.test(text)))return absent;
  if((window.GetComponentsInChildren(runtime.UIPanel,true)??[]).some((panel:any)=>panel.gameObject?.activeInHierarchy!==false&&typeof panel.alpha==='number'&&panel.alpha<=0.05))return absent;
  return {visible:true,played:counts.length===1?Number(counts[0]):null};
 }catch{return absent;}
}

