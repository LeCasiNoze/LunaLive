import { appendFile, mkdir, readFile, writeFile, rename } from "node:fs/promises";
import path from "node:path";
import type { AutomodItem } from "./automod-domain.js";

export interface SessionDataEvent {
  schemaVersion: 1; id: string; sessionId: string; recordedAt: string; kind: string;
  visitId: string | null; item: AutomodItem | null; data: Record<string, unknown>;
}
/** Append-only facts. Null amounts are unknown, never losses. No retention pruning. */
export class SessionDataJournal {
  private tail: Promise<unknown> = Promise.resolve();
  private ids = new Map<string, Set<string>>();
  constructor(private readonly runtimeDir: string) {}
  record(event: SessionDataEvent): Promise<boolean> {
    if (!/^[a-zA-Z0-9-]{1,80}$/.test(event.sessionId) || !event.id) throw Error("Identité statistique invalide.");
    const pending = this.tail.then(async () => {
      const directory = path.join(this.runtimeDir, "session-data");
      const destination = path.join(directory, `${event.sessionId}.jsonl`);
      let ids = this.ids.get(event.sessionId);
      if (!ids) {
        const raw = await readFile(destination,"utf8").catch(error => { if ((error as NodeJS.ErrnoException).code === "ENOENT") return ""; throw error; });
        const lines=raw.split('\n'),loaded:string[]=[];
        for(let index=0;index<lines.length;index++){
          const line=lines[index]!;if(!line.trim())continue;
          try{loaded.push((JSON.parse(line) as SessionDataEvent).id);}
          catch(error){
            if(index!==lines.length-1||raw.endsWith('\n'))throw error;
            // Preserve the interrupted append for diagnosis before repairing the journal.
            await writeFile(`${destination}.interrupted-${Date.now()}`,raw,{encoding:'utf8',mode:0o600,flush:true,flag:'wx'});
            await writeFile(`${destination}.repair`,raw.slice(0,raw.lastIndexOf('\n')+1),{encoding:'utf8',mode:0o600,flush:true});
            await rename(`${destination}.repair`,destination);
          }
        }
        // A valid record missing only its newline must not be concatenated with the next append.
        if(raw&&!raw.endsWith('\n')){
          try{JSON.parse(lines.at(-1)!);await appendFile(destination,'\n',{encoding:'utf8',flush:true});}
          catch(error){if(!(error instanceof SyntaxError))throw error;}
        }
        ids = new Set(loaded);
        this.ids.set(event.sessionId,ids);
      }
      if (ids.has(event.id)) return false;
      await mkdir(directory,{recursive:true});
      await appendFile(destination,`${JSON.stringify(event)}\n`,{encoding:"utf8",mode:0o600,flush:true});
      ids.add(event.id);
      return true;
    });
    this.tail = pending.catch(() => undefined);
    return pending;
  }
}
