import type { ProviderKey } from "./provider-capabilities.js";

export type AutomodPhase =
  | "disabled"
  | "waiting"
  | "preparing"
  | "playing"
  | "waiting-bonus-end"
  | "completing"
  | "recovering"
  | "paused";

export type AutomodItemSource = "lunalive" | "random";

export interface AutomodItem {
  key: string;
  callId: string | null;
  source: AutomodItemSource;
  slotName: string;
  provider: ProviderKey;
  requestedBy: string | null;
  imageUrl?: string | null;
  requestedById?: number | null;
  requestedByRumbleId?: string | null;
  automodGenerated?: boolean;
}

export interface ActiveBonus {
  startedAt: number;
  endedAt: number | null;
  gainCents: number | null;
  abandoned?: boolean;
  purchaseOrderId?: string | null;
}

export interface AutomodRuntimeState {
  version: 1;
  phase: AutomodPhase;
  active: AutomodItem | null;
  slotStartedAt: number | null;
  slotDeadlineAt: number | null;
  recoveryPausedAt?: number | null;
  bonus: ActiveBonus | null;
  roundsPlayed: number;
  spinInFlight: boolean;
  /** Bonus retrouvé à l'ouverture : la rotation normale commence après sa collecte. */
  entryBonusPending?: boolean;
  /** Verified reference stake for statistics; never the enhanced debit. */
  verifiedBaseStakeCents?: number | null;
  verifiedChargedStakeCents?: number | null;
  visitId?: string | null;
  shopVisit?: import('./automod-shop.js').ShopVisit | null;
  lastCompletedKey: string | null;
  lastError: string | null;
  updatedAt: number;
}

export type AutomodEvent =
  | { type: "enable"; now: number }
  | { type: "disable"; now: number }
  | { type: "pause"; now: number }
  | { type: "resume"; now: number }
  | { type: "item-selected"; now: number; item: AutomodItem }
  | { type: "slot-ready"; now: number; durationMs: number; existingBonus?: boolean }
  | { type: "entry-bonus-finished"; now: number; durationMs: number }
  | { type: "first-spin-settled"; now: number; durationMs: number }
  | { type: "spin-intent"; now: number }
  | { type: "round-settled"; now: number; roundsPlayed: number }
  | { type: "restart-item"; now: number }
  | { type: "context-reopen"; now: number }
  | { type: "recovery-paused"; now: number }
  | { type: "recovery-resumed"; now: number }
  | { type: "tick"; now: number }
  | { type: "finish-item"; now: number }
  | { type: "bonus-started"; now: number; purchaseOrderId?:string|null }
  | { type: "bonus-ended"; now: number; gainCents: number }
  | { type: "bonus-abandoned"; now: number; reason?: string }
  | { type: "item-completed"; now: number }
  | { type: "discard-processed-item"; now: number }
  | { type: "skip-random-item"; now: number }
  | { type: "skip-failed-item"; now: number; message: string }
  | { type: "failure"; now: number; message: string }
  | { type: "retry"; now: number };

export function initialAutomodState(now = Date.now()): AutomodRuntimeState {
  return {
    version: 1,
    phase: "disabled",
    active: null,
    slotStartedAt: null,
    slotDeadlineAt: null,
        recoveryPausedAt: null,
    bonus: null,
    roundsPlayed: 0,
    spinInFlight: false,
    lastCompletedKey: null,
    lastError: null,
    updatedAt: now,
  };
}

function assertPhase(state: AutomodRuntimeState, event: AutomodEvent, allowed: AutomodPhase[]): void {
  if (!allowed.includes(state.phase)) {
    throw new Error(`Événement ${event.type} interdit depuis ${state.phase}.`);
  }
}

function timerExpired(state: AutomodRuntimeState, now: number): boolean {
  return state.recoveryPausedAt == null && state.slotDeadlineAt !== null && now >= state.slotDeadlineAt;
}

export function reduceAutomod(state: AutomodRuntimeState, event: AutomodEvent): AutomodRuntimeState {
  if (!Number.isSafeInteger(event.now) || event.now < 0) throw new Error("Horodatage Automod invalide.");

  switch (event.type) {
    case "enable":
      assertPhase(state, event, ["disabled"]);
      return { ...state, phase: state.active === null ? "waiting" : state.bonus !== null && state.bonus.endedAt === null ? "waiting-bonus-end" : "preparing", lastError: null, updatedAt: event.now };

    case "disable":
      return { ...state, phase: "disabled", updatedAt: event.now };

    case "pause":
      assertPhase(state, event, ["waiting", "preparing", "playing", "waiting-bonus-end", "completing", "recovering"]);
      return { ...state, phase: "paused", updatedAt: event.now };

    case "resume":
      assertPhase(state, event, ["paused"]);
      return {
        ...state,
        phase: state.active === null ? "waiting" : state.bonus?.endedAt === null ? "waiting-bonus-end" : "preparing",
        updatedAt: event.now,
      };

    case "item-selected":
      assertPhase(state, event, ["waiting"]);
      return {
        ...state,
        phase: "preparing",
        active: event.item,
        slotStartedAt: null,
        slotDeadlineAt: null,
        recoveryPausedAt: null,
        bonus: null,
        entryBonusPending: false,
        verifiedBaseStakeCents: null,
        verifiedChargedStakeCents: null,
        visitId: `${event.item.key}:${event.now}`,
        ...(state.shopVisit===undefined?{}:{shopVisit:null}),
        roundsPlayed: 0,
        spinInFlight: false,
        lastError: null,
        updatedAt: event.now,
      };

    case "slot-ready":
      assertPhase(state, event, ["preparing"]);
      if (state.active === null) throw new Error("Aucune machine active à démarrer.");
      if (!Number.isSafeInteger(event.durationMs) || event.durationMs <= 0) throw new Error("Durée de slot invalide.");
      return {
        ...state,
        phase: "playing",
        slotStartedAt: state.slotStartedAt,
        slotDeadlineAt: state.slotDeadlineAt,
        bonus: event.existingBonus ? state.bonus?.endedAt === null ? state.bonus : { startedAt: event.now, endedAt: null, gainCents: null } : null,
        entryBonusPending: event.existingBonus === true && state.slotDeadlineAt === null,
        lastError: null,
        updatedAt: event.now,
      };

    case "entry-bonus-finished":
      assertPhase(state, event, ["playing", "waiting-bonus-end"]);
      if (!state.entryBonusPending || state.bonus?.endedAt == null) throw new Error("Bonus d’entrée non terminé.");
      if (!Number.isSafeInteger(event.durationMs) || event.durationMs <= 0) throw new Error("Durée de slot invalide.");
      return { ...state, phase: "playing", entryBonusPending: false, slotStartedAt: null, slotDeadlineAt: null,
        recoveryPausedAt: null, updatedAt: event.now };

    case "first-spin-settled":
      assertPhase(state, event, ["playing"]);
      if (state.entryBonusPending || state.active === null) throw new Error("Premier spin normal attendu après le bonus d’entrée.");
      if (!Number.isSafeInteger(event.durationMs) || event.durationMs <= 0) throw new Error("Durée de slot invalide.");
      if (state.slotDeadlineAt !== null) return state; // Recovery never extends an existing rotation.
      return { ...state, slotStartedAt: event.now, slotDeadlineAt: event.now + event.durationMs, updatedAt: event.now };

    case "spin-intent":
      assertPhase(state, event, ["playing"]);
      if (state.spinInFlight) throw new Error("Un spin est déjà marqué en cours.");
      return { ...state, spinInFlight: true, updatedAt: event.now };

    case "round-settled":
      assertPhase(state, event, ["playing", "waiting-bonus-end"]);
      if (!Number.isSafeInteger(event.roundsPlayed) || event.roundsPlayed < state.roundsPlayed) {
        throw new Error("Compteur de spins Automod invalide.");
      }
      return { ...state, roundsPlayed: event.roundsPlayed, spinInFlight: false, updatedAt: event.now };

    case "restart-item":
      assertPhase(state, event, ["playing"]);
      if (state.active === null) throw new Error("Aucune machine active à relancer.");
      if (state.spinInFlight || (state.bonus !== null && state.bonus.endedAt === null)) {
        throw new Error("Relance interdite pendant un round ou un bonus actif.");
      }
      return { ...state, phase: "preparing", bonus: null, lastError: null, updatedAt: event.now };

    case "tick":
      // A context recovery preserves the same item and deadline.
      if (state.phase !== "playing" && state.phase !== "waiting-bonus-end") return { ...state, updatedAt: event.now };
      if (!timerExpired(state, event.now)) return { ...state, updatedAt: event.now };
      return {
        ...state,
        phase: state.bonus !== null && state.bonus.endedAt === null ? "waiting-bonus-end" : "completing",
        updatedAt: event.now,
      };

    case "context-reopen":
      assertPhase(state, event, ["preparing", "playing", "recovering"]);
      if (state.active === null || state.bonus?.endedAt === null) throw new Error("Réouverture contextuelle interdite pendant un bonus non réglé.");
      return { ...state, phase: "preparing", spinInFlight: false, lastError: null, updatedAt: event.now };

    case "recovery-paused":
      if (state.recoveryPausedAt != null || state.slotDeadlineAt === null || event.now >= state.slotDeadlineAt || state.bonus?.endedAt === null) return state;
      return { ...state, recoveryPausedAt: event.now, updatedAt: event.now };

    case "recovery-resumed":
      if (state.recoveryPausedAt == null) return state;
      return { ...state, slotDeadlineAt: state.slotDeadlineAt === null ? null : state.slotDeadlineAt + Math.max(0,event.now-state.recoveryPausedAt), recoveryPausedAt: null, updatedAt: event.now };

    case "finish-item":
      assertPhase(state, event, ["playing"]);
      if (state.bonus !== null && state.bonus.endedAt === null) {
        throw new Error("Impossible de terminer une machine pendant un bonus.");
      }
      return { ...state, phase: "completing", updatedAt: event.now };

    case "bonus-started":
      assertPhase(state, event, ["playing"]);
      if (state.bonus !== null && state.bonus.endedAt === null) throw new Error("Un bonus est déjà actif.");
      return {
        ...state,
        bonus: { startedAt: event.now, endedAt: null, gainCents: null, ...(event.purchaseOrderId?{purchaseOrderId:event.purchaseOrderId}:{}) },
        updatedAt: event.now,
      };

    case "bonus-ended":
      assertPhase(state, event, ["playing", "waiting-bonus-end"]);
      if (state.bonus === null || state.bonus.endedAt !== null) throw new Error("Aucun bonus actif à terminer.");
      if (!Number.isSafeInteger(event.gainCents) || event.gainCents < 0) throw new Error("Gain de bonus invalide.");
      return {
        ...state,
        // A confirmed payout is not proof that the recap has disappeared.
        // Keep observing; only a subsequent idle tick may authorize rotation.
        phase: !state.entryBonusPending && timerExpired(state, event.now) ? "waiting-bonus-end" : "playing",
        bonus: { ...state.bonus, endedAt: event.now, gainCents: event.gainCents },
        updatedAt: event.now,
      };

    case "bonus-abandoned":
      assertPhase(state, event, ["playing", "waiting-bonus-end"]);
      if (state.bonus === null || state.bonus.endedAt !== null) throw new Error("Aucun bonus actif à abandonner.");
      return {
        ...state,
        phase: "completing",
        bonus: { ...state.bonus, endedAt: event.now, gainCents: null, abandoned: true },
        lastError: event.reason?.trim() || "Bonus abandonné après échec du clic de démarrage; gain final non mesuré.",
        updatedAt: event.now,
      };

    case "item-completed":
      assertPhase(state, event, ["completing"]);
      if (state.active === null) throw new Error("Aucune machine active à terminer.");
      if (state.bonus !== null && (state.bonus.endedAt === null || (state.bonus.gainCents === null && state.bonus.abandoned !== true))) {
        throw new Error("Impossible de quitter avant la fin du bonus et la lecture de son gain.");
      }
      return {
        ...state,
        phase: "waiting",
        active: null,
        slotStartedAt: null,
        slotDeadlineAt: null,
        recoveryPausedAt: null,
        bonus: null,
        roundsPlayed: 0,
        spinInFlight: false,
        lastCompletedKey: state.active.key,
        lastError: null,
        updatedAt: event.now,
      };

    case "discard-processed-item":
      if (state.active === null || state.active.callId === null) {
        throw new Error("Aucun call LunaLive actif à réconcilier.");
      }
      return {
        ...state,
        phase: state.phase === "disabled" ? "disabled" : "waiting",
        active: null,
        slotStartedAt: null,
        slotDeadlineAt: null,
        recoveryPausedAt: null,
        bonus: null,
        roundsPlayed: 0,
        spinInFlight: false,
        lastCompletedKey: state.active.key,
        lastError: null,
        updatedAt: event.now,
      };

    case "skip-random-item":
      assertPhase(state, event, ["preparing", "playing"]);
      if (state.active?.source !== "random" || state.roundsPlayed !== 0 || state.spinInFlight || (state.bonus !== null && state.bonus.endedAt === null)) {
        throw new Error("Seule une machine aléatoire bloquée avant le premier spin peut être écartée.");
      }
      return {
        ...state,
        phase: "waiting",
        active: null,
        slotStartedAt: null,
        slotDeadlineAt: null,
        recoveryPausedAt: null,
        bonus: null,
        roundsPlayed: 0,
        spinInFlight: false,
        lastError: null,
        updatedAt: event.now,
      };

    case "skip-failed-item":
      assertPhase(state, event, ["preparing", "playing"]);
      if (state.active === null || state.spinInFlight || (state.bonus !== null && state.bonus.endedAt === null)) {
        throw new Error("Une machine en erreur ne peut pas être écartée pendant un round ou un bonus actif.");
      }
      return {
        ...state,
        phase: "waiting",
        active: null,
        slotStartedAt: null,
        slotDeadlineAt: null,
        recoveryPausedAt: null,
        bonus: null,
        roundsPlayed: 0,
        spinInFlight: false,
        lastError: event.message.trim() || "Erreur inconnue",
        updatedAt: event.now,
      };

    case "failure":
      if (state.phase === "disabled") throw new Error("Un Automod désactivé ne peut pas entrer en reprise.");
      return { ...state, phase: "recovering", lastError: event.message.trim() || "Erreur inconnue", updatedAt: event.now };

    case "retry":
      assertPhase(state, event, ["recovering"]);
      return {
        ...state,
        phase: state.active === null ? "waiting" : state.bonus !== null && state.bonus.endedAt === null ? "waiting-bonus-end" : "preparing",
        lastError: null,
        updatedAt: event.now,
      };
  }
}
