import { execFile } from "node:child_process";
import { mkdtemp, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import type { Page } from "playwright-core";
import { captureCanvasSnapshot } from "./canvas-snapshot.js";

export function parsePragmaticRecapOcr(text: string): number | null {
  const normalized = text.replace(/\s+/g, " ");
  // Un compteur BIG/NICE WIN et le HUD WIN ne sont pas un récapitulatif final.
  if (/\b(?:BIG|MEGA|SUPER|SENSATIONAL|NICE|EPIC|EXCELLENT)\s*WIN\b/i.test(normalized)) return null;
  if (!/\b(?:CONTINUE|COLLECT)\b/i.test(normalized)) return null;
  const recapTitle = /\bTOTAL\s*WIN\b|\bCONGRATULATIONS\b/i.test(normalized);
  const freeSpinsRecap = /\bYOU\s+(?:HAVE\s+)?WON\b/i.test(normalized) && /\bFREE\s+SPINS\b/i.test(normalized);
  if (!recapTitle && !freeSpinsRecap) return null;
  const match = normalized.match(/\bTOTAL\s*WIN\s*[€$£]?\s*(\d{1,7}(?:[.,]\d{1,2})?)/i)
    ?? normalized.match(/\bYOU\s+(?:HAVE\s+)?WON\s*[€$£]?\s*(\d{1,7}(?:[.,]\d{1,2})?)/i)
    ?? normalized.match(/\bCONGRATULATIONS\s+(?:WIN|WON)\s*[€$£]?\s*(\d{1,7}(?:[.,]\d{1,2})?)/i);
  if (match?.[1] === undefined) return null;
  if (/^\s*FREE\s+SPINS\b/i.test(normalized.slice((match.index ?? 0) + match[0].length))) return null;
  const amount = Number(match[1].replace(",", "."));
  return Number.isFinite(amount) && amount >= 0 ? Math.round(amount * 100) : null;
}

export function pragmaticRecapAmountRegion(tsv: string, width: number, height: number): { x: number; y: number; width: number; height: number } | null {
  const lines = new Map<string, { x: number; y: number; width: number; height: number; words: string[] }>();
  for (const row of tsv.split(/\r?\n/).slice(1)) {
    const columns = row.split("\t"), key = columns.slice(1, 5).join(":");
    if (columns[0] === "4") lines.set(key, { x: Number(columns[6]), y: Number(columns[7]), width: Number(columns[8]), height: Number(columns[9]), words: [] });
    if (columns[0] === "5" && Number(columns[10]) >= 35) lines.get(key)?.words.push(columns[11] ?? "");
  }
  const text = [...lines.values()].map(line => line.words.join(" ").toUpperCase().replace(/[^A-Z0-9 ]/g, ""));
  if (text.some(line => /\b(?:BIG|MEGA|SUPER|SENSATIONAL|NICE|EPIC|EXCELLENT)\s*WIN\b/.test(line))) return null;
  const entries = [...lines.values()];
  const titles = entries.filter((_, index) => /^(?:YOU|OU|NOU) HAVE WON$/.test(text[index] ?? ""));
  const counts = entries.filter((_, index) => /^IN \d+ FREE SPINS$/.test(text[index] ?? ""));
  const actions = entries.filter((_, index) => /\bCONTINUE\b/.test(text[index] ?? ""));
  if (titles.length !== 1 || counts.length !== 1 || actions.length !== 1) return null;
  const title = titles[0]!, count = counts[0]!, action = actions[0]!;
  const center = title.x + title.width / 2, gap = count.y - title.y - title.height;
  if ([title, count, action].some(line => ![line.x, line.y, line.width, line.height].every(Number.isFinite) || line.x < 0 || line.y < 0 || line.width <= 0 || line.height <= 0 || line.x + line.width > width || line.y + line.height > height)) return null;
  if (![width, height, center, gap, title.width].every(Number.isFinite) || width <= 0 || height <= 0 ||
      center < width * .25 || center > width * .8 || title.y < height * .1 || title.y > height * .45 ||
      gap < height * .08 || gap > height * .35 || action.y <= count.y + count.height || action.y > height * .9 ||
      Math.abs(count.x + count.width / 2 - center) > width * .1 || Math.abs(action.x + action.width / 2 - center) > width * .1) return null;
  const cropWidth = Math.round(title.width * .65);
  return { x: Math.round(center - cropWidth / 2), y: Math.round(title.y + title.height + gap * .25), width: cropWidth, height: Math.round(gap * .5) };
}

export function parsePragmaticRecapAmount(text: string): number | null {
  const match = text.trim().match(/^[€$£]?\s*(\d{1,7}[.,]\d{2})\s*[€$£]?$/);
  return match?.[1] === undefined ? null : Math.round(Number(match[1].replace(",", ".")) * 100);
}

function runTesseract(executable: string, imagePath: string, psm: "6" | "7" | "11", deadline: number, tsv = false): Promise<string> {
  return new Promise((resolve, reject) => {
    if (Date.now() >= deadline) { reject(new Error("Délai OCR du récapitulatif dépassé.")); return; }
    execFile(
      executable,
      [imagePath, "stdout", "--psm", psm, ...(tsv ? ["tsv"] : psm === "7" ? ["-c", "tessedit_char_whitelist=€0123456789.,"] : [])],
      { encoding: "utf8", timeout: Math.max(1, Math.min(2_000, deadline - Date.now())), env: { ...process.env, OMP_THREAD_LIMIT: "1" }, maxBuffer: 2 * 1024 * 1024, windowsHide: true },
      (error, stdout) => error ? reject(error) : resolve(stdout),
    );
  });
}

export async function readPragmaticRecapOcr(page: Page): Promise<{ gainCents: number | null; error: string | null }> {
  const deadline = Date.now() + 8_000;
  const directory = await mkdtemp(path.join(os.tmpdir(), "lecasionoze-pragmatic-ocr-"));
  const imagePath = path.join(directory, "recap.png");
  try {
    const visibleFrames = page.locator("iframe:visible");
    let selectedFrame: ReturnType<typeof visibleFrames.nth> | null = null;
    let largestArea = 0;
    for (let index = 0; index < await visibleFrames.count(); index += 1) {
      if (Date.now() >= deadline) throw new Error("Délai de capture du récapitulatif dépassé.");
      const frame = visibleFrames.nth(index);
      const box = await frame.boundingBox({ timeout: Math.max(1, Math.min(1_500, deadline - Date.now())) }).catch(() => null);
      if (box === null || box.width * box.height <= largestArea) continue;
      largestArea = box.width * box.height;
      selectedFrame = frame;
    }
    if (Date.now() >= deadline) throw new Error("Délai de capture du récapitulatif dépassé.");
    const captureTimeout = Math.max(1, Math.min(1_500, deadline - Date.now()));
    const image = selectedFrame === null
      ? await page.screenshot({ type: "png", timeout: captureTimeout })
      // Element screenshots wait for stability and may scroll/restyle an animated iframe.
      // The existing CDP capture reads the visible rectangle without changing the game.
      : await captureCanvasSnapshot(selectedFrame);
    await writeFile(imagePath, image);
    const executable = process.env.TESSERACT_PATH ?? (process.platform === "win32"
      ? "C:\\Program Files\\Tesseract-OCR\\tesseract.exe"
      : "tesseract");
    const tsv = await runTesseract(executable, imagePath, "11", deadline, true);
    const sparseOutput = tsv.split(/\r?\n/).filter(row => row.startsWith("5\t")).map(row => row.split("\t")[11] ?? "").join(" ");
    const sparseGain = parsePragmaticRecapOcr(sparseOutput);
    if (sparseGain !== null) return { gainCents: sparseGain, error: null };
    const region = image.length >= 24 ? pragmaticRecapAmountRegion(tsv, image.readUInt32BE(16), image.readUInt32BE(20)) : null;
    if (region !== null) {
      const amounts: Array<number | null> = [];
      for (const threshold of [205, 225]) {
        if (Date.now() >= deadline) throw new Error("Délai OCR central dépassé.");
        const output = path.join(directory, `amount-${threshold}.png`);
        const mask = `if(gt(r(X,Y),${threshold})*gt(g(X,Y),${threshold}),0,255)`;
        const filter = `crop=${region.width}:${region.height}:${region.x}:${region.y},format=rgb24,geq=r='${mask}':g='${mask}':b='${mask}',scale=iw*3:ih*3:flags=lanczos,pad=iw+48:ih+48:24:24:color=white`;
        await new Promise<void>((resolve, reject) => execFile(process.env.FFMPEG_PATH ?? "ffmpeg", ["-hide_banner", "-loglevel", "error", "-y", "-i", imagePath, "-filter_threads", "1", "-vf", filter, "-threads", "1", "-frames:v", "1", output], { timeout: Math.max(1, Math.min(2_000, deadline - Date.now())), windowsHide: true }, error => error ? reject(error) : resolve()));
        amounts.push(parsePragmaticRecapAmount(await runTesseract(executable, output, "7", deadline)));
      }
      return { gainCents: amounts[0] !== null && amounts[0] === amounts[1] ? amounts[0] ?? null : null, error: null };
    }
    const blockOutput = await runTesseract(executable, imagePath, "6", deadline);
    return { gainCents: parsePragmaticRecapOcr(blockOutput), error: null };
  } catch (error) {
    return { gainCents: null, error: error instanceof Error ? error.message : String(error) };
  } finally {
    await rm(directory, { recursive: true, force: true }).catch(() => undefined);
  }
}
