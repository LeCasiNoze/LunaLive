import type { AutomodConfig } from './automod-config.js';
import type { AutomodItem,AutomodRuntimeState } from './automod-domain.js';
import type { SlotExecutor,SlotObservation } from './automod-service.js';
import type { PointsTransport } from './points-outbox.js';
import { checkedBonusShopOffers,type BonusShopOffer } from './bonus-shop.js';

export interface ShopOrder {
 id:string;kind:'buy'|'stake'|'duration'|'globalstake';tier:number|null;status:string;
 selectedOffer:BonusShopOffer|null;reservedPoints:number;rumbleUserId:string;callId:string|null;
}
export interface ShopVisit {
 callId:string;referenceStakeCents:number;referenceDurationMs:number;technicalFailure:boolean;
 purchaseOrderId:string|null;purchasePausedAt:number|null;purchaseConfirmed:boolean;
 referenceEnhancedCeilings:Record<'hacksaw'|'pragmatic'|'nolimit',number>;
 referenceGlobalFactor?:number;
}
const stakeFactors=[3,6,10],durationFactors=[1.5,2,4];
/** The API owns the wallet/order. This worker owns the real provider action, never a second debit. */
export class AutomodShop {
 private orders:ShopOrder[]=[];private checkedAt=0;private draining=false;private nextPurchaseAt=0;
 private configuredVisit:AutomodConfig|null=null;
 constructor(private transport:PointsTransport,private now=Date.now){}
 hasChosenPurchase():boolean{return this.orders.some(o=>o.kind==='buy'&&o.status==='chosen');}
 private async action(id:string,action:string,body:unknown={}){
  return this.transport.shopRequest<any>('POST',`orders/${id}/${action}`,body);
 }
 async load(item:AutomodItem):Promise<ShopOrder[]>{
  const r=await this.transport.shopRequest<{orders:ShopOrder[]}>('GET',`orders?callId=${encodeURIComponent(item.callId??'')}`);
  this.orders=r.orders.filter(o=>o.kind==='globalstake'||item.callId!==null&&o.callId===item.callId);this.checkedAt=this.now();return this.orders;
 }
 async config(item:AutomodItem,base:AutomodConfig,state:AutomodRuntimeState):Promise<AutomodConfig>{
  const orders=await this.load(item),config=structuredClone(base);
  if(state.shopVisit&&state.shopVisit.callId!==(item.callId??item.key))state.shopVisit=null;
  if(!item.callId&&!orders.some(o=>o.kind==='globalstake')&&(state.shopVisit?.referenceGlobalFactor??1)<=1){this.configuredVisit=null;return config;}
  for(const order of orders.filter(o=>o.status==='pending')){
   const claim=await this.action(order.id,'claim');order.status=claim.status;if(claim.tier!==undefined)order.tier=claim.tier;
  }
  state.shopVisit??={callId:item.callId??item.key,referenceStakeCents:base.stakeCents,referenceDurationMs:base.slotDurationMs,technicalFailure:false,purchaseOrderId:null,purchasePausedAt:null,purchaseConfirmed:false,
    referenceEnhancedCeilings:{hacksaw:base.enhancedSpins.hacksaw.maxTotalStakeCents,pragmatic:base.enhancedSpins.pragmatic.maxTotalStakeCents,nolimit:base.enhancedSpins.nolimit.maxTotalStakeCents}};
  const stake=orders.find(o=>o.kind==='stake'),duration=orders.find(o=>o.kind==='duration');
  config.stakeCents=state.shopVisit.referenceStakeCents;
  config.slotDurationMs=state.shopVisit.referenceDurationMs;
  state.shopVisit.referenceGlobalFactor??=orders.some(o=>o.kind==='globalstake')?3:1;
  const localFactor=stake?stakeFactors[(stake.tier??0)-1]:1;
  if(!localFactor)throw Error('SHOP_INVALID_STAKE_TIER');
  const factor=Math.max(localFactor,state.shopVisit.referenceGlobalFactor);
  if(factor>1){
   config.stakeCents*=factor;config.stakeAtOrBelow=true;
   // Preserve the owner's configured cost ceiling relative to the paid boost.
   for(const provider of ['hacksaw','pragmatic','nolimit'] as const)config.enhancedSpins[provider].maxTotalStakeCents=state.shopVisit.referenceEnhancedCeilings[provider]*factor;
  }
  if(duration){const factor=durationFactors[(duration.tier??0)-1];if(!factor)throw Error('SHOP_INVALID_DURATION_TIER');config.slotDurationMs=Math.round(config.slotDurationMs*factor);}
  this.configuredVisit=structuredClone(config);return config;
 }
 async prepare(executor:SlotExecutor,state:AutomodRuntimeState,config:AutomodConfig):Promise<void>{
  await this.applyBoosts(executor,state,config,false);
  const buy=this.orders.find(o=>o.kind==='buy');
  if(!buy||!['pending','opening'].includes(buy.status))return;
  try {
   if(!executor.inspectBonusShop)throw Error('SHOP_MENU_UNSUPPORTED');
   const offers=checkedBonusShopOffers(await executor.inspectBonusShop());
   const result=await this.action(buy.id,'menu',{offers,cacheBaseStakeCents:config.stakeCents});
   buy.status=result.status;buy.selectedOffer=result.selectedOffer;
  }catch(error){
   state.shopVisit!.technicalFailure=true;
   // Menu failure is not a slot failure: release points and keep the ordinary call playable.
   await this.action(buy.id,'failure',{reason:error instanceof Error?error.message:'menu-unavailable'});
   buy.status='refunded';
  }
 }
 async applyBoosts(executor:SlotExecutor,state:AutomodRuntimeState,config:AutomodConfig,commit=true):Promise<void>{
  for(const order of this.orders.filter(o=>o.kind!=='buy'&&['pending','opening'].includes(o.status))){
   if(order.kind==='globalstake'&&(order.status!=='opening'||(state.shopVisit?.referenceGlobalFactor??1)<=1))continue;
   if(order.kind==='stake'||order.kind==='globalstake'){
    const actual=await executor.activeConfiguration?.();
    const minimum=state.shopVisit!.referenceStakeCents*(order.kind==='stake'?(state.shopVisit!.referenceGlobalFactor??1):1);
    if(!actual||actual.baseStakeCents>config.stakeCents||actual.baseStakeCents<=minimum||actual.chargedStakeCents>config.enhancedSpins[state.active!.provider].maxTotalStakeCents){
     await this.action(order.id,'failure',{reason:'boost-stake-not-achievable'});order.status='refunded';continue;
    }
    if(!commit)continue;
    await this.action(order.id,'boost-applied',{applied:true,baseStakeCents:actual.baseStakeCents,chargedStakeCents:actual.chargedStakeCents});
   }else{if(!commit)continue;await this.action(order.id,'boost-applied',{applied:true,durationMs:config.slotDurationMs});}
   order.status='done';
  }
 }
 /** true owns controls for purchase/drain; normal rotation must wait for the next observation. */
 async tick(executor:SlotExecutor,state:AutomodRuntimeState,observation:SlotObservation,persist:()=>Promise<void>,stopping=false,onPurchased?:()=>Promise<void>):Promise<boolean>{
  if(!state.active)return false;
  if(this.now()-this.checkedAt>=5000)await this.load(state.active);
  // If an API response was lost on the first settled spin, retry the same idempotent debit.
  if(this.configuredVisit&&state.roundsPlayed>0&&state.slotDeadlineAt!==null)await this.applyBoosts(executor,state,this.configuredVisit);
  const buy=this.orders.find(o=>o.kind==='buy'&&(o.id===state.shopVisit?.purchaseOrderId||!['done','expired','refunded'].includes(o.status)));
  if(!buy)return false;
  if(buy.status==='purchase-sent'&&state.shopVisit?.purchaseConfirmed){await this.action(buy.id,'confirmed');buy.status='bonus';}
  if(state.shopVisit?.purchaseConfirmed&&state.bonus?.endedAt!=null&&state.bonus.purchaseOrderId===buy.id){
   if(state.bonus.gainCents===null)throw Error('SHOP_FINAL_GAIN_UNCONFIRMED');
   await this.action(buy.id,'complete',{gainCents:state.bonus.gainCents});buy.status='done';
   const paused=state.shopVisit.purchasePausedAt;
   if(paused!==null&&state.slotDeadlineAt!==null)state.slotDeadlineAt+=Math.max(0,this.now()-paused);
   state.shopVisit.purchasePausedAt=null;state.shopVisit.purchaseOrderId=null;
   this.draining=false;await persist();return false;
  }
  if(['purchase-sent','bonus','uncertain'].includes(buy.status)){
   // Never infer permission to click from a recovered reservation. Observe the bonus instead.
   if(!state.shopVisit?.purchaseConfirmed&&buy.status!=='uncertain')await this.action(buy.id,'failure',{reason:'restart-after-buy-intent-needs-reconciliation'});
   return false;
  }
  if(buy.status!=='chosen'||!buy.selectedOffer||stopping)return false;
  if(this.now()<this.nextPurchaseAt)return false;
  if(state.bonus?.endedAt===null||observation.bonusActive)return false;
  if(state.slotDeadlineAt!==null&&this.now()>=state.slotDeadlineAt)return false;
  if(observation.autoplayActive){
   try{await executor.stop();}catch(error){if(!(error instanceof Error)||!error.message.startsWith('HACKSAW_AUTOPLAY_STOP_PENDING:'))throw error;}
   this.draining=true;return true;
  }
  if(!observation.idle||observation.roundActive)return this.draining;
  if(!executor.inspectBonusShop||!executor.purchaseBonusShop)throw Error('SHOP_PURCHASE_UNSUPPORTED');
  const quote=checkedBonusShopOffers(await executor.inspectBonusShop()).find(o=>o.id===buy.selectedOffer!.id);
  if(!quote)throw Error('SHOP_VARIANT_MISSING');
  const intent=await this.action(buy.id,'intent',{offer:quote});
  if(!intent.authorized){this.nextPurchaseAt=this.now()+Math.max(5000,Number(intent.waitMs)||5000);this.draining=false;return false;}
  state.shopVisit!.purchaseOrderId=buy.id;state.shopVisit!.purchasePausedAt=this.now();
  state.shopVisit!.purchaseConfirmed=false;await persist();
  try{
   await executor.purchaseBonusShop(quote);
   // Provider method resolves only after the bought bonus is observed, never just after an OK click.
   state.shopVisit!.purchaseConfirmed=true;await persist();
   await onPurchased?.();
  }catch(error){
   state.shopVisit!.technicalFailure=true;await persist();
   await this.action(buy.id,'failure',{reason:error instanceof Error?error.message:'buy-confirmation-unknown'});buy.status='uncertain';
   throw error;
  }
  await this.action(buy.id,'confirmed');buy.status='bonus';
  this.draining=false;return true;
 }
 async finish(state:AutomodRuntimeState):Promise<void>{
  if(!state.active)return;
  await this.load(state.active);
  for(const o of this.orders.filter(o=>o.kind!=='globalstake'&&!['done','expired','refunded'].includes(o.status))){
   if(o.kind==='buy'&&o.status==='offered'&&state.slotDeadlineAt!==null&&this.now()>=state.slotDeadlineAt&&state.roundsPlayed>0&&!state.shopVisit?.technicalFailure)await this.action(o.id,'expire',{played:true,technicalFailure:false});
   else await this.action(o.id,'failure',{reason:'call-ended-before-shop-action'});
  }
  this.draining=false;
 }
 async fault(state:AutomodRuntimeState):Promise<void>{
  if(state.shopVisit){state.shopVisit.technicalFailure=true;}
 }
}
