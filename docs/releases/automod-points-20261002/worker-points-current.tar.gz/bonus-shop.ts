/** Quotes use provider-native semantic IDs; a numbered chat option is never an execution ID. */
export interface BonusShopOffer { id:string; label:string; costCents:number; baseStakeCents:number; }
export function checkedBonusShopOffers(raw:BonusShopOffer[]):BonusShopOffer[] {
 if(!raw.length||raw.length>16)throw Error('SHOP_MENU_UNAVAILABLE: aucun menu de bonus fiable.');
 const ids=new Set<string>();
 for(const o of raw){
  if(!/^[a-zA-Z0-9_-]{1,100}$/.test(o.id)||ids.has(o.id)||!o.label||o.label.length>160||!Number.isSafeInteger(o.costCents)||o.costCents<=0||!Number.isSafeInteger(o.baseStakeCents)||o.baseStakeCents<=0)throw Error('SHOP_MENU_AMBIGUOUS: option ou prix non vérifiable.');
  ids.add(o.id);
 }
 return raw;
}
export function sameBonusQuote(a:BonusShopOffer,b:BonusShopOffer):boolean {
 return a.id===b.id&&a.costCents===b.costCents&&a.baseStakeCents===b.baseStakeCents;
}
