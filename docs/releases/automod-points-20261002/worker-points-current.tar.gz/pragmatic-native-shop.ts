import type { BonusShopOffer } from './bonus-shop.js';

/** Self-contained: serialized into the provider iframe. Reading never opens or buys. */
export function pragmaticNativeShop(runtime:any,baseStakeCents:number,ownMenu=false):{offers:BonusShopOffer[];error:string|null;diagnostic?:Record<string,unknown>} {
 const fail=(error:string)=>({offers:[],error});
 if(!Number.isSafeInteger(baseStakeCents)||baseStakeCents<=0)return fail('invalid-base-stake');
 const type=runtime.FeaturePurchaseV2;
 if(typeof type!=='function'&&typeof runtime.FeaturePurchaseManager!=='function'&&typeof runtime.FeaturePurchaseManager_GRM!=='function')return fail('unsupported-purchase-family');
 const managers:any[]=[];
 for(const root of typeof type==='function'?runtime.globalRuntime?.sceneRoots??[]:[]){
  for(const c of root.GetComponentsInChildren(type,true)??[]){
   if(c.enabled===true&&c.xtEnabled===true&&c.gameObject?.activeInHierarchy===true&&!managers.includes(c))managers.push(c);
  }
 }
 if(managers.length===0&&(typeof runtime.FeaturePurchaseManager==='function'||typeof runtime.FeaturePurchaseManager_GRM==='function')){
  // Legacy family (observed on Hot Fiesta). Its costs use the same native money unit.
  const legacy:any[]=[];
  for(const family of [runtime.FeaturePurchaseManager,runtime.FeaturePurchaseManager_GRM].filter(t=>typeof t==='function'))
   for(const root of runtime.globalRuntime?.sceneRoots??[])for(const c of root.GetComponentsInChildren(family,true)??[]){
    if(c.enabled===true&&c.xtEnabled===true&&c.gameObject?.activeInHierarchy===true&&!legacy.includes(c))legacy.push(c);
   }
  if(legacy.length!==1)return fail('ambiguous-legacy-purchase-manager');
  const m=legacy[0];
  const grm=Array.isArray(m.betLevels)&&!Array.isArray(m.purchaseOptionIsAvailable);
  if(m.isSuperSpin===true||m.isFreeBonusRound===true||m.buttonIsHidden===true||m.buttonIsDisabled===true||(grm?m.purchaseDisplayer?.isPurchaseEnabled!==true:m.featurePurchaseIsEnabled!==true))return fail('purchase-not-idle');
  if((!ownMenu||grm)&&(typeof m.CanPurchaseFeature!=='function'||m.CanPurchaseFeature()!==true))return fail('purchase-not-idle');
  let selectedIndex=-1;
  if(ownMenu&&!grm){
   if(typeof runtime.XT?.GetObject!=='function'||!runtime.Vars)return fail('missing-legacy-menu-guards');
   const selected=runtime.XT.GetObject(runtime.Vars.FeaturePurchase),fs=runtime.XT.GetObject(runtime.Vars.ReceivedFreeSpinsResponse),bonus=runtime.XT.GetObject(runtime.Vars.BonusData);
   selectedIndex=selected?.purchaseIndex;
   if(!Number.isSafeInteger(selectedIndex)||selectedIndex<0||fs?.IsFreeSpin===true&&fs?.IsLastFreeSpin!==true||bonus&&bonus.GameOver!==true)return fail('purchase-not-idle');
  }
  const getter=runtime.CoinManager?.GetSmallestBet;
  if(typeof getter!=='function')return fail('missing-price-unit');
  const unit=Reflect.apply(getter,runtime.CoinManager,[]);
  if(typeof unit!=='number'||!Number.isFinite(unit)||unit<=0)return fail('invalid-price-unit');
  let available=m.purchaseOptionIsAvailable;
  if(grm){
   if(typeof runtime.XT?.GetObject!=='function'||!runtime.Vars||typeof m.EnoughMoney!=='function')return fail('missing-grm-menu-guards');
   const level=runtime.XT.GetObject(runtime.Vars.BetLevelSettings)?.betLevelIndex;
   if(!Number.isSafeInteger(level)||m.betLevels.length!==m.purchaseCosts?.length)return fail('invalid-grm-bet-level');
   available=m.purchaseCosts.map((cost:number,i:number)=>m.betLevels[i]===level&&m.EnoughMoney(cost)===true);
  }
  if(!Array.isArray(m.purchaseCosts)||!m.purchaseCosts.length||m.purchaseCosts.length>16||!Array.isArray(available)||available.length!==m.purchaseCosts.length)return fail('ambiguous-purchase-prices');
  const offers:BonusShopOffer[]=[];
  for(let i=0;i<m.purchaseCosts.length;i++){
   if(ownMenu&&!grm?i!==selectedIndex:available[i]!==true)continue;
   const cost=m.purchaseCosts[i];
   if(typeof cost!=='number'||!Number.isFinite(cost)||cost<=0)return fail('invalid-native-price');
   if(ownMenu&&(typeof m.EnoughMoney!=='function'||m.EnoughMoney(cost)!==true))return fail('purchase-not-affordable');
   const exactCents=cost*unit*100,costCents=Math.round(exactCents);
   if(!Number.isSafeInteger(costCents)||costCents<=0||Math.abs(exactCents-costCents)>0.001)return fail('fractional-purchase-price');
   offers.push({id:`pragmatic-${grm?'grm':'legacy'}-${i}`,label:`Bonus ${i+1}`,costCents,baseStakeCents});
  }
  return offers.length?{offers,error:null}:fail('no-enabled-purchase-option');
 }
 if(managers.length!==1)return fail('ambiguous-purchase-manager');
 const m=managers[0];
 // fsPurchased survives the completed purchased bonus on V2; it is history, not current activity.
 // Current activity is checked independently here and by the executor before opening the menu.
 if(m.isSuperSpin===true||m.featureAvailable!==true||m.isFreeSpin===true||m.isBonus===true||m.frbActive===true||!ownMenu&&(m.spinBlockersCounter!==0||m.purchaseBlockCounter!==0))return {...fail('purchase-not-idle'),diagnostic:{isSuperSpin:m.isSuperSpin,featureAvailable:m.featureAvailable,isFreeSpin:m.isFreeSpin,isBonus:m.isBonus,frbActive:m.frbActive,fsPurchased:m.fsPurchased,spinBlockersCounter:m.spinBlockersCounter,purchaseBlockCounter:m.purchaseBlockCounter,ownMenu}};
 const getter=runtime.CoinManager?.GetSmallestBet;
 if(typeof getter!=='function')return fail('missing-price-unit');
 const unit=Reflect.apply(getter,runtime.CoinManager,[]);
 if(typeof unit!=='number'||!Number.isFinite(unit)||unit<=0)return fail('invalid-price-unit');
 const data=m.featurePurchaseData,options=m.purchaseOptions;
 if(!Array.isArray(data?.purchaseCosts)||!Array.isArray(options)||!options.length||options.length>16||data.purchaseCosts.length!==options.length)return fail('ambiguous-purchase-prices');
 const offers:BonusShopOffer[]=[];
 for(let i=0;i<options.length;i++){
  const o=options[i];
  if(o.forceDisabled===true||o.isAvailable!==true||o.isEnabled!==true||o.isDisabledByAnte===true)continue;
  const nativeCost=data.purchaseCosts[i];
  if(typeof nativeCost!=='number'||!Number.isFinite(nativeCost)||nativeCost<=0)return fail('invalid-native-price');
  // purchaseCosts are provider units, NOT cents: native code multiplies by GetSmallestBet().
  const exactCents=nativeCost*unit*100,costCents=Math.round(exactCents);
  if(!Number.isSafeInteger(costCents)||costCents<=0||Math.abs(exactCents-costCents)>0.001)return fail('fractional-purchase-price');
  offers.push({id:`pragmatic-v2-${i}`,label:`Bonus ${i+1}`,costCents,baseStakeCents});
 }
 return offers.length?{offers,error:null}:fail('no-enabled-purchase-option');
}

/** Follow the visible native menu. PurchaseFeature alone only selects the option. */
export function pragmaticNativeShopClick(runtime:any,quote:BonusShopOffer,step:'open'|'select'|'confirm'|'close',read:typeof pragmaticNativeShop):{triggered:boolean;error:string|null;controls?:unknown[]} {
 const legacy=/^pragmatic-(legacy|grm)-(\d+)$/.exec(quote.id);
 if(legacy){
  if(step==='open'||typeof runtime.CATButton!=='function')return {triggered:false,error:'unsupported-legacy-shop-step'};
  const index=Number(legacy[2]),grm=legacy[1]==='grm',buttons:any[]=[];
  const checked=read(runtime,quote.baseStakeCents,step!=='select');
  const actual=checked.offers.find(o=>o.id===quote.id);
  if(checked.error||!actual||actual.costCents!==quote.costCents)return {triggered:false,error:'quote-changed'};
  const flatten=(event:any,seen:any[]=[],depth=0):any[]|null=>{
   if(!event||depth>16)return null;if(seen.includes(event))return [];
   const result:any[]=[];
   for(const a of event.actions??[]){
    if(a.isEnabled===false)continue;result.push(a);
    if(a.eventId?.cat){const linked=a.eventId.cat.events?.find((e:any)=>e.id===a.eventId.id),nested=flatten(linked,[...seen,event],depth+1);if(!nested)return null;result.push(...nested);}
   }
   return result;
  };
  for(const root of runtime.globalRuntime?.sceneRoots??[])for(const b of root.GetComponentsInChildren(runtime.CATButton,true)??[]){
   if(b.enabled!==true||b.gameObject?.activeInHierarchy!==true||typeof b.OnClick!=='function')continue;
   const path:string[]=[];let t=b.transform;for(let d=0;t&&d<16;d++,t=t.parent)path.push(t.gameObject?.name??'');
   if(!(grm?path.includes('PurchaseManager')&&path.includes('BuyFeature'):path.includes('FreeSpinsPurchase'))||path.some(n=>/gamble/i.test(n)))continue;
   const link=b.catEventClick,event=link?.cat?.events?.find((e:any)=>e.id===link.id);if(!event||event.isEnabled===false)continue;
   const actions=flatten(event);if(!actions||actions.some(a=>/gamble/i.test(String(a.data?.methodToCall??'')+String(a.EventToCode?.name??''))||/^(?:Buy|Rebuy|Purchase(?!Feature$))/i.test(String(a.data?.methodToCall??''))))continue;
   const spins=actions.filter(a=>a.EventToCode?.name==='Evt_DataToCode_Pressed_Spin');
   const selected=actions.filter(a=>a.data?.methodToCall==='PurchaseFeature');
   const selectsIndex=selected.length===1&&selected[0].data.useParam===true&&selected[0].data.paramType===2&&Number(selected[0].data.paramString)===index;
   const window=grm?'BuyWindow':'FSPurchaseWindow';
   if(step==='select'&&path.includes('BuyButtons')&&path.includes(`Option_${index}`)&&spins.length===0&&(grm?selected.length===0:selectsIndex))buttons.push(b);
   if(step==='confirm'&&path.includes(window)&&path[0]==='ButtonYes'&&spins.length===1&&(grm?selectsIndex:selected.length===0))buttons.push(b);
   if(step==='close'&&path.includes(window)&&path[0]==='ButtonNo'&&spins.length===0&&(grm?selected.length===0:selected.length===1&&selected[0].data.paramType===2&&Number(selected[0].data.paramString)===-2))buttons.push(b);
  }
  if(buttons.length!==1)return {triggered:false,error:'shop-control-not-unique-or-visible'};
  buttons[0].OnClick();return {triggered:true,error:null};
 }
 const match=/^pragmatic-v2-(\d+)$/.exec(quote.id);
 if(!match||typeof runtime.CATButton!=='function')return {triggered:false,error:'unsupported-shop-ui'};
 const index=Number(match[1]),buttons:any[]=[],controls:unknown[]=[];
 for(const root of runtime.globalRuntime?.sceneRoots??[])for(const b of root.GetComponentsInChildren(runtime.CATButton,true)??[]){
  if(typeof b.OnClick!=='function')continue;
  let parent=b.transform;const path:string[]=[];
  for(let d=0;parent&&d<12;d++,parent=parent.parent)path.push(parent.gameObject?.name??'');
  if(!path.includes('FeaturePurchase'))continue;
  const link=b.catEventClick,event=link?.cat?.events?.find((e:any)=>e.id===link.id);
  if(path.includes('ConfirmPurchaseWindow')||step==='open'&&path.includes('MainButton'))controls.push({path,enabled:b.enabled,active:b.gameObject?.activeInHierarchy,eventEnabled:event?.isEnabled,actions:(event?.actions??[]).map((a:any)=>({type:a.constructor?.name,enabled:a.isEnabled,method:a.data?.methodToCall,targetName:a.data?.target?.gameObject?.name})),purchase:(event?.actions??[]).filter((a:any)=>a.data?.methodToCall==='PurchaseFeature').map((a:any)=>({enabled:a.isEnabled,paramType:a.data.paramType,param:a.data.paramString,useParam:a.data.useParam}))});
  const rebuyMenu=step==='open'&&path[0]==='ColliderRebuy'&&path.includes('MainButton')&&
   (event?.actions??[]).some((a:any)=>a.eventId?.cat?.events?.find((e:any)=>e.id===a.eventId.id)?.userFriendlyName==='Show Purchase Window');
  if(path.some(n=>/gamble/i.test(n))||path.some(n=>/rebuy/i.test(n))&&!rebuyMenu)continue;
  if(b.enabled!==true||b.gameObject?.activeInHierarchy!==true)continue;
  if(!event||event.isEnabled===false)continue;
  if(step==='open'&&path.includes('MainButton')&&(path[0]==='ColliderBuy'||rebuyMenu)){
   // The main Rebuy presentation opens the option menu, unlike the direct RebuyButtons.
   // Refuse any linked chain containing a purchase or an unresolved CAT link.
   const safe=(ev:any,seen:any[]=[],depth=0):boolean=>{
    if(!ev||depth>16)return false;
    if(seen.includes(ev))return true; // Visual open/close chains may reference an already-inspected event.
    for(const a of ev.actions??[]){
     if(a.isEnabled===false)continue;
     if(/^(?:PurchaseFeature|RebuyFeature|RebuyFreeSpins|Buy(?:Bonus|Feature|FreeSpins)|Gamble.*)$/i.test(String(a.data?.methodToCall??'')))return false;
     if(a.eventId?.cat){const linked=a.eventId.cat.events?.find((e:any)=>e.id===a.eventId.id);if(!safe(linked,[...seen,ev],depth+1))return false;}
    }
    return true;
   };
   if(safe(event))buttons.push(b);
  }
  if(step==='select'&&path.includes('PurchaseWindow')&&path.includes(`Option${index+1}`))buttons.push(b);
  if(step==='close'&&path.includes('PurchaseWindow')&&path.includes('CloseButton'))buttons.push(b);
  if(step==='confirm'&&path.includes('ConfirmPurchaseWindow')&&path.includes('AcceptButton')){
   const purchase=(event.actions??[]).filter((a:any)=>a.isEnabled!==false&&a.data?.methodToCall==='PurchaseFeature');
   if(purchase.length===1&&purchase[0].data.useParam===true&&purchase[0].data.paramType===2&&Number(purchase[0].data.paramString)===index)buttons.push(b);
  }
 }
 if(buttons.length!==1)return {triggered:false,error:'shop-control-not-unique-or-visible',controls};
 // Only the recognized visible purchase windows may account for menu spin blockers.
 const result=read(runtime,quote.baseStakeCents,step!=='open');
 const actual=result.offers.find(o=>o.id===quote.id);
 if(result.error||!actual||actual.costCents!==quote.costCents||actual.baseStakeCents!==quote.baseStakeCents)return {triggered:false,error:'quote-changed'};
 buttons[0].OnClick();return {triggered:true,error:null};
}

/** Read visible option captions only; hidden localized placeholders are not evidence. */
export function pragmaticNativeShopLabels(runtime:any):Record<string,string>{
 const captions:Record<string,string[]>={};
 if(typeof runtime.UILabel!=='function')return {};
 for(const root of runtime.globalRuntime?.sceneRoots??[])for(const l of root.GetComponentsInChildren(runtime.UILabel,true)??[]){
  if(l.enabled===false||l.gameObject?.activeInHierarchy!==true)continue;
  let parent=l.transform;const path:string[]=[];
  for(let d=0;parent&&d<14;d++,parent=parent.parent)path.push(parent.gameObject?.name??'');
  const grm=path.includes('PurchaseManager')&&path.includes('BuyFeature');
  const legacy=(path.includes('FreeSpinsPurchase')||grm)&&path.includes('BuyButtons')?path.find(p=>/^Option_\d+$/.test(p)):null;
  if(!legacy&&(!path.includes('PurchaseWindow')||!path.includes('FeaturePurchase')))continue;
  const option=legacy??path.find(p=>/^Option([1-9]|1[0-6])$/.test(p));if(!option)continue;
  const text=String(l.text??'').replace(/\[[^\]]+\]/g,'').replace(/\s+/g,' ').trim();
  if(!text||/[€$£]|^\d+[.,]?\d*$|^Rp\b/i.test(text)||text.length>160)continue;
  const id=legacy?`pragmatic-${grm?'grm':'legacy'}-${Number(legacy.slice(7))}`:`pragmatic-v2-${Number(option.slice(6))-1}`;
  const list=captions[id]??=[];if(!list.includes(text))list.push(text);
 }
 return Object.fromEntries(Object.entries(captions).map(([id,text])=>[id,text.join(' · ').slice(0,160)]));
}
