import { captureCanvasSnapshot } from "./canvas-snapshot.js";
import { checkedBonusShopOffers,sameBonusQuote,type BonusShopOffer } from "./bonus-shop.js";
import type { BrowserContext, Frame, Locator, Page } from "playwright-core";
import { randomUUID } from "node:crypto";
import { ArtifactRecorder } from "./artifacts.js";
import type { AutomodConfig } from "./automod-config.js";
import type { AutomodItem } from "./automod-domain.js";
import type { SlotEvent, SlotExecutor, SlotObservation } from "./automod-service.js";
import { bonusTransitions, hacksawBonusSignal, pragmaticBonusSignal, type BonusSignalState } from "./bonus-signals.js";
import { openBrowser, type BrowserSession } from "./browser.js";
import { CelsiusAdapter } from "./celsius-adapter.js";
import type { RunnerConfig } from "./domain.js";
import { ProfileLock } from "./profile-lock.js";
import { selectMinimumStake } from "./hacksaw-minimum-bench.js";
import { setHacksawSceneIsolation } from "./hacksaw-scene-presentation.js";
import { resizeGameForBenchmark, restoreGameResolution } from "./fps-game-resolution.js";
import { enterProviderGame } from "./provider-bootstrap.js";
import { readPragmaticRecapOcr } from "./pragmatic-recap-ocr.js";
import { readPragmaticBonusOverlay, type BonusOverlay } from "./pragmatic-bonus-overlay.js";
import { findPragmaticPromoOk } from "./pragmatic-overlay-ocr.js";
import { findPragmaticGambleCollect, findPragmaticDeclaredCollect } from "./pragmatic-gamble-ocr.js";
import { pragmaticCustomCollect } from "./pragmatic-custom-collect.js";
import { pragmaticFreeSpinStartContext, pragmaticFreeSpinRecapContext } from "./pragmatic-free-spin-start.js";
import { pragmaticNativeFreeSpins } from "./pragmatic-native-free-spins.js";
import { pragmaticNativeAnte } from "./pragmatic-native-ante.js";
import { pragmaticNativeShop,pragmaticNativeShopClick,pragmaticNativeShopLabels } from "./pragmatic-native-shop.js";
import { startPragmaticAudio } from "./pragmatic-audio.js";
import { findHacksawGambleOffer, type HacksawGambleOffer } from "./hacksaw-gamble-ocr.js";
import { findHacksawContinue } from "./hacksaw-continue-ocr.js";
import { shouldUseHacksawCenterStartFallback, isHacksawBonusStartProgress } from "./hacksaw-start-fallback.js";
import { parseCurrencyCents, type ProviderKey } from "./provider-capabilities.js";
import { installProviderTelemetry, readProviderTelemetry } from "./provider-telemetry.js";
import { installNolimitBridge, NolimitDriver, NolimitEnhancedActivationError } from "./nolimit-driver.js";
import { bootstrapUrbanVpn, setChromeNativeFullscreen } from "./urban-vpn.js";
import { readPrivateEgressCountry } from "./private-egress.js";
import type { CdpGameCapture } from "./cdp-game-capture.js";
import { WinPresentationSkipper, type WinPresentationResult } from "./win-presentation.js";
import { readWinPresentation, readRecoveryWords, type WinObservation } from "./win-presentation-ocr.js";
import { contextBlocker, recoverScreenContext, type ScreenContext, type ContextRecoveryResult } from "./context-recovery.js";
import { parkPresentationPointer as parkPointer } from "./presentation-pointer.js";
import { setGameLinkPresentation } from "./presentation-links.js";
import { cancelHacksawWinEpisode, hacksawCompletedWinCents, readHacksawWinEpisode } from "./hacksaw-win-bridge.js";

interface PragmaticSnapshot {
  bonus: BonusSignalState;
  playingFreeSpins: boolean;
  freeSpinsLeft: number;
  readyToSpin: boolean | null;
  spinBusy: boolean | null;
  resultSignature: string | null;
  telemetryCount: number;
  autoplayActive: boolean;
  autoplayRemaining: number | null;
  lastSpinWinCents: number | null;
  presentationWinCents?: number | null;
  winPresentationCandidate: boolean;
  winPresentationRuntimeKnown: boolean;
  spinResultIsBigWin: boolean | null;
  waitInResultForBigWin: boolean | null;
  bigWinLevel: number | null;
  blockingDialogVisible: boolean | null;
  gambleActive: boolean | null;
  customBonusCollectPending: boolean;
}

interface HacksawSnapshot {
  providerState: string | null;
  bonus: BonusSignalState;
  counterValue: number | null;
  totalWinVisible: boolean;
  idle: boolean;
  balanceCents: number | null;
  autoplayActive: boolean;
  autoplayRemaining: number | null;
  autoplayButtonDisabled: boolean;
  blockingDialogVisible: boolean;
  lastSpinWinCents: number | null;
}

export interface BrowserSlotExecutorOptions {
  runnerConfig: RunnerConfig;
  recorder: ArtifactRecorder;
  now?: () => number;
  replayHacksawBonusAfterDrop?: boolean;
  onMilestone?: (message: string) => void | Promise<void>;
  initialRoundsPlayed?: number;
  requireHacksawReplayOnOpen?: boolean;
  videoCapture?: CdpGameCapture;
  getAudioMode?: () => "spotify" | "game";
}

export interface ActiveSlotConfiguration {
  provider: ProviderKey;
  baseStakeCents: number;
  chargedStakeCents: number;
  enhancedMultiplier: number;
}

export interface ProviderFrameTiming {
  provider: ProviderKey;
  durationMs: number;
  frames: number;
  fps: number;
  averageFrameMs: number;
  p95FrameMs: number;
  framesOver25Ms: number;
  framesOver50Ms: number;
}

export function isPragmaticAutoplayActive(remaining: number | null): boolean {
  return remaining !== null && remaining > 0;
}

export function selectLargestAutoplayBatch(choices: readonly number[], spinsRemaining: number): number {
  if (!Number.isSafeInteger(spinsRemaining) || spinsRemaining <= 0) return 0;
  return [...new Set(choices)]
    .filter((value) => Number.isSafeInteger(value) && value > 0 && value <= spinsRemaining)
    .sort((a, b) => b - a)[0] ?? 0;
}

export function isExplicitSafeGambleDeclineLabel(label: string): boolean {
  return /^(?:collect|no|skip|keep)$/i.test(label.trim());
}

export function isPragmaticZeroCounterSettled(input: {
  remaining: number | null;
  busy: boolean | null;
  bonusActive: boolean;
  since: number | null;
  now: number;
}): boolean {
  return input.remaining === 0 && input.busy === false && !input.bonusActive &&
    input.since !== null && input.now - input.since >= 12_000;
}

export function isHacksawZeroCounterSettled(input: {
  remaining: number | null;
  autoplayActive: boolean;
  bonusActive: boolean;
  blockingDialogVisible: boolean;
  idle: boolean;
  since: number | null;
  now: number;
}): boolean {
  return input.remaining === 0 && !input.autoplayActive && !input.bonusActive && !input.blockingDialogVisible &&
    input.since !== null && (input.idle || input.now - input.since >= 12_000);
}

export function pragmaticUnreadableBonusFallback(input: {
  waitingForReadableBonusEnd: boolean;
  ocrAttempts: number;
  playingFreeSpins: boolean;
  freeSpinsLeft: number;
  spinBusy: boolean | null;
  readyToSpin: boolean | null;
  lastSpinWinCents: number | null;
}): number | null {
  // Conservé pour compatibilité : un dernier spin ne prouve jamais le total du bonus.
  void input;
  return null;
}

function frameOrigin(frame: Frame): string {
  try { return new URL(frame.url()).origin; } catch { return "opaque"; }
}

function exactlyOne<T>(items: readonly T[], label: string): T {
  if (items.length !== 1 || items[0] === undefined) throw new Error(`${label} non unique (${items.length}).`);
  return items[0];
}

function euroToCents(value: unknown): number | null {
  const number = typeof value === "number" ? value : Number.NaN;
  return Number.isFinite(number) && number >= 0 ? Math.round(number * 100) : null;
}

export function isHacksawEnhancedActive(toggleText: string, selectedFeature: boolean): boolean {
  return selectedFeature || /\b(?:disable|désactiver)\b/i.test(toggleText);
}

export function isHacksawWinPresentationState(state: string | null): boolean {
  return state?.replace(/[^a-z]/gi, "").toLocaleLowerCase("en") === "winpresentation";
}

export const HACKSAW_SNAPSHOT_EXPRESSION = `(() => {
  const visible = (selector) => {
    const element = document.querySelector(selector);
    if (!(element instanceof HTMLElement)) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
  };
  const numberText = (selector) => {
    const text = document.querySelector(selector)?.textContent ?? "";
    const match = text.replace(/\\s+/g, "").match(/\\d+/);
    return match === null ? null : Number(match[0]);
  };
  const providerState = document.querySelector("#hacksaw-casino")?.getAttribute("data-state") ?? null;
  const nativeBusy = /^(?:gameRoundEnter|gameRoundExit|play|spin|winPresentation|feature)(?:$|[-_])/i.test(providerState ?? "") || /^feature/i.test(providerState ?? "");
  const placeBet = document.querySelector("#PlaceBetBtn");
  const autoplayButton = document.querySelector("#AutoplayBtn");
  const stopAutoplay = document.querySelector("#StopAutoplayBtn");
  const autoplayCounter = numberText("#AutoplayCounter");
  const blockingDialogVisible = visible("#DialogWindow");
  const totalWinVisible = visible("#FeatureTotalWinItem");
  const lastWinText = ["#WinAmountValue", "#WinValue", "#LastWinValue", "#WinAmount", "#TotalWinValue"]
    .map((selector) => document.querySelector(selector)?.textContent ?? "")
    .find((text) => text.trim().length > 0) ?? "";
  return {
    counterVisible: visible("#FeatureCounterItem"),
    providerState,
    counterValue: numberText("#FeatureCounterValue"),
    totalWinVisible,
    totalWinText: document.querySelector("#FeatureTotalWinValue")?.textContent ?? "",
    balanceText: document.querySelector("#BalanceValue")?.textContent ?? "",
    idle: !nativeBusy && placeBet !== null && visible("#PlaceBetBtn") && !placeBet.disabled && placeBet.getAttribute("aria-disabled") !== "true" && !blockingDialogVisible && !totalWinVisible,
    autoplayActive: stopAutoplay !== null && visible("#StopAutoplayBtn") && autoplayCounter !== null && autoplayCounter > 0,
    autoplayRemaining: autoplayCounter,
    autoplayButtonDisabled: autoplayButton === null || autoplayButton.disabled || autoplayButton.getAttribute("aria-disabled") === "true" || autoplayButton.classList.contains("is-disabled"),
    blockingDialogVisible,
    blockingDialogText: document.querySelector("#DialogWindow")?.textContent ?? "",
    lastWinText,
  };
})()`;

export const PRAGMATIC_SNAPSHOT_EXPRESSION = `(() => {
  const runtime = window;
  const vars = runtime.Vars ?? {};
  const hp = runtime.HPVARS ?? {};
  const numeric = (value) => {
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value !== "string") return null;
    const normalized = value.replace(/[^0-9,.-]/g, "").replace(",", ".");
    if (!/[0-9]/.test(normalized)) return null;
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : null;
  };
  const readNumber = (name) => {
    const key = vars[name] ?? name;
    for (const getter of [runtime.XT?.GetDouble, runtime.XT?.GetInt]) {
      if (typeof key !== "string" || typeof getter !== "function") continue;
      try {
        const value = Reflect.apply(getter, runtime.XT, [key]);
        const parsed = numeric(value);
        if (parsed !== null && parsed >= 0) return parsed;
      } catch {}
    }
    const value = hp[name] ?? vars[name];
    return numeric(value);
  };
  const readBool = (names) => {
    let sawFalse = false;
    for (const name of names) {
      const direct = hp[name] ?? vars[name];
      if (typeof direct === "boolean") {
        if (direct) return true;
        sawFalse = true;
      }
      const key = vars[name] ?? name;
      const getter = runtime.XT?.GetBool;
      if (typeof key === "string" && typeof getter === "function") {
        try {
          const value = Reflect.apply(getter, runtime.XT, [key]);
          if (typeof value === "boolean") {
            if (value) return true;
            sawFalse = true;
          }
        } catch {}
      }
    }
    return sawFalse ? false : null;
  };
  const readObject = (name) => {
    const key = vars[name];
    if (typeof key === "string" && typeof runtime.XT?.GetObject === "function") {
      try { const object = runtime.XT.GetObject(key); if (object !== null && typeof object === "object") return object; } catch {}
    }
    for (const value of [hp[name], vars[name], runtime[name]]) if (value !== null && typeof value === "object") return value;
    return null;
  };
  const nativeFreeSpins = (${pragmaticNativeFreeSpins.toString()})(runtime);
  const response = nativeFreeSpins.response ?? readObject("ReceivedFreeSpinsResponse");
  const spinResponse = readObject("ReceivedSpinResponse");
  const call = (name) => {
    if (typeof response !== "object" || response === null) return undefined;
    const fn = response[name];
    try { return typeof fn === "function" ? Reflect.apply(fn, response, []) : response[name]; }
    catch { return undefined; }
  };
  const collected = call("IsFreeSpinsCollected") === true;
  // CurrentSpin/MaxSpins existent aussi sur certains rounds normaux et ont
  // provoqué un faux bonus sur The Dog House. Seuls les drapeaux explicites
  // du provider constituent une preuve de démarrage.
  const responseSignals = !collected && (
    call("IsFreeSpin") === true || call("IsFreeSpinsStart") === true
  );
  const playingFreeSpins = hp.playingFreeSpins === true;
  const logicIsFreeSpin = readBool(["Logic_IsFreeSpin"]) === true;
  const freeSpinsLeft = Math.max(0, Math.trunc(readNumber("FreeSpinsLeftDisplayed") ?? 0));
  const responseTotalWin = ["TotalWinMultiplied", "TotalWin", "Win", "WinAmount", "CoinWin"]
    .map(call)
    .map(numeric)
    .find((value) => value !== null) ?? null;
  const explicitTotalWin = responseTotalWin ?? [
    "FreeSpinsTotalWinDisplayed",
    "FreeSpinsTotalWin",
    "FreeSpinTotalWin",
    "TotalFreeSpinsWin",
    "WinDisplayed",
    "TotalWinDisplayed",
    "WinAmountDisplayed",
  ].map(readNumber).find((value) => value !== null) ?? null;
  const totalWin = nativeFreeSpins.final ? nativeFreeSpins.totalWin : explicitTotalWin;
  const totalWinAuthoritative = nativeFreeSpins.final; // Per-spin/default zero responses never prove the final bonus payout.
  const ready = readBool(["Logic_CanSpin", "CanSpin", "SpinButtonEnabled", "IsSpinAllowed", "spinButtonEnabled", "canSpin"]);
  const busy = readBool(["Logic_IsSpinInProgress", "IsSpinInProgress", "SpinInProgress", "GameBusy", "isSpinning", "spinInProgress"]);
  const autoplayRemaining = readNumber("AutoplaySpinsLeft");
  const autoplayDisplayed = readNumber("AutoplaySpinsLeftDisplayed");
  const readResponseNumber = (object, names) => {
    if (typeof object !== "object" || object === null) return null;
    for (const name of names) {
      const member = object[name];
      try {
        const value = typeof member === "function" ? Reflect.apply(member, object, []) : member;
        const parsed = numeric(value);
        if (parsed !== null && parsed >= 0) return parsed;
      } catch {}
    }
    return null;
  };
  const responseWin = readResponseNumber(spinResponse, ["TotalWin", "Win", "WinAmount", "CoinWin", "GetTotalWin"]);
  const displayedWin = ["WinDisplayed", "TotalWinDisplayed", "WinAmountDisplayed", "LastWin", "LastWinDisplayed"]
    .map(readNumber)
    .find((value) => value !== null) ?? null;
  const coinManager = runtime.CoinManager;
  const managerWin = readResponseNumber(
    typeof coinManager === "object" && coinManager !== null && typeof coinManager.instance === "object"
      ? coinManager.instance
      : coinManager,
    ["lastWin", "lastTotalWin", "win", "totalWin", "getLastWin", "getTotalWin"],
  );
  const lastSpinWin = responseWin ?? displayedWin ?? managerWin;
  const presentationWin = readNumber("SpinCycleWinReceived") ?? readNumber("WinReceived");
  const spinResultIsBigWin = readBool(["SpinResultIsBigWin"]);
  const waitInResultForBigWin = readBool(["WaitInResultForBigWin"]);
  const bigWinLevel = readNumber("BigWinLevel");
  // Some games initialize BigWinLevel only on their first big win. Two
  // registered, explicitly false presentation flags still prove inactivity.
  // Any active/partial flag requires a readable level; never guess a win.
  const inactivePresentation = spinResultIsBigWin === false && waitInResultForBigWin === false;
  const winPresentationRuntimeKnown = ["SpinResultIsBigWin", "WaitInResultForBigWin", "BigWinLevel"].every(name => typeof vars[name] === "string") && spinResultIsBigWin !== null && waitInResultForBigWin !== null && (inactivePresentation || bigWinLevel !== null);
  const winPresentationCandidate = winPresentationRuntimeKnown && spinResultIsBigWin === true && waitInResultForBigWin === true && bigWinLevel >= 1;
  const gambleNames = ["CanGamble_Spin", "CanGamble_FreeSpin", "CanGamble_Bonus"];
  const customBonusCollectPending = (${pragmaticCustomCollect.toString()})(runtime).pending;
  const gambleActive = customBonusCollectPending ? true : gambleNames.some(name => typeof vars[name] === "string" || typeof hp[name] === "boolean") ? readBool(gambleNames) : null;
  const blockingDialogVisible = typeof document === "undefined" ? null : [...document.querySelectorAll('dialog[open],[role="dialog"],[role="alertdialog"],[aria-modal="true"]')].some(element => {
    const rect = element.getBoundingClientRect(), style = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
  });
  const roundParts = [call("RoundId"), call("CurrentSpin"), call("TotalWin"), hp.ReceivedSpinResponse, vars.ReceivedSpinResponse]
    .map((value) => typeof value === "object" && value !== null ? Object.keys(value).slice(0, 10).join(",") : String(value ?? ""));
  return {
    playingFreeSpins: nativeFreeSpins.final ? false : playingFreeSpins, logicIsFreeSpin: nativeFreeSpins.final ? false : logicIsFreeSpin, freeSpinsLeft, responseSignals: nativeFreeSpins.final ? false : responseSignals, totalWin, totalWinAuthoritative, ready, busy,
    resultSignature: roundParts.join("|"),
    telemetryCount: runtime.__lecasionozeTelemetry?.length ?? 0,
    autoplayActive: autoplayRemaining !== null && autoplayRemaining > 0,
    autoplayRemaining: autoplayRemaining !== null && autoplayRemaining >= 0
      ? Math.trunc(autoplayRemaining)
      : autoplayDisplayed !== null && autoplayDisplayed >= 0 ? Math.trunc(autoplayDisplayed) : null,
    lastSpinWin, presentationWin, winPresentationCandidate, winPresentationRuntimeKnown, spinResultIsBigWin, waitInResultForBigWin, bigWinLevel, gambleActive, blockingDialogVisible, customBonusCollectPending,
  };
})()`;

export class BrowserSlotExecutor implements SlotExecutor {
  private static readonly VPN_RECHECK_INTERVAL_MS = 30 * 60_000;
  private lastVpnVerifiedAt = 0;
  private readonly now: () => number;
  private browser: BrowserSession | null = null;
  private profileLock: ProfileLock | null = null;
  private lobbyPage: Page | null = null;
  private gamePage: Page | null = null;
  private provider: ProviderKey | null = null;
  private previousBonus: BonusSignalState = { active: false, gainCents: null };
  private roundsPlayed = 0;
  private spinPending = false;
  private spinStartedAt = 0;
  private pendingSawBusy = false;
  private pendingResultSeenAt: number | null = null;
  private spinBaselineSignature: string | null = null;
  private spinBaselineTelemetry = 0;
  private spinLastBalanceCents: number | null = null;
  private lastPragmatic: PragmaticSnapshot | null = null;
  private lastHacksaw: HacksawSnapshot | null = null;
  private nolimitDriver: NolimitDriver | null = null;
  private bonusStartAdvanced = false;
  private bonusCollectAdvanced = false;
  private pragmaticOverlayLastCheckedAt = 0;
  private pragmaticOverlayUnresolvedSince: number | null = null;
  private hacksawContinueOcrMisses = 0;
  private hacksawBonusCollectDetectedAt: number | null = null;
  private hacksawBonusCollectCenterClicked = false;
  private hacksawBonusStartDetectedAt: number | null = null;
  private hacksawBonusStartCenterClicked = false;
  private lastBonusGainCents: number | null = null;
  private bonusDetectedAt = 0;
  private pragmaticStartCanvasClicks = 0;
  private pragmaticStartFreeSpinsLeft: number | null = null;
  private pragmaticStartCanvasClickedAt = 0;
  private pragmaticOcrGainCents: number | null = null;
  private pragmaticOcrCandidate: { gainCents: number; since: number } | null = null;
  private pragmaticFinalStateSince: number | null = null;
  private pragmaticOcrAttempts = 0;
  private pragmaticZeroAutoplaySince: number | null = null;
  private pragmaticZeroAutoplayLogged = false;
  private pragmaticLastOcrAt = 0;
  private pragmaticPromoLastCheckedAt = 0;
  private lastAdvanceAt = 0;
  private expectedChargedStakeCents: Partial<Record<ProviderKey, number>> = {};
  private actualBaseStakeCents = 0;
  private hacksawVerifiedBaseStakeCents: number | null = null;
  private hacksawEnhancedActive = false;
  private hacksawChargedStakeCents: number | null = null;
  private activeItem: AutomodItem | null = null;
  private hacksawReplayPending = false;
  private hacksawReplayDone = false;
  private resumeCapturedBonus = false;
  private pendingBaseGameConfig: AutomodConfig | null = null;
  private shopBaseConfig: AutomodConfig | null = null;
  private pendingWinGains: NonNullable<SlotObservation["winPresentations"]> = [];
  private pragmaticPendingWin: NonNullable<SlotObservation["winPresentations"]>[number] | null = null;
  private discardHacksawReplay = false;
  private pointerParkedAt = Number.NEGATIVE_INFINITY;
  private pointerReport: string | null = null;
  private readonly pragmaticWinSkipper: WinPresentationSkipper;
  private pragmaticWinProgressKey: string | null = null;
  private pragmaticWinProgressAt = 0;
  private pragmaticWinReference: PragmaticSnapshot | null = null;
  private pragmaticWinLatestSnapshot: PragmaticSnapshot | null = null;
  private pragmaticWinCanvas: Locator | null = null;
  private pragmaticWinHolding = false;
  private pragmaticWinLastReport: string | null = null;
  private pragmaticWinAudit: Record<string, boolean | number | null> | null = null;
  private pragmaticWinGeneration = 0;
  private pragmaticWinHoldingSince: number | null = null;
  private pragmaticWinEpisodeReference: PragmaticSnapshot | null = null;
  private pragmaticWinTickPending = false;
  private pragmaticWinContext: { generation: number; page: Page; frame: Frame; deadline: number; cancelled: boolean } | null = null;
  private nativeAutoplay = false;
  private autoplayLastRemaining: number | null = null;
  private nativeAutoplayStopRequested = false;
  private hacksawZeroAutoplaySince: number | null = null;
  private hacksawZeroAutoplayLogged = false;
  private hacksawWinSkipInFlight = false;

  public async measureProviderFrameTiming(durationMs = 5_000): Promise<ProviderFrameTiming> {
    if (!Number.isFinite(durationMs) || durationMs < 1_000 || durationMs > 30_000) {
      throw new Error("Durée de mesure FPS invalide (1 à 30 secondes requises).");
    }
    const provider = this.provider;
    if (provider === null) throw new Error("Aucun provider actif pour mesurer les FPS.");
    let frame: Frame;
    if (provider === "hacksaw") frame = this.hacksawFrame();
    else if (provider === "pragmatic") frame = await this.pragmaticFrame();
    else {
      const matches: Frame[] = [];
      for (const candidate of this.requireGamePage().frames()) {
        if (!/nolimitcdn\.com/i.test(candidate.url())) continue;
        const ownsRuntime = await candidate.evaluate<boolean>(`(() =>
          Boolean(window.NolimitLauncher?.constructor?.apiPlugin) ||
          Boolean(window.nolimitApi) ||
          Boolean(document.querySelector(".nolimit.container.ready canvas"))
        )()`).catch(() => false);
        if (ownsRuntime) matches.push(candidate);
      }
      frame = exactlyOne(matches, "Frame runtime Nolimit");
    }
    const result = await frame.evaluate<{
      durationMs: number;
      frames: number;
      fps: number;
      averageFrameMs: number;
      p95FrameMs: number;
      framesOver25Ms: number;
      framesOver50Ms: number;
    }>(`(async () => {
      const requestedMs = ${Math.round(durationMs)};
      const stamps = [];
      const startedAt = performance.now();
      await new Promise((resolve) => {
        const sample = (at) => {
          stamps.push(at);
          if (at - startedAt >= requestedMs) resolve();
          else requestAnimationFrame(sample);
        };
        requestAnimationFrame(sample);
      });
      const deltas = stamps.slice(1).map((at, index) => at - (stamps[index] ?? at)).filter((value) => value >= 0);
      const sorted = deltas.slice().sort((left, right) => left - right);
      const elapsed = Math.max(1, (stamps.at(-1) ?? startedAt) - (stamps[0] ?? startedAt));
      const p95 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95))] ?? 0;
      return {
        durationMs: elapsed,
        frames: stamps.length,
        fps: Math.max(0, stamps.length - 1) * 1_000 / elapsed,
        averageFrameMs: deltas.length === 0 ? 0 : deltas.reduce((sum, value) => sum + value, 0) / deltas.length,
        p95FrameMs: p95,
        framesOver25Ms: deltas.filter((value) => value > 25).length,
        framesOver50Ms: deltas.filter((value) => value > 50).length,
      };
    })()`);
    const timing = { provider, ...result };
    await this.options.recorder.event("provider-frame-timing", timing);
    return timing;
  }

  public async celsiusLayoutDiagnostic(): Promise<unknown> {
    const page = this.requireGamePage();
    const dom = await page.evaluate(`(() => Array.from(document.querySelectorAll("[class*='integrated-game'], iframe, object, embed, canvas"))
      .slice(0, 40)
      .map((element) => {
        const rect = element.getBoundingClientRect();
        return {
          tag: element.tagName,
          className: typeof element.className === "string" ? element.className : "",
          parentClass: typeof element.parentElement?.className === "string" ? element.parentElement.className : "",
          childClasses: Array.from(element.children).slice(0, 12).map((child) => typeof child.className === "string" ? child.className : child.tagName),
          rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
          display: getComputedStyle(element).display,
          visibility: getComputedStyle(element).visibility,
          src: element instanceof HTMLIFrameElement ? element.src : null,
        };
      }))()`);
    const frames = await Promise.all(page.frames().map(async (frame) => {
      const owner = frame === page.mainFrame()
        ? null
        : await frame.frameElement().then((element) => element.evaluate((node) => {
            const owner = node as HTMLElement;
            const rect = owner.getBoundingClientRect();
            return {
              tag: owner.tagName,
              className: typeof owner.className === "string" ? owner.className : "",
              parentClass: typeof owner.parentElement?.className === "string" ? owner.parentElement.className : "",
              rect: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
              outerHtml: owner.outerHTML.slice(0, 500),
            };
          })).catch(() => null);
      return { url: frame.url(), name: frame.name(), owner };
    }));
    return { dom, frames };
  }
  private hacksawGambleOffer: HacksawGambleOffer | null = null;
  private hacksawGambleOcrAt = 0;
  private hacksawBonusPurchasePending = false;
  private expectedGamePath: string | null = null;

  public constructor(private readonly options: BrowserSlotExecutorOptions) {
    this.now = options.now ?? Date.now;
    this.pragmaticWinSkipper = new WinPresentationSkipper({
      observe: () => this.readPragmaticWinPresentation(),
      canClick: () => this.canSkipPragmaticWinPresentation(),
      clickCenter: () => this.clickPragmaticWinPresentation(),
      now: this.now,
    });
  }

  public async ensureGameAudio(): Promise<void> {
    if (this.options.getAudioMode?.() !== "game" || this.provider !== "pragmatic" || this.gamePage === null) return;
    try {
      const frame = await this.pragmaticFrame();
      const state = await frame.evaluate(`(${startPragmaticAudio.toString()})(window)`);
      if (state === "started") await this.options.onMilestone?.("Audio Pragmatic : chargement natif des sons démarré.");
    } catch {
      await this.options.onMilestone?.("Audio Pragmatic non confirmé ; parcours du jeu conservé.");
    }
  }

  private async parkPresentationPointer(force = false): Promise<void> {
    const page = this.gamePage;
    if (page === null || page.isClosed() || (!force && this.now() - this.pointerParkedAt < 1_500)) return;
    this.pointerParkedAt = this.now();
    const result = await parkPointer(page);
    const report = result.parked ? `CSS confirmé, natif=${result.native}` : `non confirmé (${result.reason})`;
    if (report !== this.pointerReport) {
      this.pointerReport = report;
      try { await this.options.onMilestone?.(`Pointeur présentation: ${report}.`); } catch { console.warn(`Pointeur présentation: ${report}.`); }
    }
  }

  private installProviderNetworkDiagnostics(): void {
    const context = this.browser?.context;
    if (context === undefined) return;
    const relevant = (rawUrl: string): boolean => {
      try {
        const host = new URL(rawUrl).hostname.toLowerCase();
        return /(?:^|\.)(?:nolimitcdn\.com|nolimitcity\.io|evo-games\.com)$/.test(host);
      } catch {
        return false;
      }
    };
    context.on("requestfailed", (request) => {
      if (!relevant(request.url())) return;
      void this.options.recorder.event("provider-network-request-failed", {
        url: request.url(),
        method: request.method(),
        resourceType: request.resourceType(),
        failure: request.failure()?.errorText ?? "unknown",
      }).catch(() => undefined);
    });
    context.on("response", (response) => {
      if (!relevant(response.url())) return;
      const request = response.request();
      const status = response.status();
      void this.options.recorder.event("provider-network-response", {
        url: response.url(),
        method: request.method(),
        resourceType: request.resourceType(),
        status,
        ok: response.ok(),
        contentType: response.headers()["content-type"] ?? null,
      }).catch(() => undefined);
      if (status >= 400) {
        void response.text().then((body) => this.options.recorder.event("provider-network-error-body", {
          url: response.url(),
          status,
          body: body.slice(0, 2_000),
        })).catch(() => undefined);
      }
    });
    const attachConsole = (page: Page): void => {
      page.on("console", (message) => {
        if (!relevant(message.location().url) || !["error", "warning"].includes(message.type())) return;
        void this.options.recorder.event("provider-console", {
          level: message.type(),
          url: message.location().url,
          text: message.text().slice(0, 2_000),
        }).catch(() => undefined);
      });
      page.on("pageerror", (error) => {
        void this.options.recorder.event("provider-page-error", {
          pageUrl: page.url(),
          message: error.message.slice(0, 2_000),
        }).catch(() => undefined);
      });
    };
    for (const page of context.pages()) attachConsole(page);
    context.on("page", attachConsole);
  }

  private async assertWebGlReady(): Promise<void> {
    const page = this.browser?.page;
    if (page === undefined || page.isClosed()) throw new Error("Préflight WebGL impossible: page Chrome absente.");
    const state = await page.evaluate(`(() => {
      const result = {};
      for (const kind of ["webgl", "webgl2"]) {
        const canvas = document.createElement("canvas");
        const gl = canvas.getContext(kind);
        if (!gl) { result[kind] = { available: false }; continue; }
        const extension = gl.getExtension("WEBGL_debug_renderer_info");
        result[kind] = {
          available: true,
          renderer: extension ? String(gl.getParameter(extension.UNMASKED_RENDERER_WEBGL)) : "masked",
        };
      }
      return result;
    })()` ) as Record<string, { available: boolean; renderer?: string }>;
    await this.options.recorder.event("browser-webgl-preflight", {
      softwareGraphicsRequested: process.env.AUTOMOD_SOFTWARE_GRAPHICS === "1",
      webgl: state.webgl ?? { available: false },
      webgl2: state.webgl2 ?? { available: false },
    });
    if (state.webgl?.available !== true) {
      throw new Error(
        "WebGL indisponible dans Chrome; Automod interrompu avant ouverture d'une slot. " +
        "Sur le VPS Xvfb, AUTOMOD_SOFTWARE_GRAPHICS=1 est requis.",
      );
    }
  }

  private async ensureBrowser(): Promise<void> {
    if (this.browser !== null && this.lobbyPage !== null && !this.lobbyPage.isClosed()) return;
    this.profileLock = await ProfileLock.acquire(this.options.runnerConfig.profileDir);
    try {
      this.browser = await openBrowser(this.options.runnerConfig, { managedAudio: true });
      this.installProviderNetworkDiagnostics();
      await this.assertWebGlReady();
      await installProviderTelemetry(this.browser.context);
      await installNolimitBridge(this.browser.context);
      await bootstrapUrbanVpn(this.browser.context, this.options.runnerConfig.vpn, this.options.recorder);
      await setChromeNativeFullscreen(this.browser.page, true);
      this.lastVpnVerifiedAt = this.now();
      this.lobbyPage = this.browser.page;
      await this.ensureLobbyAuthenticated();
    } catch (error) {
      await this.browser?.close().catch(() => undefined);
      this.browser = null;
      this.lobbyPage = null;
      await this.profileLock.release().catch(() => undefined);
      this.profileLock = null;
      throw error;
    }
  }

  private async ensureVpnFresh(): Promise<void> {
    if (!this.options.runnerConfig.vpn.enabled) return;
    if (this.browser === null || this.browser.context.pages().length === 0) {
      throw new Error("Contrôle Urban VPN impossible : navigateur Celsius absent.");
    }
    if (this.now() - this.lastVpnVerifiedAt < BrowserSlotExecutor.VPN_RECHECK_INTERVAL_MS) return;
    const country = await readPrivateEgressCountry(this.browser.context).catch(() => null);
    if (country === "NO") {
      this.lastVpnVerifiedAt = this.now();
      await this.options.onMilestone?.("Contrôle réseau privé : Norway confirmé, aucune interruption du jeu.");
      return;
    }
    await this.options.onMilestone?.("Contrôle périodique Urban VPN avant le prochain lot de spins.");
    await setChromeNativeFullscreen(this.browser.page, false);
    try {
      await bootstrapUrbanVpn(this.browser.context, this.options.runnerConfig.vpn, this.options.recorder);
    } finally {
      await setChromeNativeFullscreen(this.browser.page, true);
    }
    this.lastVpnVerifiedAt = this.now();
  }

  private async ensureLobbyAuthenticated(): Promise<CelsiusAdapter> {
    const page = this.lobbyPage;
    if (page === null || page.isClosed()) throw new Error("Page Celsius persistante absente.");
    await setGameLinkPresentation(page, false);
    await this.updateHacksawScenePresentation(page, false);
    const celsius = new CelsiusAdapter(page, this.options.runnerConfig.baseUrl, this.options.recorder, this.options.onMilestone);
    const assessment = await celsius.open();
    const challengeVisible = async (): Promise<boolean> => page.evaluate<boolean>(`(() => {
      const visible = (el) => { const box = el.getBoundingClientRect(); const style = getComputedStyle(el); return box.width > 20 && box.height > 20 && style.display !== 'none' && style.visibility !== 'hidden'; };
      const selector = 'iframe[src*="captcha" i],iframe[src*="challenge" i],iframe[src*="turnstile" i],.cf-turnstile,#challenge-stage,#cf-chl-widget,[data-sitekey],input[name="cf-turnstile-response"]';
      if ([...document.querySelectorAll(selector)].some(visible)) return true;
      const text = ((document.title || '') + ' ' + (document.body?.innerText || '')).toLowerCase().replace(/\\s+/g, ' ');
      return /verify (?:you are|that you are) human|vérifiez que vous êtes humain|checking your browser|just a moment|security verification|confirmez que vous êtes humain/.test(text);
    })()`).catch(() => false);
    const stopForCaptcha = async (): Promise<never> => {
      await this.options.onMilestone?.("CAPTCHA détecté : arrêt immédiat de l’Automod et du stream Rumble. Validation manuelle requise avant tout redémarrage.");
      throw new Error("AUTOMOD_BLOCKED_CAPTCHA: CAPTCHA détecté; arrêt immédiat du stream et de l’Automod, puis validation manuelle requise.");
    };
    if (await challengeVisible()) await stopForCaptcha();
    let hydrated = assessment;
    let lastHydrationError: string | null = null;
    for (let attempt = 0; hydrated.level !== "authenticated-likely" && attempt <= 2; attempt += 1) {
      if (attempt > 0) {
        // Avoid refreshing a live challenge: it can invalidate the widget or
        // immediately trigger another CAPTCHA for the same session.
        if (await challengeVisible()) await stopForCaptcha();
        await this.options.onMilestone?.(`Celsius indisponible malgré Norway: actualisation automatique ${attempt}/2.`);
        await page.reload({ waitUntil: "domcontentloaded", timeout: 60_000 }).catch(() => undefined);
        await page.waitForTimeout(2_000);
        if (await challengeVisible()) await stopForCaptcha();
      }
      try {
        hydrated = await celsius.waitForLobbyHydration();
        lastHydrationError = null;
      } catch (error) {
        if (await challengeVisible()) await stopForCaptcha();
        lastHydrationError = error instanceof Error ? error.message : String(error);
        hydrated = { level: "unknown", reason: lastHydrationError };
      }
    }
    if (hydrated.level !== "authenticated-likely") {
      throw new Error(`Session Celsius non authentifiée (${hydrated.level})${lastHydrationError ? `: ${lastHydrationError}` : "."}`);
    }
    return celsius;
  }

  private async updateHacksawScenePresentation(page: Page, enabled: boolean): Promise<void> {
    if (page.isClosed()) return;
    try {
      if (!enabled) await restoreGameResolution(page);
      const result = await setHacksawSceneIsolation(page, enabled);
      if (enabled) await this.options.onMilestone?.(`Présentation Hacksaw allégée: ${result.hidden} éléments externes masqués, géométrie du jeu conservée.`);
    } catch (error) {
      if (page.isClosed()) return;
      let restorationError: string | null = null;
      try {
        if (!enabled) await restoreGameResolution(page);
        await setHacksawSceneIsolation(page, false);
      }
      catch (restoreError) {
        if (page.isClosed()) return;
        restorationError = restoreError instanceof Error ? restoreError.message : String(restoreError);
      }
      const reason = error instanceof Error ? error.message : String(error);
      const message = `Présentation Hacksaw: optimisation abandonnée (${reason}). ${restorationError === null ? "Affichage externe restauré." : `Restauration impossible: ${restorationError}`}`;
      try {
        if (this.options.onMilestone) await this.options.onMilestone(message);
        else console.warn(message);
      }
      catch { console.warn(message); }
      if (restorationError !== null) throw new Error(`Restauration de la présentation Hacksaw impossible: ${restorationError}`, { cause: error });
    }
  }

  private async restoreHacksawScenePresentation(): Promise<void> {
    for (const page of new Set([this.gamePage, this.lobbyPage])) {
      if (page !== null && !page.isClosed()) {
        await setGameLinkPresentation(page, false);
        await this.updateHacksawScenePresentation(page, false);
      }
    }
  }

  private resetSlotState(): void {
    this.expectedChargedStakeCents = {};
    this.hacksawVerifiedBaseStakeCents = null;
    this.pendingBaseGameConfig = null;
    this.pendingWinGains = [];
    this.pragmaticPendingWin = null;
    this.invalidateWinPresentation();
    this.pragmaticWinHoldingSince = null;
    this.pragmaticWinEpisodeReference = null;
    this.pragmaticWinProgressKey = null;
    this.pragmaticWinProgressAt = this.now();
    this.pragmaticWinReference = null;
    this.pragmaticWinLatestSnapshot = null;
    this.pragmaticWinCanvas = null;
    this.pragmaticWinHolding = false;
    this.pragmaticWinLastReport = null;
    this.pragmaticWinAudit = null;
    this.previousBonus = { active: false, gainCents: null };
    this.roundsPlayed = this.options.initialRoundsPlayed ?? 0;
    this.spinPending = false;
    this.spinStartedAt = 0;
    this.pendingSawBusy = false;
    this.pendingResultSeenAt = null;
    this.spinBaselineSignature = null;
    this.spinBaselineTelemetry = 0;
    this.spinLastBalanceCents = null;
    this.lastPragmatic = null;
    this.lastHacksaw = null;
    this.nolimitDriver = null;
    this.bonusStartAdvanced = false;
    this.bonusCollectAdvanced = false;
    this.hacksawContinueOcrMisses = 0;
    this.hacksawBonusCollectDetectedAt = null;
    this.hacksawBonusCollectCenterClicked = false;
    this.hacksawBonusStartDetectedAt = null;
    this.hacksawBonusStartCenterClicked = false;
    this.lastBonusGainCents = null;
    this.bonusDetectedAt = 0;
    this.pragmaticOverlayUnresolvedSince = null;
    this.pragmaticStartCanvasClicks = 0;
    this.pragmaticStartFreeSpinsLeft = null;
    this.pragmaticStartCanvasClickedAt = 0;
    this.pragmaticOcrGainCents = null;
    this.pragmaticOcrCandidate = null;
    this.pragmaticFinalStateSince = null;
    this.pragmaticOcrAttempts = 0;
    this.pragmaticLastOcrAt = 0;
    this.lastAdvanceAt = 0;
    this.hacksawEnhancedActive = false;
    this.hacksawChargedStakeCents = null;
    this.hacksawReplayPending = false;
    this.hacksawReplayDone = false;
    this.nativeAutoplay = false;
    this.autoplayLastRemaining = null;
    this.nativeAutoplayStopRequested = false;
    this.hacksawZeroAutoplaySince = null;
    this.hacksawZeroAutoplayLogged = false;
    this.hacksawGambleOffer = null;
    this.hacksawGambleOcrAt = 0;
    this.hacksawBonusPurchasePending = false;
  }

  public async open(item: AutomodItem, config: AutomodConfig): Promise<{ existingBonus: boolean } | void> {
    this.expectedGamePath = null;
    if (!config.allowedProviders.includes(item.provider)) throw new Error(`Provider ${item.provider} interdit par la configuration.`);
    await this.ensureBrowser();
    await this.restoreHacksawScenePresentation();
    const canSwitchInsideCelsius =
      this.gamePage !== null &&
      this.gamePage === this.lobbyPage &&
      !this.gamePage.isClosed() &&
      this.gamePage.url().startsWith(new URL(this.options.runnerConfig.baseUrl).origin);
    let celsius: CelsiusAdapter;
    if (canSwitchInsideCelsius && this.lobbyPage !== null) {
      await this.options.videoCapture?.stop().catch(() => undefined);
      this.gamePage = null;
      this.provider = null;
      this.resetSlotState();
      celsius = new CelsiusAdapter(this.lobbyPage, this.options.runnerConfig.baseUrl, this.options.recorder, this.options.onMilestone);
    } else {
      await this.close();
      celsius = await this.ensureLobbyAuthenticated();
    }
    let page: Page;
    try {
      page = await celsius.openNormalGame(item.slotName);
    } catch (directError) {
      if (!canSwitchInsideCelsius) throw directError;
      await this.lobbyPage?.goto(this.options.runnerConfig.baseUrl, { waitUntil: "domcontentloaded", timeout: 60_000 });
      celsius = await this.ensureLobbyAuthenticated();
      page = await celsius.openNormalGame(item.slotName);
      await this.options.recorder.event("automod-direct-switch-fallback", {
        slotName: item.slotName,
        reason: directError instanceof Error ? directError.message : String(directError),
      });
    }
    await this.options.onMilestone?.(`Écran pré-slot: entrée ${item.provider} détectée pour ${item.slotName}.`);
    const replayRequired = item.provider === "hacksaw" && !this.discardHacksawReplay && (this.options.requireHacksawReplayOnOpen === true || this.resumeCapturedBonus);
    const interruptedRoundChoice = replayRequired ? "replay" as const : "discard" as const;
    let entry = await enterProviderGame(page, new URL(this.options.runnerConfig.baseUrl).origin, { hacksawInterruptedRound: interruptedRoundChoice });
    await this.options.onMilestone?.(`Écran pré-slot validé: ${item.slotName} (${entry.action}).`);
    if (item.provider === "hacksaw" && !replayRequired && entry.action !== "round-discarded") {
      const secondPass = await enterProviderGame(page, new URL(this.options.runnerConfig.baseUrl).origin, { hacksawInterruptedRound: "discard" });
      if (secondPass.action === "round-discarded") entry = secondPass;
    }
    if (entry.action === "round-discarded") {
      await this.options.onMilestone?.(`Round Hacksaw interrompu sans bonus enregistré: réponse NO pour ${item.slotName}.`);
    }
    if (replayRequired) {
      const replayDeadline = this.now() + 25_000;
      while (entry.action !== "replay-confirmed" && this.now() <= replayDeadline) {
        await page.waitForTimeout(500);
        entry = await enterProviderGame(page, new URL(this.options.runnerConfig.baseUrl).origin, { hacksawInterruptedRound: "replay" });
        if (entry.action === "replay-confirmed") {
          await this.options.onMilestone?.(`Écran pré-slot: rejeu du bonus confirmé YES pour ${item.slotName}.`);
        }
      }
    }
    if (entry.provider !== item.provider) {
      if (page !== this.lobbyPage) await page.close().catch(() => undefined);
      throw new Error(`Provider attendu ${item.provider}, provider ouvert ${entry.provider}.`);
    }
    // L'intro provider ou un round interrompu peut reconstruire le conteneur
    // Celsius. Le plein écran est donc réaffirmé après l'entrée, pas seulement
    // après la sélection EUR.
    await celsius.ensureGameFullscreen(page, item.slotName);
    await this.options.videoCapture?.attach(page);
    this.gamePage = page;
    this.provider = entry.provider;
    this.resetSlotState();
    await this.ensureGameAudio();
    this.activeItem = item;
    this.shopBaseConfig = structuredClone(config);
    if (this.resumeCapturedBonus) this.pendingBaseGameConfig = structuredClone(config);
    let recoveredActiveBonus = false;
    if (entry.provider === "hacksaw") {
      if (replayRequired && entry.action !== "replay-confirmed") {
        const balanceText = await this.hacksawFrame().locator("#BalanceValue").textContent().catch(() => null);
        const balanceCents = parseCurrencyCents(balanceText ?? "");
        throw new Error(`Rejeu du bonus Hacksaw attendu mais option non détectée; aucun nouveau spin; balanceCents=${balanceCents ?? "illisible"}.`);
      }
      if (entry.action === "replay-confirmed" && this.resumeCapturedBonus) {
        this.actualBaseStakeCents = config.stakeCents;
        this.hacksawEnhancedActive = config.enhancedSpins.hacksaw.enabled;
        this.hacksawChargedStakeCents = this.expectedChargedStakeCents.hacksaw ?? config.stakeCents;
        this.hacksawReplayDone = true;
        const activeDeadline = this.now() + 20_000;
        this.lastHacksaw = await this.readHacksaw();
        while (!this.lastHacksaw.bonus.active && this.now() <= activeDeadline) {
          await page.waitForTimeout(250);
          this.lastHacksaw = await this.readHacksaw();
        }
        if (!this.lastHacksaw.bonus.active) throw new Error("Bonus Hacksaw non actif après acceptation du rejeu.");
        this.previousBonus = { active: false, gainCents: null };
        await this.options.onMilestone?.("BONUS REJOUÉ");
      } else if (entry.action === "replay-confirmed") {
        const settlementDeadline = this.now() + this.options.runnerConfig.safety.settlementTimeoutMs;
        this.lastHacksaw = await this.readHacksaw();
        while (!this.lastHacksaw.bonus.active && !this.lastHacksaw.idle && this.now() <= settlementDeadline) {
          await page.waitForTimeout(250);
          this.lastHacksaw = await this.readHacksaw();
        }
        if (this.lastHacksaw.bonus.active) {
          recoveredActiveBonus = true;
          this.actualBaseStakeCents = config.stakeCents;
          this.hacksawEnhancedActive = config.enhancedSpins.hacksaw.enabled;
          this.hacksawChargedStakeCents = this.expectedChargedStakeCents.hacksaw ?? config.stakeCents;
          this.previousBonus = { active: false, gainCents: null };
          await this.options.onMilestone?.("ROUND INTERROMPU REPRIS: BONUS DÉTECTÉ");
        } else if (this.lastHacksaw.idle) {
          this.actualBaseStakeCents = await this.configureHacksaw(config);
          this.lastHacksaw = await this.readHacksaw();
          this.previousBonus = this.lastHacksaw.bonus;
        } else {
          throw new Error("Round Hacksaw interrompu non réglé dans le délai de sécurité.");
        }
      } else {
        this.lastHacksaw = await this.readHacksaw();
        if (this.lastHacksaw.bonus.active || this.lastHacksaw.totalWinVisible) {
          recoveredActiveBonus = true;
          this.pendingBaseGameConfig = structuredClone(config);
          this.previousBonus = { active: true, gainCents: null };
          this.bonusDetectedAt = this.now();
        } else {
          this.actualBaseStakeCents = await this.configureHacksaw(config);
          this.lastHacksaw = await this.readHacksaw();
          this.previousBonus = this.lastHacksaw.bonus;
        }
      }
    } else if (entry.provider === "pragmatic") {
      if (this.resumeCapturedBonus) await this.options.onMilestone?.("Reprise Pragmatic: lecture de l’état du bonus capturé.");
      this.lastPragmatic = await this.readPragmatic();
      if (this.resumeCapturedBonus) {
        await this.options.onMilestone?.(
          `Reprise Pragmatic: actif=${this.lastPragmatic.bonus.active}, ` +
          `freeSpinsLeft=${this.lastPragmatic.freeSpinsLeft}, ` +
          `gain=${this.lastPragmatic.bonus.gainCents === null ? "illisible" : `${(this.lastPragmatic.bonus.gainCents / 100).toFixed(2)} €`}.`,
        );
        const activeDeadline = this.now() + 20_000;
        let recap = this.lastPragmatic.bonus.active ? null : await this.readPragmaticRecap();
        while (!this.lastPragmatic.bonus.active && this.lastPragmatic.freeSpinsLeft === 0 && recap?.gainCents == null && this.now() <= activeDeadline) {
          await page.waitForTimeout(250);
          this.lastPragmatic = await this.readPragmatic();
          if (!this.lastPragmatic.bonus.active) recap = await this.readPragmaticRecap();
        }
        if (!this.lastPragmatic.bonus.active && this.lastPragmatic.freeSpinsLeft === 0 && recap?.gainCents == null) throw new Error("Bonus Pragmatic capturé introuvable après rechargement.");
        this.actualBaseStakeCents = config.stakeCents;
        this.previousBonus = { active: true, gainCents: null };
        this.bonusDetectedAt = this.now();
      } else {
        const recap = this.lastPragmatic.bonus.active || this.lastPragmatic.freeSpinsLeft > 0
          ? null : await this.readPragmaticRecap();
        const screen = await this.readPragmaticOverlay();
        if (screen.kind === "intro" && !this.lastPragmatic.bonus.active && this.lastPragmatic.freeSpinsLeft === 0) {
          if (!await this.clearPragmaticOverlay(false)) throw new Error("PRAGMATIC_OVERLAY_UNRESOLVED: introduction résiduelle non fermée.");
          this.lastPragmatic = await this.readPragmatic();
        }
        if (this.lastPragmatic.bonus.active || this.lastPragmatic.freeSpinsLeft > 0 || screen.kind === "recap" || recap?.gainCents !== null && recap?.gainCents !== undefined) {
          recoveredActiveBonus = true;
          this.pendingBaseGameConfig = structuredClone(config);
          this.actualBaseStakeCents = await this.readPragmaticTotalBetCents(await this.pragmaticFrame()) ?? config.stakeCents;
          this.previousBonus = { active: true, gainCents: null };
          this.bonusDetectedAt = this.now();
          await this.options.onMilestone?.("Bonus/récapitulatif Pragmatic déjà présent : conservation de la mise existante jusqu’au retour au jeu de base.");
        } else {
          this.actualBaseStakeCents = await this.configurePragmatic(config);
          this.lastPragmatic = await this.readPragmatic();
          this.previousBonus = this.lastPragmatic.bonus;
        }
      }
    } else {
      this.nolimitDriver = new NolimitDriver(page, this.options.onMilestone, this.now);
      try {
        await this.nolimitDriver.initialize(config, this.resumeCapturedBonus);
      } catch (error) {
        if (
          error instanceof NolimitEnhancedActivationError &&
          config.enhancedSpins.nolimit.enabled &&
          !this.resumeCapturedBonus
        ) {
          await this.options.onMilestone?.(
            `${error.message} Fallback sécurisé: rechargement de ${item.slotName}, ` +
            `mise de base ${(config.stakeCents / 100).toFixed(2)} € sans Golden.`,
          );
          // Repartir d'une slot fraîche garantit que ni le menu ni une sélection
          // partielle ne restent actifs. Le second passage ne peut pas retomber
          // dans ce fallback puisque la politique Nolimit y est désactivée.
          const previousExpectedCost = this.expectedChargedStakeCents.nolimit;
          this.expectedChargedStakeCents.nolimit = config.stakeCents;
          try {
            await this.close();
            await this.open(item, {
              ...config,
              enhancedSpins: {
                ...config.enhancedSpins,
                nolimit: { ...config.enhancedSpins.nolimit, enabled: false },
              },
            });
          } finally {
            if (previousExpectedCost === undefined) delete this.expectedChargedStakeCents.nolimit;
            else this.expectedChargedStakeCents.nolimit = previousExpectedCost;
          }
          await this.options.onMilestone?.(
            `Fallback Nolimit confirmé: ${item.slotName} prête à ${(config.stakeCents / 100).toFixed(2)} € sans Golden.`,
          );
          return;
        }
        throw error;
      }
      const snapshot = this.nolimitDriver.snapshot();
      if (!this.resumeCapturedBonus && snapshot.bonus.active) {
        recoveredActiveBonus = true;
        this.pendingBaseGameConfig = structuredClone(config);
      }
      this.actualBaseStakeCents = snapshot.baseStakeCents ?? config.stakeCents;
      if (this.resumeCapturedBonus) {
        this.previousBonus = { active: false, gainCents: null };
      } else {
        this.previousBonus = snapshot.bonus;
      }
    }
    if (!this.resumeCapturedBonus && !recoveredActiveBonus) {
      const actualConfiguration = await this.activeConfiguration();
      await this.options.onMilestone?.(
        `${item.provider === "hacksaw" ? "FeatureSpins" : "Golden Bet"} ` +
        `${actualConfiguration.enhancedMultiplier > 1 ? "ACTIVE" : "OFF"} · ` +
        `base ${(actualConfiguration.baseStakeCents / 100).toFixed(2)} € · ` +
        `total ${(actualConfiguration.chargedStakeCents / 100).toFixed(2)} €`,
      );
      const policy = config.enhancedSpins[item.provider];
      if (policy.enabled && actualConfiguration.enhancedMultiplier > 1) {
        if (actualConfiguration.enhancedMultiplier > policy.maxMultiplier) {
          throw new Error(`Golden Bet ${item.provider} ${actualConfiguration.enhancedMultiplier}x hors plafond ${policy.maxMultiplier}x.`);
        }
        if (actualConfiguration.chargedStakeCents > policy.maxTotalStakeCents) {
          throw new Error(`Golden Bet ${item.provider} à ${actualConfiguration.chargedStakeCents} centimes, plafond ${policy.maxTotalStakeCents} centimes.`);
        }
      } else if (actualConfiguration.chargedStakeCents !== actualConfiguration.baseStakeCents) {
        throw new Error(`Mode majoré ${item.provider} encore actif malgré la politique désactivée.`);
      }
      const expectedCost = this.expectedChargedStakeCents[item.provider];
      if (expectedCost !== undefined && actualConfiguration.chargedStakeCents !== expectedCost) {
        throw new Error(
          `Coût réel ${actualConfiguration.chargedStakeCents} centimes différent du coût confirmé ${expectedCost} centimes; aucun spin.`,
        );
      }
    }
    if (item.provider === "hacksaw" && process.env.AUTOMOD_ISOLATE_HACKSAW_SCENE === "1") {
      await this.updateHacksawScenePresentation(page, true);
    }
    if (item.provider === "hacksaw" && process.env.AUTOMOD_HACKSAW_RENDER_WIDTH === "544") {
      try {
        await resizeGameForBenchmark(page, 544);
        await this.options.onMilestone?.("Rendu Hacksaw 544×306 vérifié; surface visible conservée.");
      } catch (error) {
        // A normal resize failure restores the old style. An aggregate error
        // means restoration failed too: let context recovery handle it.
        if (error instanceof AggregateError) throw error;
        await this.options.onMilestone?.(`Rendu Hacksaw 306p indisponible, résolution originale restaurée: ${error instanceof Error ? error.message : String(error)}`);
      }
    }
    const linkPresentation = await setGameLinkPresentation(page, true);
    if (linkPresentation.suppressed > 0) await this.options.onMilestone?.(`Présentation Celsius: ${linkPresentation.suppressed} lien conteneur neutralisé pendant le plein écran.`);
    await this.parkPresentationPointer(true);
    await this.options.recorder.event("automod-slot-ready", {
      slotName: item.slotName,
      provider: item.provider,
      stakeCents: config.stakeCents,
      enhancedSpins: config.enhancedSpins[item.provider],
    });
    if (recoveredActiveBonus) this.pendingBaseGameConfig ??= structuredClone(config);
    this.expectedGamePath = new URL(page.url()).origin + new URL(page.url()).pathname;
    return { existingBonus: recoveredActiveBonus };
  }

  private async inspectScreenContext(): Promise<ScreenContext> {
    const page = this.gamePage ?? this.lobbyPage;
    if (!page || page.isClosed()) return { kind: "lobby", signature: "page-absent" };
    const shell = await page.evaluate<{ text: string; title: string; challenge: boolean; login: boolean }>(`(() => {
      const visible = (el) => { const box = el.getBoundingClientRect(); return box.width > 30 && box.height > 30 && getComputedStyle(el).visibility !== "hidden"; };
      return { text: document.body?.innerText.slice(0, 4000) ?? "", title: document.title,
        challenge: [...document.querySelectorAll('iframe[src*="captcha"],iframe[src*="challenge"],.cf-turnstile')].some(visible),
        login: [...document.querySelectorAll('input[type="password"]')].some(visible) };
    })()`).catch(() => null);
    if (shell === null) return { kind: "unknown", signature: "page-loading" };
    const blocker = shell.challenge ? "CAPTCHA" : shell.login ? "SESSION_EXPIRED" : contextBlocker(`${shell.title} ${shell.text}`);
    if (blocker) return { kind: "blocked", signature: blocker, reason: blocker };
    const currentPath = new URL(page.url()).origin + new URL(page.url()).pathname;
    if (this.expectedGamePath !== null && currentPath !== this.expectedGamePath) return { kind: "wrong-slot", signature: currentPath };
    try {
      if (this.provider === "hacksaw") {
        const snapshot = await this.readHacksaw();
        this.lastHacksaw = snapshot;
        if (snapshot.bonus.gainCents !== null && this.previousBonus.active) this.lastBonusGainCents = snapshot.bonus.gainCents;
        const signature = JSON.stringify([snapshot.providerState, snapshot.counterValue, snapshot.totalWinVisible, snapshot.autoplayRemaining, snapshot.bonus.gainCents]);
        if (this.hacksawGambleOffer !== null || /buy|gamble|purchase/i.test(snapshot.providerState ?? "")) return { kind: "protected", signature };
        if (snapshot.blockingDialogVisible) return { kind: "unknown", signature };
        if (/^featureExit/i.test(snapshot.providerState ?? "") && snapshot.totalWinVisible) return { kind: "recap", signature };
        if (/^feature(?:Enter|Play)/i.test(snapshot.providerState ?? "")) return { kind: "bonus", signature };
        if (snapshot.idle && /^(?:idle|autoplay)/i.test(snapshot.providerState ?? "")) return { kind: "base", signature };
        if (/^(?:autoplay|gameRound)/i.test(snapshot.providerState ?? "")) return { kind: "spinning", signature };
        return { kind: "unknown", signature };
      }
      if (this.provider === "pragmatic") {
        const snapshot = await this.readPragmatic();
        this.lastPragmatic = snapshot;
        const overlay = await this.readPragmaticOverlay();
        const signature = JSON.stringify([overlay.kind, snapshot.freeSpinsLeft, snapshot.autoplayRemaining, snapshot.resultSignature, snapshot.bonus.gainCents]);
        if (snapshot.gambleActive === true) return { kind: "protected", signature };
        if (snapshot.blockingDialogVisible || overlay.kind === "unknown") return { kind: "unknown", signature };
        if (overlay.kind === "recap") return { kind: "recap", signature };
        if (overlay.kind === "intro" || snapshot.bonus.active) return { kind: "bonus", signature };
        if (snapshot.readyToSpin === true && snapshot.spinBusy === false) return { kind: "base", signature };
        if (snapshot.spinBusy === true) return { kind: "spinning", signature };
        return { kind: "unknown", signature };
      }
      if (this.provider === "nolimit" && this.nolimitDriver !== null) return this.nolimitDriver.recoveryContext();
    } catch (error) {
      const reason = contextBlocker(String(error));
      if (reason) return { kind: "blocked", signature: reason, reason };
    }
    const providers = page.frames().filter(frame => frame !== page.mainFrame() && /hacksawgaming|pragmatic|nolimitcdn/i.test(frame.url()));
    return { kind: providers.length ? "unknown" : "lobby", signature: `frames:${providers.length}` };
  }

  private async clickUnknownScreenOnce(stillOwned: () => boolean): Promise<boolean> {
    if (!stillOwned()) return false;
    const fresh = await this.inspectScreenContext();
    if (fresh.kind !== "unknown" && fresh.kind !== "recap") return false;
    const canvases: Array<{ canvas: Locator; width: number; height: number }> = [];
    for (const frame of this.requireGamePage().frames()) {
      for (const canvas of await frame.locator("canvas").all().catch(() => [] as Locator[])) {
        if (!await canvas.isVisible().catch(() => false)) continue;
        const box = await canvas.boundingBox();
        if (box && box.width >= 200 && box.height >= 100) canvases.push({ canvas, width: box.width, height: box.height });
      }
    }
    canvases.sort((a, b) => b.width * b.height - a.width * a.height);
    const target = canvases[0];
    if (!target) return false;
    const words = await readRecoveryWords(await captureCanvasSnapshot(target.canvas)).catch(() => null);
    if (!stillOwned() || words === null || contextBlocker(words) || /gamble|double your win|extra spin|confirm.{0,20}(?:buy|purchase)|(?:price|cost).{0,15}[€$£]/i.test(words)) return false;
    await target.canvas.click({ force: true, timeout: 2_000, position: { x: Math.round(target.width / 2), y: Math.round(target.height / 2) } });
    await this.options.onMilestone?.("Écran inconnu : clic central unique envoyé ; analyse du contexte pendant trois secondes.");
    return true;
  }

  public async recoverContext(): Promise<ContextRecoveryResult> {
    const page = this.gamePage;
    const generation = this.pragmaticWinGeneration;
    const deadline = Date.now() + 15_000;
    const stillOwned = () => Date.now() < deadline && this.gamePage === page && this.pragmaticWinGeneration === generation;
    try {
      if (page !== null && !page.isClosed()) {
        const providerError = await Promise.all(page.frames().map(frame => frame.locator("body").innerText({ timeout:1_000 }).catch(()=>"")))
          .then(parts=>parts.some(text=>/something went wrong/i.test(text))).catch(()=>false);
        if (providerError) {
          await this.options.onMilestone?.("Erreur provider ‘Something went wrong’ détectée : actualisation de la page puis réouverture normale de la slot.");
          // Re-enter through the real lobby: reopening a broken game iframe
          // leaves its wallet/session error intact. Keep this inside recovery's budget.
          await page.goto(this.options.runnerConfig.baseUrl, { waitUntil:"domcontentloaded", timeout:8_000 });
          await page.waitForTimeout(1_000);
          return { action:"reopen", context:{ kind:"unknown", signature:"provider-error-refreshed" }, clicked:false };
        }
      }
      const result = await recoverScreenContext({ inspect: () => stillOwned() ? this.inspectScreenContext() : Promise.resolve({ kind: "unknown", signature: "recovery-expired" }),
        advanceKnown: () => stillOwned() ? this.advanceBonus() : Promise.resolve(), clickOnce: () => this.clickUnknownScreenOnce(stillOwned),
        wait: ms => new Promise(resolve => setTimeout(resolve, ms)) });
      await this.options.recorder.event("automod-context-recovery", { ...result });
      return result;
    } finally { await this.parkPresentationPointer(true); }
  }

  public async prepareBaseGame(): Promise<boolean> {
    const config = this.pendingBaseGameConfig;
    if (config === null) return true;
    if ((this.provider !== "nolimit" && this.previousBonus.active) || this.pragmaticWinHolding) return false;
    if (this.provider === "pragmatic") {
      const before = await this.readPragmatic();
      if (before.bonus.active || before.playingFreeSpins || before.freeSpinsLeft !== 0 || before.readyToSpin !== true || before.spinBusy === true || before.blockingDialogVisible !== false || before.gambleActive === true) return false;
      if (!this.bonusCollectAdvanced) {
        if (this.lastBonusGainCents === null || !await this.clearPragmaticOverlay(true)) return false;
        this.bonusCollectAdvanced = true;
      }
      const recap = await this.readPragmaticRecap();
      if (recap.error !== null || recap.gainCents !== null) return false;
      if (!await this.clearPragmaticOverlay(true)) return false;
      await this.requireGamePage().waitForTimeout(300);
      const stable = await this.readPragmatic();
      if (stable.bonus.active || stable.freeSpinsLeft !== 0 || stable.playingFreeSpins || stable.readyToSpin !== true || stable.spinBusy === true || stable.blockingDialogVisible !== false || stable.gambleActive === true) return false;
      this.actualBaseStakeCents = await this.configurePragmatic(config);
      this.lastPragmatic = await this.readPragmatic();
    } else if (this.provider === "nolimit") {
      if (this.nolimitDriver === null || !await this.nolimitDriver.prepareBaseGame(config)) return false;
      this.actualBaseStakeCents = this.nolimitDriver.snapshot().baseStakeCents ?? config.stakeCents;
    } else if (this.provider === "hacksaw") {
      const before = await this.readHacksaw();
      if (!before.idle || before.bonus.active || before.totalWinVisible || before.blockingDialogVisible) return false;
      await this.requireGamePage().waitForTimeout(300);
      const stable = await this.readHacksaw();
      if (!stable.idle || stable.bonus.active || stable.totalWinVisible || stable.blockingDialogVisible) return false;
      this.actualBaseStakeCents = await this.configureHacksaw(config);
      this.lastHacksaw = await this.readHacksaw();
    } else return false;
    this.pendingBaseGameConfig = null;
    await this.options.onMilestone?.("Retour au jeu de base confirmé après bonus restauré ; mise et mode majoré réglés.");
    return true;
  }

  public async openCapturedBonus(item: AutomodItem, config: AutomodConfig): Promise<void> {
    this.resumeCapturedBonus = true;
    try {
      await this.open(item, config);
    } finally {
      this.resumeCapturedBonus = false;
    }
  }

  private invalidateWinPresentation(): void {
    this.pragmaticWinSkipper.reset();
    this.pragmaticWinGeneration++;
    if (this.pragmaticWinContext !== null) this.pragmaticWinContext.cancelled = true;
    this.pragmaticWinContext = null;
  }

  public async discardCapturedHacksawBonus(item: AutomodItem, config: AutomodConfig): Promise<void> {
    if (item.provider !== "hacksaw") throw new Error("Le refus de rejeu est réservé aux bonus Hacksaw persistants.");
    const previousDiscard = this.discardHacksawReplay, previousResume = this.resumeCapturedBonus;
    this.discardHacksawReplay = true;
    this.resumeCapturedBonus = false;
    try {
      await this.open(item, config);
      const page = this.requireGamePage(), deadline = this.now() + 8_000;
      let stableReads = 0;
      while (this.now() <= deadline) {
        const snapshot = await this.readHacksaw();
        stableReads = snapshot.idle === true && snapshot.bonus.active === false && snapshot.autoplayActive === false && snapshot.blockingDialogVisible === false ? stableReads + 1 : 0;
        if (stableReads >= 4) {
          this.lastHacksaw = snapshot;
          this.previousBonus = snapshot.bonus;
          await this.options.onMilestone?.("Refus NON Hacksaw confirmé: 4 lectures fraîches idle, bonus inactif, autoplay arrêté et aucun dialogue.");
          return;
        }
        await page.waitForTimeout(250);
      }
      throw new Error("Refus NON Hacksaw sans preuve stable idle/bonus inactif après 8 secondes; abandon interdit.");
    } finally {
      this.discardHacksawReplay = previousDiscard;
      this.resumeCapturedBonus = previousResume;
      await this.parkPresentationPointer(true);
    }
  }

  private hacksawFrame(): Frame {
    const page = this.requireGamePage();
    return exactlyOne(page.frames().filter((frame) => /(?:^|\.)hacksawgaming\.com(?:[/:]|$)/i.test(frame.url())), "Frame Hacksaw");
  }

  private async pragmaticFrame(): Promise<Frame> {
    const page = this.requireGamePage();
    const celsiusOrigin = new URL(this.options.runnerConfig.baseUrl).origin;
    const matches: Frame[] = [];
    for (const frame of page.frames()) {
      if (frameOrigin(frame) === celsiusOrigin) continue;
      const match = await Promise.race([
        frame.evaluate(() => {
          const runtime = window as unknown as { Vars?: Record<string, unknown>; XT?: Record<string, unknown>; CoinManager?: unknown };
          return runtime.CoinManager !== undefined && runtime.Vars !== undefined && typeof runtime.XT?.TriggerEvent === "function";
        }).catch(() => false),
        new Promise<boolean>((resolve) => setTimeout(() => resolve(false), 2_000)),
      ]);
      if (match) matches.push(frame);
    }
    return exactlyOne(matches, "Runtime Pragmatic");
  }

  private async configureHacksaw(config: AutomodConfig): Promise<number> {
    const frame = this.hacksawFrame();
    const amount = frame.locator("#BetAmountValue");
    if ((await amount.count()) !== 1) throw new Error("Montant de mise Hacksaw introuvable.");
    const readableDeadline = this.now() + 15_000;
    let current: number | null = null;
    while (this.now() <= readableDeadline) {
      current = parseCurrencyCents((await amount.textContent()) ?? "");
      if (current !== null) break;
      await frame.page().waitForTimeout(100);
    }
    if (current === null) throw new Error("Mise Hacksaw illisible.");
    for (let step = 0; current !== config.stakeCents && step < 100; step += 1) {
      if (current === null) throw new Error("Mise Hacksaw illisible.");
      const control = frame.locator(current < config.stakeCents ? "#BetAmountIncrease" : "#BetAmountDecrease");
      if ((await control.count()) !== 1) break;
      const reachedLimit = await control.evaluate((element) =>
        element.classList.contains("is-reached") || element.getAttribute("aria-disabled") === "true");
      if (reachedLimit) {
        await this.options.onMilestone?.(`Limite de mise Hacksaw vérifiée: ${current} centimes; réglage demandé ${config.stakeCents} centimes.`);
        break;
      }
      await control.waitFor({ state: "visible", timeout: 15_000 }).catch(() => undefined);
      const enabledDeadline = this.now() + 15_000;
      while (!(await control.isEnabled().catch(() => false)) && this.now() <= enabledDeadline) {
        await frame.page().waitForTimeout(100);
      }
      if (!(await control.isVisible()) || !(await control.isEnabled())) break;
      const before: number = current;
      await control.click({ timeout: 5_000 });
      let next: number | null = before;
      const changeDeadline = this.now() + 2_000;
      while (this.now() <= changeDeadline) {
        next = parseCurrencyCents((await amount.textContent()) ?? "");
        if (next !== null && next !== before) break;
        await frame.page().waitForTimeout(50);
      }
      if (next === null || next === before) {
        const diagnostic = await control.evaluate((element) => ({
          tag: element.tagName,
          className: element.getAttribute("class"),
          disabled: element instanceof HTMLButtonElement ? element.disabled : null,
          ariaDisabled: element.getAttribute("aria-disabled"),
          text: element.textContent?.trim() ?? "",
        })).catch(() => null);
        throw new Error(`Contrôle de mise Hacksaw sans effet depuis ${before} centimes; ${JSON.stringify(diagnostic)}.`);
      }
      if ((config.stakeAtOrBelow===true&&before<=config.stakeCents&&next>config.stakeCents) ||
          (config.stakeAtOrBelow!==true&&Math.abs(next - config.stakeCents) > Math.abs(before - config.stakeCents))) {
        const restore = frame.locator(next > before ? "#BetAmountDecrease" : "#BetAmountIncrease");
        if ((await restore.count()) === 1 && (await restore.isEnabled())) {
          await restore.click();
          await frame.page().waitForTimeout(100);
        }
        current = before;
        break;
      }
      current = next;
    }
    const confirmed = parseCurrencyCents((await amount.textContent()) ?? "");
    if (confirmed === null) throw new Error("Mise Hacksaw finale illisible.");
    if(config.stakeAtOrBelow&&confirmed>config.stakeCents)throw Error('SHOP_STAKE_FLOOR_UNAVAILABLE: minimum supérieur à la mise visée.');
    await this.configureHacksawEnhanced(config, confirmed);
    this.hacksawVerifiedBaseStakeCents = confirmed;
    return confirmed;
  }

  private async configureHacksawEnhanced(config: AutomodConfig, baseStakeCents: number): Promise<void> {
    const frame = this.hacksawFrame();
    const policy = config.enhancedSpins.hacksaw;
    const snapshot = async () => {
      const raw = await frame.evaluate(() => {
      const features = Array.from(document.querySelectorAll(".FeatureBuyItem.FeatureSpinItem")).map((item) => {
        const button = item.querySelector<HTMLButtonElement>("button[data-feature-buy-id-cta]");
        return button === null ? null : {
          id: button.getAttribute("data-feature-buy-id-cta") ?? "",
          description: item.textContent?.replace(/\s+/g, " ").trim() ?? "",
          selected: item.classList.contains("is-selected") || button.getAttribute("aria-pressed") === "true",
        };
      }).filter((value): value is { id: string; description: string; selected: boolean } => value !== null);
      const notice = document.querySelector("#FeatureBuyActiveModifierNotice");
      const noticeStyle = notice instanceof HTMLElement ? getComputedStyle(notice) : null;
      const noticeRect = notice instanceof HTMLElement ? notice.getBoundingClientRect() : null;
      const noticeVisible = notice instanceof HTMLElement && noticeStyle !== null && noticeRect !== null &&
        noticeRect.width > 0 && noticeRect.height > 0 && noticeStyle.display !== "none" &&
        noticeStyle.visibility !== "hidden" && (notice.textContent?.trim().length ?? 0) > 0;
      const toggleText = document.querySelector("#FeatureBuyToggle")?.textContent?.replace(/\s+/g, " ").trim() ?? "";
      const selectedFeature = features.some((feature) => feature.selected);
        return { features, toggleText, selectedFeature, noticeVisible };
      });
      return { ...raw, active: isHacksawEnhancedActive(raw.toggleText, raw.selectedFeature) };
    };
    let state = await snapshot();
    const toggle = frame.locator("#FeatureBuyToggle");
    const menu = frame.locator("#FeatureBuyWindow");
    const openMenu = async () => {
      if (await menu.isVisible().catch(() => false)) return;
      if ((await toggle.count()) !== 1) throw new Error("Menu FeatureSpin Hacksaw absent.");
      await toggle.waitFor({ state: "visible", timeout: 15_000 }).catch(() => undefined);
      if (!(await toggle.isVisible())) throw new Error("Menu FeatureSpin Hacksaw indisponible après 15 secondes.");
      await this.options.onMilestone?.("Golden Hacksaw: ouverture du menu FeatureSpins.");
      await toggle.evaluate((element) => (element as HTMLElement).click());
      await menu.waitFor({ state: "visible", timeout: 3_000 });
    };
    const closeMenu = async () => {
      if (!(await menu.isVisible().catch(() => false))) return;
      if ((await toggle.count()) !== 1) throw new Error("Impossible de fermer le menu FeatureSpin Hacksaw.");
      await toggle.evaluate((element) => (element as HTMLElement).click());
      await menu.waitFor({ state: "hidden", timeout: 3_000 });
    };
    if (!policy.enabled) {
      if (!state.active) { this.hacksawEnhancedActive = false; this.hacksawChargedStakeCents = null; return; }
      // On current Hacksaw UI the active toggle is DISABLE: its first click
      // removes the modifier instead of opening FeatureBuyWindow.
      if (/^disable$/i.test(state.toggleText)) {
        await toggle.evaluate((element) => (element as HTMLElement).click());
        await frame.page().waitForTimeout(500);
        state = await snapshot();
        if (state.active) throw new Error("Golden Bet Hacksaw encore active après DISABLE.");
        this.hacksawEnhancedActive = false;
        this.hacksawChargedStakeCents = null;
        return;
      }
      await openMenu();
      const selected = state.features.filter((feature) => feature.selected);
      if (selected.length !== 1 || selected[0] === undefined) throw new Error("Golden Bet Hacksaw active mais option sélectionnée ambiguë.");
      await frame.locator(`button[data-feature-buy-id-cta="${selected[0].id}"]`).evaluate((element) => (element as HTMLElement).click());
      await frame.page().waitForTimeout(500);
      state = await snapshot();
      if (state.active) throw new Error("Impossible de désactiver la Golden Bet Hacksaw.");
      await closeMenu();
      this.hacksawEnhancedActive = false;
      this.hacksawChargedStakeCents = null;
      return;
    }
    if (state.active) {
      this.hacksawEnhancedActive = true;
      let activeCandidates = state.features
        .map((feature) => ({ ...feature, cost: parseCurrencyCents(feature.description) }))
        .filter((feature) => feature.cost !== null && feature.cost <= policy.maxTotalStakeCents && feature.cost / baseStakeCents <= policy.maxMultiplier)
        .sort((a, b) => Number(b.selected) - Number(a.selected) || (a.cost ?? 0) - (b.cost ?? 0));
      if (activeCandidates.length === 0) {
        await openMenu();
        await frame.page().waitForTimeout(250);
        state = await snapshot();
        activeCandidates = state.features
          .map((feature) => ({ ...feature, cost: parseCurrencyCents(feature.description) }))
          .filter((feature) => feature.cost !== null && feature.cost <= policy.maxTotalStakeCents && feature.cost / baseStakeCents <= policy.maxMultiplier)
          .sort((a, b) => Number(b.selected) - Number(a.selected) || (a.cost ?? 0) - (b.cost ?? 0));
      }
      this.hacksawChargedStakeCents = activeCandidates[0]?.cost ?? null;
      if (this.hacksawChargedStakeCents === null) throw new Error("Golden Bet Hacksaw active mais coût total hors politique ou illisible.");
      await this.options.onMilestone?.(
        `Golden Hacksaw déjà active: coût total ${(this.hacksawChargedStakeCents / 100).toFixed(2)} € confirmé par le contrôle DISABLE/option sélectionnée.`,
      );
      await closeMenu();
      return;
    }
    await openMenu();
    await frame.page().waitForTimeout(500);
    state = await snapshot();
    const candidates = state.features.map((feature) => ({ ...feature, cost: parseCurrencyCents(feature.description) }))
      .filter((feature) => feature.cost !== null && feature.cost <= policy.maxTotalStakeCents && feature.cost / baseStakeCents <= policy.maxMultiplier)
      .sort((a, b) => (a.cost ?? 0) - (b.cost ?? 0));
    const selected = candidates[0];
    if (selected === undefined) {
      await closeMenu();
      this.hacksawEnhancedActive = false;
      this.hacksawChargedStakeCents = null;
      await this.options.onMilestone?.(
        state.features.length === 0
          ? "Golden Hacksaw: aucune option FeatureSpins sur cette machine; mise normale conservée."
          : `Golden Hacksaw: toutes les options dépassent ${policy.maxMultiplier}x/${policy.maxTotalStakeCents} centimes; mise normale conservée.`,
      );
      return;
    }
    const button = frame.locator(`button[data-feature-buy-id-cta="${selected.id}"]`);
    if ((await button.count()) !== 1 || !(await button.isVisible())) throw new Error("Golden Bet Hacksaw choisie non unique.");
    await this.options.onMilestone?.(
      `Golden Hacksaw: sélection de l’option ${selected.id} à ${((selected.cost ?? 0) / 100).toFixed(2)} € total.`,
    );
    await button.evaluate((element) => (element as HTMLElement).click());
    const confirmationDeadline = this.now() + 3_000;
    let confirmed = false;
    while (this.now() <= confirmationDeadline) {
      const okButtons: Locator[] = [];
      for (const candidate of await frame.locator("button").all()) {
        if (!(await candidate.isVisible().catch(() => false)) || !(await candidate.isEnabled().catch(() => false))) continue;
        const text = ((await candidate.textContent().catch(() => "")) ?? "").replace(/\s+/g, " ").trim();
        if (/^ok$/i.test(text)) okButtons.push(candidate);
      }
      if (okButtons.length > 1) throw new Error(`Confirmation Golden Bet Hacksaw ambiguë (${okButtons.length}); aucun clic.`);
      if (okButtons[0] !== undefined) {
        await this.options.onMilestone?.("Golden Hacksaw: confirmation OK.");
        await okButtons[0].evaluate((element) => (element as HTMLElement).click());
        confirmed = true;
        break;
      }
      const interim = await snapshot();
      if (interim.active) { confirmed = true; break; }
      await frame.page().waitForTimeout(100);
    }
    if (!confirmed) throw new Error("Confirmation OK de la Golden Bet Hacksaw introuvable.");
    await frame.page().waitForTimeout(500);
    state = await snapshot();
    if (!state.active) throw new Error("Activation Golden Bet Hacksaw non confirmée.");
    await this.options.onMilestone?.("Golden Hacksaw: activation confirmée par une preuve forte.");
    await closeMenu();
    this.hacksawEnhancedActive = true;
    this.hacksawChargedStakeCents = selected.cost;
  }

  private async configurePragmatic(config: AutomodConfig): Promise<number> {
    const frame = await this.pragmaticFrame();
    const targetEuro = config.stakeCents / 100;
    const readyDeadline = this.now() + 15_000;
    let apiReady = false;
    while (this.now() <= readyDeadline) {
      apiReady = await frame.evaluate(() => {
        const runtime = window as unknown as { HPFUNC?: Record<string, unknown>; CoinManager?: Record<string, unknown> };
        const instance = runtime.CoinManager?.instance;
        return (
          typeof instance === "object" && instance !== null &&
          (typeof runtime.HPFUNC?.setBetToValue === "function" ||
            (typeof runtime.CoinManager?.GetClosestIndices === "function" &&
              typeof (instance as Record<string, unknown>).SetCoinAndBetIndex === "function"))
        );
      }).catch(() => false);
      if (apiReady) break;
      await frame.page().waitForTimeout(250);
    }
    if (!apiReady) throw new Error("API de mise Pragmatic non initialisée après 15 secondes.");
    // Une option Ante/Golden peut survivre à une ancienne session. Revenir
    // d'abord à la mise normale évite de confondre base 0,20 € et débit 0,25 €.
    await this.configurePragmaticEnhanced(config, frame, false, false);
    const applied = await frame.evaluate((target) => {
      const runtime = window as unknown as {
        HPFUNC?: Record<string, unknown>;
        CoinManager?: Record<string, unknown>;
        Vars?: Record<string, unknown>;
        XT?: { GetDouble?: (...args: unknown[]) => unknown };
      };
      const manager = runtime.CoinManager;
      const instance = manager?.instance;
      if (manager === undefined || typeof instance !== "object" || instance === null) return false;
      const instanceRecord = instance as Record<string, unknown>;
      const direct = runtime.HPFUNC?.setBetToValue;
      if (typeof direct === "function") {
        Reflect.apply(direct, runtime.HPFUNC, [target]);
        return true;
      }
      const closest = manager.GetClosestIndices;
      const setIndices = instanceRecord.SetCoinAndBetIndex;
      if (typeof closest !== "function" || typeof setIndices !== "function") return false;
      const pair = Reflect.apply(closest, manager, [target]) as Record<string, unknown> | null;
      if (typeof pair?.coinIndex !== "number" || typeof pair.betIndex !== "number") return false;
      Reflect.apply(setIndices, instanceRecord, [pair.coinIndex, pair.betIndex]);
      return true;
    }, targetEuro);
    if (!applied) throw new Error("API sémantique de mise Pragmatic indisponible.");
    await frame.page().waitForTimeout(500);
    let confirmed = await this.readPragmaticTotalBetCents(frame);
    if(config.stakeAtOrBelow && confirmed!==null && confirmed>config.stakeCents){
      // The native "closest" setter can round upwards. Paid boosts promise a ceiling.
      for(let attempts=0;confirmed>config.stakeCents&&attempts<32;attempts++){
        const previous=confirmed;
        const decreased=await frame.evaluate(()=>{
          const manager=(window as unknown as {CoinManager?:{instance?:Record<string,unknown>}}).CoinManager?.instance;
          const method=manager?.SmartDecreaseBet??manager?.DecreaseBet;
          if(!manager||typeof method!=='function')return false;
          Reflect.apply(method,manager,[]);return true;
        });
        if(!decreased)throw Error('SHOP_STAKE_FLOOR_UNAVAILABLE: aucun palier inférieur vérifiable.');
        await frame.page().waitForTimeout(150);
        confirmed=await this.readPragmaticTotalBetCents(frame);
        if(confirmed===null||confirmed>=previous)throw Error('SHOP_STAKE_FLOOR_UNCONFIRMED: diminution de mise non confirmée.');
      }
      if(confirmed>config.stakeCents)throw Error('SHOP_STAKE_FLOOR_UNCONFIRMED: plafond de mise dépassé.');
    }
    if (confirmed === null) {
      const diagnostic = await frame.evaluate(() => {
        const runtime = window as unknown as { HPVARS?: Record<string, unknown>; CoinManager?: Record<string, unknown> };
        const manager = runtime.CoinManager ?? {};
        const pair = manager.lastIndicesPair;
        const safePair = typeof pair === "object" && pair !== null
          ? Object.fromEntries(Object.entries(pair).filter(([, value]) => typeof value === "number"))
          : null;
        return {
          anteBetIdx: runtime.HPVARS?.anteBetIdx ?? null,
          anteBetOptionsCount: runtime.HPVARS?.anteBetOptionsCount ?? null,
          lastBet: manager.lastBet ?? null,
          lastTotalBet: manager.lastTotalBet ?? null,
          desiredBet: manager.desiredBet ?? null,
          desiredBetIndex: manager.desiredBetIndex ?? null,
          desiredCoinIndex: manager.desiredCoinIndex ?? null,
          lastIndicesPair: safePair,
        };
      });
      throw new Error(`Mise Pragmatic illisible après sélection du palier proche; ${JSON.stringify(diagnostic)}.`);
    }
    const requestedPolicy = config.enhancedSpins.pragmatic;
    const anteIndexAfterBet = await frame.evaluate(() => {
      const hp = (window as unknown as { HPVARS?: Record<string, unknown> }).HPVARS;
      return typeof hp?.anteBetIdx === "number" ? hp.anteBetIdx : -1;
    });
    const displayedRatioToTarget = confirmed / config.stakeCents;
    if (
      requestedPolicy.enabled &&
      anteIndexAfterBet >= 0 &&
      confirmed > config.stakeCents &&
      displayedRatioToTarget <= requestedPolicy.maxMultiplier &&
      confirmed <= requestedPolicy.maxTotalStakeCents
    ) {
      // Certains builds appliquent l'Ante Bet directement via setBetToValue
      // avant d'hydrater betLevelManager. Le total majoré est alors la preuve
      // positive uniquement avec un index Ante réellement actif.
      return config.stakeCents;
    }
    try {
      await this.configurePragmaticEnhanced(config, frame, undefined, true, confirmed);
    } catch (error) {
      if (!requestedPolicy.enabled) throw error;
      if(String(error).includes("PRAGMATIC_ANTE_RESTORE_UNCONFIRMED"))throw error;
      await this.options.onMilestone?.(
        `Golden Pragmatic indisponible ou hors plafond: ${error instanceof Error ? error.message : String(error)} ` +
        `Fallback sécurisé à la mise normale ${(confirmed / 100).toFixed(2)} €.`
      );
    }
    return confirmed;
  }

  private async readPragmaticTotalBetCents(frame: Frame): Promise<number | null> {
    const value = await frame.evaluate(() => {
      const runtime = window as unknown as { Vars?: Record<string, unknown>; XT?: { GetDouble?: (...args: unknown[]) => unknown }; CoinManager?: Record<string, unknown> };
      const key = runtime.Vars?.TotalBetDisplayed ?? "TotalBetDisplayed";
      const getter = runtime.XT?.GetDouble;
      const result = typeof key === "string" && typeof getter === "function" ? Reflect.apply(getter, runtime.XT, [key]) : runtime.CoinManager?.lastTotalBet;
      return typeof result === "number" && Number.isFinite(result) ? result : null;
    });
    return euroToCents(value);
  }

  private async configurePragmaticEnhanced(
    config: AutomodConfig,
    frame: Frame,
    enabledOverride?: boolean,
    verifyCost = true,
    baseStakeCents = config.stakeCents,
  ): Promise<void> {
    const configuredPolicy = config.enhancedSpins.pragmatic;
    const policy = { ...configuredPolicy, enabled: enabledOverride ?? configuredPolicy.enabled };
    if (policy.enabled) await this.options.onMilestone?.("Golden Pragmatic: sélection demandée.");
    const nativeRead = (enabled=policy.enabled,apply=false) => frame.evaluate<ReturnType<typeof pragmaticNativeAnte>>(`(${pragmaticNativeAnte.toString()})(window,${enabled},${baseStakeCents},${policy.maxMultiplier},${policy.maxTotalStakeCents},${apply})`);
    let native = await nativeRead();
    if(native.found){
      const deadline=this.now()+8_000;
      while(!native.ready&&native.error===null&&this.now()<deadline){await frame.page().waitForTimeout(200);native=await nativeRead();}
      if(native.error!==null||!native.ready)throw new Error(native.error??"Extra Chance natif encore bloqué; aucune activation forcée.");
      native=await nativeRead(policy.enabled,true);
      if(!native.ready||native.index!==native.target)throw new Error("Index Extra Chance natif non confirmé.");
      if(verifyCost){
        await frame.page().waitForTimeout(300);
        const charged=await this.readPragmaticTotalBetCents(frame);
        const expected=Math.round(baseStakeCents*(native.multiplier??1));
        if(charged!==expected){
          const reverted=await nativeRead(false,true);
          if(!reverted.ready||reverted.index!==0)throw new Error("PRAGMATIC_ANTE_RESTORE_UNCONFIRMED: coût Extra Chance non confirmé et retour normal non confirmé; aucun spin.");
          throw new Error(`Coût Extra Chance non confirmé (${charged}, attendu ${expected}); mode normal restauré.`);
        }
      }
      if(policy.enabled)await this.options.onMilestone?.(`Golden Pragmatic natif: Extra Chance confirmé, ×${native.multiplier}, coût ${(Math.round(baseStakeCents*(native.multiplier??1))/100).toFixed(2)} €.`);
      return;
    }
    const availability = await frame.evaluate(() => {
      const runtime = window as unknown as {
        HPVARS?: Record<string, unknown>;
        Vars?: Record<string, unknown>;
        XT?: { GetBool?: (...args: unknown[]) => unknown };
      };
      const hp = runtime.HPVARS ?? {};
      const vars = runtime.Vars ?? {};
      const key = vars.HasAnteBet ?? "HasAnteBet";
      let hasAnteBet: boolean | null = null;
      if (typeof key === "string" && typeof runtime.XT?.GetBool === "function") {
        try {
          const value = Reflect.apply(runtime.XT.GetBool, runtime.XT, [key]);
          if (typeof value === "boolean") hasAnteBet = value;
        } catch {
          hasAnteBet = null;
        }
      }
      return {
        hasAnteBet,
        optionCount: typeof hp.anteBetOptionsCount === "number" ? hp.anteBetOptionsCount : null,
        index: typeof hp.anteBetIdx === "number" ? hp.anteBetIdx : null,
      };
    });
    // Les builds actuels de Fruit Party, Gates et Power of Thor exposent les
    // API génériques Ante Bet, mais déclarent explicitement qu'aucune option
    // n'est disponible. Attendre betLevelManager dans ce cas ajoutait 15 s et
    // transformait une absence normale en fausse erreur Golden. Ne jamais
    // cliquer le panneau Buy Free Spins pour compenser cette absence.
    if (availability.optionCount === 0 && availability.index === -1) {
      if (policy.enabled) await this.options.onMilestone?.("Golden Pragmatic: aucune option de spin majoré sur cette machine; mise normale conservée.");
      return;
    }
    const desiredIndex = policy.enabled ? 0 : -1;
    const readinessDeadline = this.now() + 15_000;
    let readyToChange = false;
    let alreadySet = false;
    while (this.now() <= readinessDeadline) {
      const readiness = await frame.evaluate((desired) => {
        const rt = window as unknown as { HPVARS?: Record<string, unknown>; Vars?: Record<string, unknown>; XT?: {GetBool(key:string):unknown} };
        const hpvars = rt.HPVARS ?? {};
        const vars = rt.Vars ?? {};
        const canSpin = typeof vars.Logic_CanSpin === "string" && rt.XT?.GetBool(vars.Logic_CanSpin) === true;
        const notBusy = typeof vars.Logic_IsSpinInProgress === "string" && rt.XT?.GetBool(vars.Logic_IsSpinInProgress) === false;
        const current = typeof hpvars.anteBetIdx === "number" ? hpvars.anteBetIdx : null;
        return {
          alreadySet: current === desired,
          ready: hpvars.betLevelManager !== undefined && (hpvars.afterRoundEnd === true || canSpin && notBusy && hpvars.playingFreeSpins !== true),
        };
      }, desiredIndex);
      alreadySet = readiness.alreadySet;
      readyToChange = readiness.ready;
      if (alreadySet || readyToChange) break;
      await frame.page().waitForTimeout(250);
    }
    if (!alreadySet && !readyToChange) {
      const diagnostic = await frame.evaluate(() => {
        const hp = (window as unknown as { HPVARS?: Record<string, unknown> }).HPVARS ?? {};
        const manager = hp.betLevelManager;
        const options = hp.betLevelOptions;
        return {
          afterRoundEnd: hp.afterRoundEnd ?? null,
          anteBetIdx: hp.anteBetIdx ?? null,
          anteBetOptionsCount: hp.anteBetOptionsCount ?? null,
          anteBetLabels: Array.isArray(hp.anteBetLabels) ? hp.anteBetLabels.slice(0, 10) : null,
          anteBetDesc: Array.isArray(hp.anteBetDesc) ? hp.anteBetDesc.slice(0, 10) : null,
          betLevelToggle: hp.betLevelToggle ?? null,
          mustSetAnteBet: hp.mustSetAnteBet ?? null,
          betLevelOptionsLength: Array.isArray(options) ? options.length : null,
          betLevelOptionKeys: Array.isArray(options)
            ? options.slice(0, 10).map((option) => typeof option === "object" && option !== null ? Object.getOwnPropertyNames(option).slice(0, 50) : [])
            : [],
          betLevelManagerKeys: typeof manager === "object" && manager !== null ? Object.getOwnPropertyNames(manager).slice(0, 80) : [],
          betLevelManagerPrototypeKeys: typeof manager === "object" && manager !== null
            ? Object.getOwnPropertyNames(Object.getPrototypeOf(manager) as object).slice(0, 80)
            : [],
        };
      });
      throw new Error(`Golden Bet Pragmatic non modifiable avant round; ${JSON.stringify(diagnostic)}.`);
    }
    const result = await frame.evaluate(({ enabled, maxMultiplier, baseStakeEuro }) => {
      const runtime = window as unknown as { HPFUNC?: Record<string, unknown>; HPVARS?: Record<string, unknown>; UHTInterfaceBOSS?: Record<string, unknown>; CoinManager?: Record<string, unknown> };
      const hpvars = runtime.HPVARS ?? {};
      const current = typeof hpvars.anteBetIdx === "number" ? hpvars.anteBetIdx : 0;
      const count = typeof hpvars.anteBetOptionsCount === "number" ? hpvars.anteBetOptionsCount : 0;
      const desired = enabled ? (count >= 0 ? 0 : null) : -1;
      if (desired === null) return { ok: false, reason: "Aucune option Golden Bet Pragmatic annoncée." };
      if (current === desired) return { ok: true, changed: false };
      const owners = [runtime.HPFUNC, runtime.UHTInterfaceBOSS, runtime.CoinManager?.instance as Record<string, unknown> | undefined];
      const allowedNames = /^(?:set|select|change|toggle).*(?:ante|enhanced|golden).*$/i;
      const discovered = owners.flatMap((owner) => {
        if (owner === undefined) return [];
        const names = new Set<string>();
        let cursor: object | null = owner;
        for (let depth = 0; depth < 3 && cursor !== null; depth += 1) {
          for (const name of Object.getOwnPropertyNames(cursor)) names.add(name);
          cursor = Object.getPrototypeOf(cursor) as object | null;
        }
        return [...names]
          .filter((name) => allowedNames.test(name) && typeof owner[name] === "function")
          .map((name) => ({ owner, name, fn: owner[name] as (...args: unknown[]) => unknown }));
      });
      const exact = discovered.filter((method) => method.name.toLowerCase() === "setantebet");
      const methods = exact.length > 0 ? exact : discovered.filter((method) => !/color|collider/i.test(method.name));
      if (methods.length !== 1 || methods[0] === undefined) {
        return { ok: false, reason: `Contrôle Golden Bet Pragmatic non unique (${methods.map((item) => item.name).join(",")}).` };
      }
      Reflect.apply(methods[0].fn, methods[0].owner, [desired]);
      void maxMultiplier;
      void baseStakeEuro;
      return { ok: true, changed: true, method: methods[0].name };
    }, { enabled: policy.enabled, maxMultiplier: policy.maxMultiplier, baseStakeEuro: config.stakeCents / 100 });
    if (!result.ok) throw new Error(result.reason);
    let confirmedIndex: number | null = null;
    const confirmationDeadline = this.now() + 5_000;
    while (this.now() <= confirmationDeadline) {
      confirmedIndex = await frame.evaluate(() => {
        const hpvars = (window as unknown as { HPVARS?: Record<string, unknown> }).HPVARS;
        return typeof hpvars?.anteBetIdx === "number" ? hpvars.anteBetIdx : null;
      });
      if (confirmedIndex === desiredIndex) break;
      await frame.page().waitForTimeout(100);
    }
    if (confirmedIndex !== desiredIndex) {
      const methodDiagnostic = await frame.evaluate(() => {
        const runtime = window as unknown as { HPFUNC?: Record<string, unknown>; UHTInterfaceBOSS?: Record<string, unknown>; CoinManager?: Record<string, unknown> };
        for (const owner of [runtime.HPFUNC, runtime.UHTInterfaceBOSS, runtime.CoinManager?.instance as Record<string, unknown> | undefined]) {
          const fn = owner?.setAnteBet;
          if (typeof fn === "function") return { length: fn.length, source: Function.prototype.toString.call(fn).slice(0, 500) };
        }
        return null;
      });
      throw new Error(`Index Golden Bet Pragmatic non confirmé (${confirmedIndex ?? "illisible"}, attendu ${desiredIndex}); ${JSON.stringify(methodDiagnostic)}.`);
    }
    if (policy.enabled) {
      await this.options.onMilestone?.(
        `Golden Pragmatic: activation confirmée${"method" in result && result.method ? ` via ${result.method}` : ""}.`,
      );
    }
    if (!verifyCost) return;
    const total = await this.readPragmaticTotalBetCents(frame);
    if (total === null) throw new Error("Coût total Pragmatic illisible après réglage Golden Bet.");
    const multiplier = total / baseStakeCents;
    if (policy.enabled && (multiplier <= 1 || multiplier > policy.maxMultiplier || total > policy.maxTotalStakeCents)) {
      throw new Error(`Golden Bet Pragmatic ${multiplier}x hors plafond ${policy.maxMultiplier}x.`);
    }
    if (!policy.enabled && multiplier > 1) throw new Error(`Golden Bet Pragmatic encore active (${multiplier}x).`);
  }

  private async readHacksaw(): Promise<HacksawSnapshot> {
    const frame = this.hacksawFrame();
    await this.skipHacksawWinPresentationIfActive(frame);
    const raw = await frame.evaluate<{
      providerState: string | null;
      counterVisible: boolean;
      counterValue: number | null;
      totalWinVisible: boolean;
      totalWinText: string;
      balanceText: string;
      idle: boolean;
      autoplayActive: boolean;
      autoplayRemaining: number | null;
      autoplayButtonDisabled: boolean;
      blockingDialogVisible: boolean;
      blockingDialogText?: string;
      lastWinText: string;
    }>(HACKSAW_SNAPSHOT_EXPRESSION);
    if (raw.blockingDialogVisible && /connection lost to wallet|wallet.{0,30}(?:disconnected|connection lost)/i.test(raw.blockingDialogText ?? "")) {
      throw new Error("HACKSAW_WALLET_DISCONNECTED: connexion fournisseur au wallet perdue ; aucun bonus ni gain déduit de ce dialogue.");
    }
    // A hidden/partial TOTAL WIN can belong to an earlier feature. Only the
    // native final recap is authoritative for this bonus's total.
    const gainCents = raw.totalWinVisible && /^featureExit(?:-[a-z0-9_-]+)?$/i.test(raw.providerState ?? "")
      ? parseCurrencyCents(raw.totalWinText) : null;
    const nativeFeatureStopped = this.nativeAutoplay && !this.nativeAutoplayStopRequested && !raw.autoplayActive;
    const shouldProbeCanvasGamble = raw.idle && !raw.blockingDialogVisible && !raw.totalWinVisible &&
      (this.spinPending || nativeFeatureStopped || this.hacksawBonusPurchasePending || this.hacksawGambleOffer !== null);
    if (shouldProbeCanvasGamble && this.now() - this.hacksawGambleOcrAt >= 750) {
      this.hacksawGambleOcrAt = this.now();
      const canvases: Array<{ canvas: Locator; area: number }> = [];
      for (const canvas of await frame.locator("#GameWrapper canvas").all()) {
        if (!(await canvas.isVisible().catch(() => false))) continue;
        const box = await canvas.boundingBox();
        if (box !== null && box.width > 0 && box.height > 0) canvases.push({ canvas, area: box.width * box.height });
      }
      canvases.sort((left, right) => right.area - left.area);
      const image = (canvases[0] ? await captureCanvasSnapshot(canvases[0].canvas).catch(() => null) : null);
      this.hacksawGambleOffer = image === null ? null : await findHacksawGambleOffer(image).catch(() => null);
      if (this.hacksawGambleOffer !== null) {
        await this.options.onMilestone?.("Gamble Hacksaw canvas détecté; choix garanti FREE SPINS requis.");
      }
    }
    const gambleActive = this.hacksawGambleOffer !== null;
    return {
      providerState: raw.providerState,
      counterValue: raw.counterValue,
      totalWinVisible: raw.totalWinVisible,
      idle: raw.idle && !gambleActive,
      balanceCents: parseCurrencyCents(raw.balanceText),
      // Hacksaw conserve parfois le dernier compteur (ex. 999) dans le DOM
      // après l'arrêt. Seul le contrôle STOP visible prouve que l'autoplay est
      // encore actif; le compteur seul ne doit jamais maintenir une fausse boucle.
      autoplayActive: raw.autoplayActive,
      autoplayRemaining: raw.autoplayRemaining,
      autoplayButtonDisabled: raw.autoplayButtonDisabled,
      blockingDialogVisible: raw.blockingDialogVisible || gambleActive,
      lastSpinWinCents: parseCurrencyCents(raw.lastWinText),
      bonus: gambleActive ? { active: true, gainCents: null } : hacksawBonusSignal({
        counterVisible: raw.counterVisible,
        counterValue: raw.counterValue,
        totalWinCents: gainCents,
        totalWinVisible: raw.totalWinVisible,
        providerState: raw.providerState,
        recapCollected: this.bonusCollectAdvanced,
      }, this.previousBonus),
    };
  }

  private async skipHacksawWinPresentationIfActive(frame: Frame): Promise<void> {
    const episode = await readHacksawWinEpisode(frame);
    if (episode?.active) {
      if (this.hacksawWinSkipInFlight) return;
      this.hacksawWinSkipInFlight = true;
      try {
        if (!await cancelHacksawWinEpisode(frame, episode)) return;
        const deadline = this.now() + 5_000;
        while (this.now() <= deadline) {
          const current = await readHacksawWinEpisode(frame);
          if (current?.bridgeId !== episode.bridgeId) throw new Error("Hacksaw: contexte du gain remplacé pendant le skip.");
          if (current.completedEpisode >= episode.episode) {
            // Never use the stale HUD of the preceding spin as this gain.
            this.pendingWinGains.push({ id: randomUUID(), gainCents: hacksawCompletedWinCents(current, this.hacksawVerifiedBaseStakeCents), source: "hacksaw-win-count-completed" });
            await this.options.onMilestone?.(`Décompte de gain Hacksaw accéléré via cancelWinAnimation; fin du décompte confirmée pour l’épisode ${episode.episode} (${current.completion}); durée observée ${current.completedAt === null ? "inconnue" : current.completedAt - current.startedAt} ms, durée native annoncée ${current.nativeDurationSeconds ?? "inconnue"} s, ${current.requestCount} commande(s).`);
            return;
          }
          if (current.episode !== episode.episode) throw new Error("Hacksaw: épisode de gain remplacé pendant le skip.");
          // The native count-up ignores input during tier entrance pauses.
          // Retry only this verified episode, at most 16 times / 5 seconds.
          await cancelHacksawWinEpisode(frame, current);
          await frame.page().waitForTimeout(50);
        }
        throw new Error("Hacksaw: skip envoyé mais fin de l’animation non confirmée par le moteur après 5 secondes.");
      } finally { this.hacksawWinSkipInFlight = false; }
    }
    if (episode && episode.episode > 0) return;
    const state = await frame.locator("#hacksaw-casino").getAttribute("data-state").catch(() => null);
    if (!isHacksawWinPresentationState(state)) {
      this.hacksawWinSkipInFlight = false;
      return;
    }
    if (this.hacksawWinSkipInFlight) return;
    this.hacksawWinSkipInFlight = true;
    const published = await frame.evaluate(() => {
      const runtime = window as unknown as {
        hacksawCasino?: { PubSub?: { getChannel?: (name: string) => { publish?: (event: string) => unknown } } };
      };
      const channel = runtime.hacksawCasino?.PubSub?.getChannel?.("ui");
      if (typeof channel?.publish !== "function") return false;
      channel.publish("cancelWinAnimation");
      return true;
    }).catch(() => false);
    if (!published) {
      this.hacksawWinSkipInFlight = false;
      throw new Error("Hacksaw: état winPresentation détecté mais canal sémantique cancelWinAnimation absent.");
    }
    const deadline = this.now() + 5_000;
    while (this.now() <= deadline) {
      const next = await frame.locator("#hacksaw-casino").getAttribute("data-state").catch(() => null);
      if (next !== null && /^(?:idle|autoplay|autoplayEnd|gameRoundEnter|play|gameRoundPlay|gameRoundEnd|gameRoundExit)$/i.test(next)) {
        this.hacksawWinSkipInFlight = false;
        const first = await frame.evaluate<{ lastWinText?: string; counterValue?: number | null }>(HACKSAW_SNAPSHOT_EXPRESSION);
        await frame.page().waitForTimeout(50);
        const second = await frame.evaluate<{ lastWinText?: string; counterValue?: number | null }>(HACKSAW_SNAPSHOT_EXPRESSION);
        const amount = parseCurrencyCents(first.lastWinText ?? "");
        this.pendingWinGains.push({ id: randomUUID(), gainCents: amount !== null && amount > 0 && amount === parseCurrencyCents(second.lastWinText ?? "") && first.counterValue === second.counterValue ? amount : null, source: "hacksaw-dom-after-skip" });
        await this.options.onMilestone?.("Animation Big Win Hacksaw ignorée via cancelWinAnimation; fin de présentation confirmée.");
        return;
      }
      await frame.page().waitForTimeout(50);
    }
    this.hacksawWinSkipInFlight = false;
    throw new Error("Hacksaw: cancelWinAnimation envoyé mais présentation toujours active après 5 secondes.");
  }

  private async readPragmatic(timeoutMs = 4_000, knownFrame?: Frame): Promise<PragmaticSnapshot> {
    const frame = knownFrame ?? await this.pragmaticFrame();
    let timer: ReturnType<typeof setTimeout> | undefined;
    const raw = await Promise.race([frame.evaluate<{
      playingFreeSpins: boolean;
      logicIsFreeSpin: boolean;
      freeSpinsLeft: number;
      responseSignals: boolean;
      totalWin: number | null;
      totalWinAuthoritative: boolean;
      ready: boolean | null;
      busy: boolean | null;
      resultSignature: string;
      telemetryCount: number;
      autoplayActive: boolean;
      autoplayRemaining: number | null;
      lastSpinWin: number | null;
      presentationWin: number | null;
      winPresentationCandidate: boolean;
      winPresentationRuntimeKnown: boolean;
      spinResultIsBigWin: boolean | null;
      waitInResultForBigWin: boolean | null;
      bigWinLevel: number | null;
      blockingDialogVisible: boolean | null;
      gambleActive: boolean | null;
      customBonusCollectPending: boolean;
    }>(PRAGMATIC_SNAPSHOT_EXPRESSION), new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error("Lecture du runtime Pragmatic hors délai.")), Math.max(1, timeoutMs));
    })]).finally(() => clearTimeout(timer));
    return {
      bonus: raw.customBonusCollectPending ? { active: true, gainCents: null } : pragmaticBonusSignal({
        playingFreeSpins: raw.playingFreeSpins,
        logicIsFreeSpin: raw.logicIsFreeSpin,
        freeSpinsLeft: raw.freeSpinsLeft,
        responseSignalsFreeSpins: raw.responseSignals,
        // Un compteur *WinDisplayed peut encore monter: seule la réponse fournisseur est finale.
        totalWinCents: raw.totalWinAuthoritative ? euroToCents(raw.totalWin) : null,
        finalResultConfirmed: raw.totalWinAuthoritative,
        readyToSpin: raw.ready,
        spinBusy: raw.busy,
      }, this.previousBonus),
      playingFreeSpins: raw.playingFreeSpins,
      freeSpinsLeft: raw.freeSpinsLeft,
      readyToSpin: raw.ready,
      spinBusy: raw.busy,
      resultSignature: raw.resultSignature || null,
      telemetryCount: raw.telemetryCount,
      autoplayActive: raw.autoplayActive,
      autoplayRemaining: raw.autoplayRemaining,
      lastSpinWinCents: euroToCents(raw.lastSpinWin),
      presentationWinCents: euroToCents(raw.presentationWin),
      winPresentationCandidate: raw.winPresentationCandidate,
      winPresentationRuntimeKnown: raw.winPresentationRuntimeKnown,
      spinResultIsBigWin: raw.spinResultIsBigWin,
      waitInResultForBigWin: raw.waitInResultForBigWin,
      bigWinLevel: raw.bigWinLevel,
      blockingDialogVisible: raw.blockingDialogVisible,
      gambleActive: raw.gambleActive,
      customBonusCollectPending: raw.customBonusCollectPending,
    };
  }

  private pragmaticWinProgress(snapshot: PragmaticSnapshot): string {
    return JSON.stringify([snapshot.autoplayRemaining, snapshot.freeSpinsLeft, snapshot.playingFreeSpins, snapshot.bonus.active, snapshot.telemetryCount]);
  }

  private pragmaticWinContextCurrent(): boolean {
    const context = this.pragmaticWinContext;
    return context !== null && !context.cancelled && context.generation === this.pragmaticWinGeneration && this.provider === "pragmatic" && this.gamePage === context.page && !context.page.isClosed() && !context.frame.isDetached() && Date.now() <= context.deadline;
  }

  private async findPragmaticWinCanvas(frame: Frame): Promise<Locator | null> {
    const canvases: Array<{ canvas: Locator; area: number }> = [];
    for (const canvas of await frame.locator("canvas").all()) {
      if (!(await canvas.isVisible().catch(() => false))) continue;
      const box = await canvas.boundingBox();
      if (box !== null && box.width > 0 && box.height > 0) canvases.push({ canvas, area: box.width * box.height });
    }
    canvases.sort((left, right) => right.area - left.area);
    const largest = canvases[0];
    return largest === undefined || (canvases[1]?.area ?? 0) === largest.area ? null : largest.canvas;
  }

  private async readPragmaticWinPresentation(): Promise<WinObservation> {
    const context = this.pragmaticWinContext;
    if (context === null || !this.pragmaticWinContextCurrent()) return { kind: "unknown", reason: "stale-game-or-deadline" };
    const current = await this.readPragmatic(Math.min(1_500, context.deadline - Date.now()), context.frame);
    if (!this.pragmaticWinContextCurrent()) return { kind: "unknown", reason: "stale-runtime-read" };
    this.pragmaticWinLatestSnapshot = current;
    const baseline = this.pragmaticWinEpisodeReference;
    const progressed = baseline !== null && (
      (baseline.autoplayRemaining !== null && current.autoplayRemaining !== null && current.autoplayRemaining < baseline.autoplayRemaining && (current.spinBusy === true || current.readyToSpin === true)) ||
      (current.freeSpinsLeft < baseline.freeSpinsLeft && current.bonus.active && current.playingFreeSpins)
    );
    if (current.winPresentationRuntimeKnown && current.winPresentationCandidate) {
      this.pragmaticWinCanvas = await this.findPragmaticWinCanvas(context.frame);
      if (this.pragmaticWinCanvas === null || !this.pragmaticWinContextCurrent()) return { kind: "unknown", reason: "provider-win-canvas-unavailable" };
      return { kind: "win", tier: "PROVIDER", amountText: "runtime-confirmed" };
    }
    const knownPresentationEnded = baseline?.winPresentationRuntimeKnown === true && baseline.waitInResultForBigWin === true && current.winPresentationRuntimeKnown && current.waitInResultForBigWin === false;
    if (this.pragmaticWinHolding && knownPresentationEnded && current.blockingDialogVisible === false && current.gambleActive !== true) {
      return { kind: "absent", reason: "provider-wait-true-to-false-confirmed" };
    }
    const presentationFlagEnded = current.winPresentationRuntimeKnown ? current.waitInResultForBigWin === false : !current.winPresentationCandidate;
    if (this.pragmaticWinHolding && presentationFlagEnded && current.blockingDialogVisible === false && current.gambleActive !== true && ((current.readyToSpin === true && current.spinBusy === false) || progressed)) {
      return { kind: "absent", reason: progressed ? "provider-round-progress-confirmed" : "provider-ready-without-win-presentation" };
    }
    if (this.pragmaticWinHolding && current.winPresentationRuntimeKnown && current.waitInResultForBigWin === false && current.blockingDialogVisible === false && current.gambleActive !== true && this.previousBonus.active && !current.bonus.active && !current.playingFreeSpins && current.freeSpinsLeft === 0 && current.bonus.gainCents !== null && current.spinBusy !== true) {
      return { kind: "blocked", reason: "provider-bonus-recap", clearEvidence: "provider-finished-bonus-with-readable-total" };
    }
    if (current.winPresentationRuntimeKnown) return this.pragmaticWinHolding ? { kind: "unknown", reason: "provider-presentation-exit-not-yet-confirmed" } : { kind: "absent", reason: "provider-presentation-not-active" };
    const canvas = await this.findPragmaticWinCanvas(context.frame);
    if (canvas === null || !this.pragmaticWinContextCurrent()) return { kind: "unknown", reason: "game-canvas-not-unique" };
    this.pragmaticWinCanvas = canvas;
    const image = await captureCanvasSnapshot(canvas);
    if (!this.pragmaticWinContextCurrent()) return { kind: "unknown", reason: "stale-capture" };
    const observation = await readWinPresentation(image);
    return this.pragmaticWinContextCurrent() ? observation : { kind: "unknown", reason: "stale-ocr" };
  }

  private async canSkipPragmaticWinPresentation(): Promise<boolean> {
    const context = this.pragmaticWinContext, baseline = this.pragmaticWinReference;
    if (context === null || baseline === null || !this.pragmaticWinContextCurrent()) return false;
    const current = await this.readPragmatic(Math.min(1_500, context.deadline - Date.now()), context.frame);
    if (this.pragmaticWinContextCurrent()) this.pragmaticWinLatestSnapshot = current;
    this.pragmaticWinAudit = { providerProof: current.winPresentationRuntimeKnown, spinResultIsBigWin: current.spinResultIsBigWin, waitInResultForBigWin: current.waitInResultForBigWin, bigWinLevel: current.bigWinLevel, ready: current.readyToSpin, busy: current.spinBusy, gamble: current.gambleActive, dialog: current.blockingDialogVisible };
    const proof = current.winPresentationRuntimeKnown ? current.winPresentationCandidate && current.gambleActive !== true : current.readyToSpin === false && current.gambleActive === false;
    return this.pragmaticWinContextCurrent() && proof && current.blockingDialogVisible === false && this.pragmaticWinProgress(current) === this.pragmaticWinProgress(baseline);
  }

  private async clickPragmaticWinPresentation(): Promise<void> {
    const context = this.pragmaticWinContext, canvas = this.pragmaticWinCanvas;
    if (context === null || canvas === null || !this.pragmaticWinContextCurrent()) throw new Error("Clic Big Win Pragmatic expiré ou jeu remplacé.");
    const dimensions = await canvas.evaluate(element => ({ width: element.clientWidth, height: element.clientHeight }), undefined, { timeout: 500 });
    if (dimensions.width <= 0 || dimensions.height <= 0 || !this.pragmaticWinContextCurrent()) throw new Error("Clic Big Win Pragmatic refusé: canvas absent ou délai dépassé.");
    // Le budget est revérifié après les lectures asynchrones; aucun clic différé après recovery.
    await canvas.click({ position: { x: dimensions.width / 2, y: dimensions.height / 2 }, timeout: Math.max(1, Math.min(1_000, context.deadline - Date.now())) });
    await this.parkPresentationPointer(true);
  }

  private async inspectPragmaticWinPresentation(snapshot: PragmaticSnapshot, observeStartedAt: number): Promise<WinPresentationResult> {
    const progress = this.pragmaticWinProgress(snapshot);
    if (progress !== this.pragmaticWinProgressKey) { this.pragmaticWinProgressKey = progress; this.pragmaticWinProgressAt = this.now(); }
    const candidate = snapshot.winPresentationCandidate || (!snapshot.winPresentationRuntimeKnown && snapshot.readyToSpin === false && this.now() - this.pragmaticWinProgressAt >= 3_000);
    if (this.pragmaticWinTickPending) throw new Error("OCR Pragmatic précédent encore en cours; aucune action supplémentaire.");
    if (this.pragmaticWinHoldingSince !== null && Date.now() - this.pragmaticWinHoldingSince >= 30_000) throw new Error("PRAGMATIC_WIN_PRESENTATION_UNRESOLVED: disparition non prouvée après 30 secondes; gain non validé.");
    this.pragmaticWinReference = snapshot;
    this.pragmaticWinLatestSnapshot = snapshot;
    const context = { generation: this.pragmaticWinGeneration, page: this.requireGamePage(), frame: await this.pragmaticFrame(), deadline: observeStartedAt + 10_000, cancelled: false };
    this.pragmaticWinContext = context;
    this.pragmaticWinTickPending = true;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const pending = this.pragmaticWinSkipper.tick({ candidate }).finally(() => { this.pragmaticWinTickPending = false; });
    try {
      const result = await Promise.race([pending, new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => { context.cancelled = true; reject(new Error("Budget de lecture Big Win Pragmatic dépassé; aucun clic tardif autorisé.")); }, Math.max(1, observeStartedAt + 12_000 - Date.now()));
      })]);
      if (context.generation !== this.pragmaticWinGeneration || context.page !== this.gamePage) throw new Error("Lecture Big Win obsolète après remplacement du jeu.");
      if (result.action === "clicked" && this.pragmaticPendingWin === null) {
        const amount = this.pragmaticWinLatestSnapshot?.presentationWinCents ?? null;
        this.pragmaticPendingWin = { id: randomUUID(), gainCents: amount !== null && amount > 0 && amount === snapshot.presentationWinCents ? amount : null, source: "pragmatic-received-spin-cycle" };
      }
      if (result.status === "cleared" && this.pragmaticPendingWin !== null) {
        this.pendingWinGains.push(this.pragmaticPendingWin);
        this.pragmaticPendingWin = null;
      }
      if (result.presentationActive && !this.pragmaticWinHolding) { this.pragmaticWinHoldingSince = Date.now(); this.pragmaticWinEpisodeReference = this.pragmaticWinLatestSnapshot ?? snapshot; }
      this.pragmaticWinHolding = result.presentationActive;
      if (!result.presentationActive) { this.pragmaticWinHoldingSince = null; this.pragmaticWinEpisodeReference = null; }
      const report = result.action === "clicked" ? `clic central après double preuve et garde fraîche ${JSON.stringify(this.pragmaticWinAudit)}` : result.status === "cleared" ? "fin confirmée, relecture du gain fournisseur" : result.error;
      if (report !== null && report !== this.pragmaticWinLastReport) { this.pragmaticWinLastReport = report; await this.options.onMilestone?.(`Pragmatic Big Win: ${report}.`); }
      return result;
    } finally { clearTimeout(timer); context.cancelled = true; }
  }

  private async declinePragmaticSpinGambleIfActive(): Promise<boolean> {
    const frame = await this.pragmaticFrame();
    const result = await frame.evaluate<{
      active: boolean;
      triggered: string | null;
      candidates: string[];
    }>(`(() => {
      const runtime = window;
      const vars = runtime.Vars ?? {};
      const getBool = runtime.XT?.GetBool;
      const active = ["CanGamble_Spin", "CanGamble_FreeSpin", "CanGamble_Bonus"]
        .some((name) => {
          const key = vars[name] ?? name;
          if (typeof key !== "string" || typeof getBool !== "function") return false;
          try { return Reflect.apply(getBool, runtime.XT, [key]) === true; } catch { return false; }
        });
      if (!active) return { active: false, triggered: null, candidates: [] };
      const candidates = [
        "Evt_DataToCode_Pressed_GambleCollect",
        "Evt_ToServer_RequestGambleClose",
        "Evt_Internal_GambleCloseCurrentResultWindow",
      ].filter((name) => typeof vars[name] === "string");
      const trigger = runtime.XT?.TriggerEvent;
      if (typeof trigger !== "function" || candidates[0] === undefined) {
        return { active: true, triggered: null, candidates };
      }
      Reflect.apply(trigger, runtime.XT, [vars[candidates[0]]]);
      return { active: true, triggered: candidates[0], candidates };
    })()`);
    if (!result.active) return false;
    if (result.triggered === null) {
      throw new Error(
        `Gamble Pragmatic actif après spin mais action COLLECT introuvable (${result.candidates.join(",") || "aucune"}).`,
      );
    }
    await this.options.onMilestone?.(
      `Gamble Pragmatic après spin refusé sans prise de risque via ${result.triggered}.`,
    );
    const deadline = this.now() + 5_000;
    while (this.now() <= deadline) {
      const closed = await frame.evaluate<boolean>(`(() => {
        const runtime = window;
        const vars = runtime.Vars ?? {};
        const getBool = runtime.XT?.GetBool;
        return !["CanGamble_Spin", "CanGamble_FreeSpin", "CanGamble_Bonus"].some((name) => {
          const key = vars[name] ?? name;
          if (typeof key !== "string" || typeof getBool !== "function") return false;
          try { return Reflect.apply(getBool, runtime.XT, [key]) === true; } catch { return false; }
        });
      })()`).catch(() => false);
      if (closed) return true;
      await frame.page().waitForTimeout(250);
    }
    throw new Error("Gamble Pragmatic après spin: COLLECT envoyé mais fermeture non confirmée après 5 secondes.");
  }

  private updateAutoplayProgress(snapshot: { autoplayActive: boolean; autoplayRemaining: number | null }): number {
    if (!this.nativeAutoplay) return 0;
    const remaining = snapshot.autoplayRemaining;
    let settled = 0;
    if (remaining !== null && this.autoplayLastRemaining !== null && remaining < this.autoplayLastRemaining) {
      settled = this.autoplayLastRemaining - remaining;
      this.roundsPlayed += settled;
    }
    if (remaining !== null) this.autoplayLastRemaining = remaining;
    if (!snapshot.autoplayActive) {
      this.nativeAutoplay = false;
      this.autoplayLastRemaining = null;
    }
    return settled;
  }

  private updateBonus(current: BonusSignalState): SlotEvent[] {
    if (current.gainCents !== null) this.lastBonusGainCents = current.gainCents;
    const normalized = this.previousBonus.active && !current.active && current.gainCents === null
      ? { ...current, gainCents: this.lastBonusGainCents }
      : current;
    const events = bonusTransitions(this.previousBonus, normalized);
    if (events.some((event) => event.type === "bonus-started")) {
      this.hacksawBonusStartCenterClicked = false;
      this.hacksawBonusStartDetectedAt = null;
      this.hacksawBonusCollectDetectedAt = null;
      this.hacksawContinueOcrMisses = 0;
      this.hacksawBonusCollectCenterClicked = false;
      this.bonusStartAdvanced = false;
      this.bonusCollectAdvanced = false;
      this.lastBonusGainCents = current.gainCents;
      this.bonusDetectedAt = this.now();
      this.pragmaticOverlayUnresolvedSince = null;
      this.pragmaticStartCanvasClicks = 0;
      this.pragmaticStartFreeSpinsLeft = null;
      this.pragmaticStartCanvasClickedAt = 0;
      if (this.provider === "hacksaw" && this.options.replayHacksawBonusAfterDrop === true && !this.hacksawReplayDone) {
        this.hacksawReplayPending = true;
      }
    }
    this.previousBonus = normalized;
    return events;
  }

  private readPragmaticRecap(): Promise<{ gainCents: number | null; error: string | null }> {
    return readPragmaticRecapOcr(this.requireGamePage());
  }

  private async pragmaticOverlayCanvas(): Promise<Locator> {
    const canvases = await (await this.pragmaticFrame()).locator("canvas").all();
    const visible: Array<{ canvas: Locator; area: number }> = [];
    for (const canvas of canvases) {
      if (!await canvas.isVisible()) continue;
      const box = await canvas.boundingBox();
      if (box && box.width > 100 && box.height > 100) visible.push({ canvas, area: box.width * box.height });
    }
    visible.sort((a, b) => b.area - a.area);
    if (!visible[0] || visible[1] && visible[1].area > visible[0].area * .9) throw new Error("Canvas Pragmatic ambigu pour vérifier le bonus.");
    return visible[0].canvas;
  }

  private async readPragmaticOverlay(): Promise<BonusOverlay> {
    const native = await (await this.pragmaticFrame()).evaluate<{pending:boolean;windowVisible:boolean}>(`(${pragmaticFreeSpinStartContext.toString()})(window)`);
    if (native.pending) return {kind:"intro",x:0.5,y:0.55};
    if (native.windowVisible) return {kind:"unknown",reason:"native-bonus-window-not-actionable"};
    const recap = await (await this.pragmaticFrame()).evaluate<{visible:boolean}>(`(${pragmaticFreeSpinRecapContext.toString()})(window)`);
    if (recap.visible) return {kind:"recap",x:0.5,y:0.55};
    const final = await (await this.pragmaticFrame()).evaluate<{final:boolean;collectEvent:string|null}>(`(() => {const proof=(${pragmaticNativeFreeSpins.toString()})(window);return {final:proof.final,collectEvent:proof.collectEvent};})()`);
    if (final.final && final.collectEvent !== null) return {kind:"recap",x:0.5,y:0.55};
    const image = await captureCanvasSnapshot(await this.pragmaticOverlayCanvas()).catch(error => {
      if (error instanceof Error && error.name === "TimeoutError") return null;
      throw error;
    });
    return image === null ? {kind:"unknown",reason:"visual-capture-timeout"} : readPragmaticBonusOverlay(image);
  }

  private async clearPragmaticOverlay(allowRecap: boolean, deadline = Date.now() + 10_000): Promise<boolean> {
    const generation = this.pragmaticWinGeneration;
    let screen = await this.readPragmaticOverlay();
    if (screen.kind === "unknown") {
      await this.requireGamePage().waitForTimeout(250);
      screen = await this.readPragmaticOverlay();
    }
    // OCR can miss the base-game HUD on small/animated canvases. Only override
    // that inconclusive visual result when provider runtime independently proves
    // an idle base game; explicit offers, wins, dialogs and OCR failures stay blocked.
    if (screen.kind === "unknown" && screen.reason === "insufficient-game-evidence") {
      const runtime = await this.readPragmatic();
      const provenIdleBaseGame = runtime.winPresentationRuntimeKnown &&
        runtime.readyToSpin === true && runtime.spinBusy === false &&
        runtime.bonus.active === false && runtime.playingFreeSpins === false &&
        runtime.freeSpinsLeft === 0 && runtime.blockingDialogVisible === false &&
        runtime.gambleActive === false && runtime.winPresentationCandidate === false &&
        runtime.waitInResultForBigWin !== true;
      if (provenIdleBaseGame) {
        await this.options.onMilestone?.("OCR HUD incomplet, mais état runtime Pragmatic confirme le base game idle sans bonus, gain ni dialogue.");
        return true;
      }
    }
    for (let attempt = 0; attempt < 2; attempt++) {
      if (Date.now() >= deadline || generation !== this.pragmaticWinGeneration) return false;
      if (screen.kind === "clear") return true;
      if (!("x" in screen) || screen.kind === "recap" && !allowRecap) return false;
      const fresh = await this.readPragmaticOverlay();
      if (fresh.kind === "clear") return true;
      if (fresh.kind !== screen.kind || !("x" in fresh) || Math.abs(fresh.x - screen.x) > .04 || Math.abs(fresh.y - screen.y) > .04) return false;
      const runtime = await this.readPragmatic();
      if (Date.now() >= deadline || generation !== this.pragmaticWinGeneration || this.provider !== "pragmatic" || runtime.blockingDialogVisible !== false || runtime.gambleActive === true || runtime.winPresentationCandidate) return false;
      const canvas = await this.pragmaticOverlayCanvas();
      const box = await canvas.boundingBox();
      if (!box || Date.now() >= deadline || generation !== this.pragmaticWinGeneration) return false;
      let collectedNatively = false;
      const uiRecap = fresh.kind === "recap" ? await (await this.pragmaticFrame()).evaluate<{visible:boolean}>(`(${pragmaticFreeSpinRecapContext.toString()})(window)`) : {visible:false};
      if (fresh.kind === "recap" && allowRecap && this.lastBonusGainCents !== null && !uiRecap.visible) {
        const result = await (await this.pragmaticFrame()).evaluate<{triggered:boolean}>(`(() => {const result=(${pragmaticNativeFreeSpins.toString()})(window,true,${this.lastBonusGainCents/100});return {triggered:result.triggered};})()`);
        collectedNatively = result.triggered;
      }
      // Locator.click scrolls the iframe/canvas into view before dispatch. In
      // fullscreen GRM that moves the visible canvas by a few pixels and breaks
      // the following OCR capture. The fresh capture already proved this point
      // visible: dispatch at its page coordinates without scrolling/restyling.
      if (!collectedNatively) await canvas.page().mouse.click(box.x + fresh.x * box.width, box.y + fresh.y * box.height);
      await this.parkPresentationPointer();
      await this.options.onMilestone?.(`Fenêtre bonus Pragmatic ${fresh.kind}: ${collectedNatively ? "COLLECT natif acquitté" : "CONTINUE localisé et cliqué"} ; vérification de disparition.`);
      // A fading window is still a window. Do not start paid spins underneath it.
      for (let read = 0; read < 4; read++) {
        await this.requireGamePage().waitForTimeout(350);
        if (fresh.kind === "intro") {
          const native = await (await this.pragmaticFrame()).evaluate<{windowVisible:boolean}>(`(${pragmaticFreeSpinStartContext.toString()})(window)`);
          const after = await this.readPragmatic();
          if (!native.windowVisible && after.freeSpinsLeft > 0 &&
              (after.playingFreeSpins || after.spinBusy === true || after.freeSpinsLeft < runtime.freeSpinsLeft) &&
              after.gambleActive !== true && after.blockingDialogVisible === false && !after.winPresentationCandidate && Date.now() < deadline && generation === this.pragmaticWinGeneration) {
            await this.options.onMilestone?.("Introduction Pragmatic fermée : fenêtre native absente et progression free spins confirmée.");
            return true;
          }
        }
        if (fresh.kind === "recap" && uiRecap.visible) {
          const recap = await (await this.pragmaticFrame()).evaluate<{visible:boolean}>(`(${pragmaticFreeSpinRecapContext.toString()})(window)`);
          const intro = await (await this.pragmaticFrame()).evaluate<{windowVisible:boolean}>(`(${pragmaticFreeSpinStartContext.toString()})(window)`);
          const after = await this.readPragmatic();
          if (!recap.visible && !intro.windowVisible && after.bonus.active === false && after.freeSpinsLeft === 0 && after.readyToSpin === true && after.spinBusy === false && after.gambleActive === false && after.blockingDialogVisible === false && !after.winPresentationCandidate && Date.now()<deadline && generation===this.pragmaticWinGeneration) {
            await this.options.onMilestone?.("Récapitulatif Pragmatic fermé par son interface : disparition native et retour base idle confirmés.");
            return true;
          }
        }
        screen = await this.readPragmaticOverlay();
        if (fresh.kind === "intro" && screen.kind === "unknown" && screen.reason === "insufficient-game-evidence") {
          const after = await this.readPragmatic();
          const native = await (await this.pragmaticFrame()).evaluate<{windowVisible:boolean}>(`(${pragmaticFreeSpinStartContext.toString()})(window)`);
          if (!native.windowVisible && after.playingFreeSpins && after.freeSpinsLeft > 0 && after.gambleActive !== true && after.blockingDialogVisible === false && !after.winPresentationCandidate && Date.now() < deadline && generation === this.pragmaticWinGeneration) {
            screen = {kind:"clear",reason:"native-intro-dismissed-and-free-spins-playing"};
          }
        }
        if (Date.now() >= deadline || generation !== this.pragmaticWinGeneration) return false;
        if (screen.kind === "clear") {
          await this.options.onMilestone?.("Fenêtre bonus Pragmatic absente sur nouvelle capture ; jeu visible confirmé.");
          return true;
        }
      }
    }
    throw new Error("PRAGMATIC_OVERLAY_UNRESOLVED: fenêtre bonus toujours visible après deux actions vérifiées.");
  }

  public async observe(): Promise<SlotObservation> {
    if (this.expectedGamePath !== null && this.gamePage !== null && !this.gamePage.isClosed()) {
      const actual = new URL(this.gamePage.url());
      if (actual.origin + actual.pathname !== this.expectedGamePath) throw new Error("AUTOMOD_CONTEXT_MISMATCH: la page active ne correspond plus à la machine prévue.");
    }
    const observeStartedAt = Date.now();
    const observeGeneration = this.pragmaticWinGeneration;
    if (this.provider === "nolimit") {
      if (this.nolimitDriver === null) throw new Error("Driver Nolimit absent.");
      const observation = await this.nolimitDriver.observe();
      // Keep the executor's autoplay guard aligned after a restored bonus.
      // The driver owns bonus events, so do not emit a duplicate bonus-ended.
      this.previousBonus = this.nolimitDriver.snapshot().bonus;
      return observation;
    }
    if (this.provider === "hacksaw") {
      const snapshot = await this.readHacksaw();
      // Certains jeux conservent le compteur et le bouton STOP visibles après
      // l'arrêt demandé. Le retour du bouton de spin à l'état idle est alors la
      // preuve fiable que le lot est réellement interrompu.
      const autoplayActive = snapshot.autoplayActive && !(this.nativeAutoplayStopRequested && snapshot.idle);
      const autoplaySnapshot = autoplayActive === snapshot.autoplayActive
        ? snapshot
        : { ...snapshot, autoplayActive };
      const stoppedEarlyForFeature =
        this.nativeAutoplay &&
        !this.nativeAutoplayStopRequested &&
        !autoplayActive &&
        (snapshot.autoplayRemaining ?? this.autoplayLastRemaining ?? 0) > 0 &&
        (snapshot.autoplayButtonDisabled || snapshot.blockingDialogVisible);
      const events = this.updateBonus(stoppedEarlyForFeature ? { ...snapshot.bonus, active: true } : snapshot.bonus);
      // Some titles resume the native batch themselves after collecting a
      // feature. Reattach its counter without sending another autoplay command.
      if (!this.nativeAutoplay && autoplayActive && !this.nativeAutoplayStopRequested) {
        this.nativeAutoplay = true;
        this.autoplayLastRemaining = this.lastHacksaw?.autoplayRemaining ?? snapshot.autoplayRemaining;
      }
      const hadNativeAutoplay = this.nativeAutoplay;
      let autoplayRounds = this.updateAutoplayProgress(autoplaySnapshot);
      const zeroCounterCandidate = (hadNativeAutoplay || this.hacksawZeroAutoplaySince !== null) && snapshot.autoplayRemaining === 0 && !autoplayActive && !snapshot.bonus.active;
      if (zeroCounterCandidate) this.hacksawZeroAutoplaySince ??= this.now();
      else {
        this.hacksawZeroAutoplaySince = null;
        this.hacksawZeroAutoplayLogged = false;
      }
      const knownNativeBusy = /^(?:gameRoundEnter|gameRoundExit|play|spin|winPresentation)(?:$|[-_])|^feature/i.test(snapshot.providerState ?? "");
      const settledAfterZeroCounter = !knownNativeBusy && isHacksawZeroCounterSettled({
        remaining: snapshot.autoplayRemaining,
        autoplayActive,
        bonusActive: snapshot.bonus.active,
        blockingDialogVisible: snapshot.blockingDialogVisible,
        idle: snapshot.idle,
        since: this.hacksawZeroAutoplaySince,
        now: this.now(),
      });
      if (settledAfterZeroCounter && !this.hacksawZeroAutoplayLogged) {
        this.hacksawZeroAutoplayLogged = true;
        this.roundsPlayed += 1;
        autoplayRounds += 1;
        await this.options.onMilestone?.("Autoplay Hacksaw à zéro: dernier spin confirmé réglé.");
      }
      if (this.spinPending && !this.nativeAutoplay) {
        if (!snapshot.idle) this.pendingSawBusy = true;
        if (snapshot.balanceCents !== null && snapshot.balanceCents !== this.spinLastBalanceCents) {
          this.spinLastBalanceCents = snapshot.balanceCents;
          this.pendingResultSeenAt = this.now();
        }
        const settledByStableBalance = snapshot.idle && this.pendingResultSeenAt !== null && this.now() - this.pendingResultSeenAt >= 1_000;
        if (snapshot.bonus.active || (this.pendingSawBusy && snapshot.idle) || settledByStableBalance) {
          this.roundsPlayed += 1;
          this.spinPending = false;
        } else if (this.now() - this.spinStartedAt > this.options.runnerConfig.safety.settlementTimeoutMs) {
          throw new Error("Spin Hacksaw non réglé dans le délai de sécurité.");
        }
      }
      this.lastHacksaw = snapshot;
      return {
        idle: (snapshot.idle || settledAfterZeroCounter) && !autoplayActive && !this.spinPending,
        roundsPlayed: this.roundsPlayed,
        events,
        baseStakeCents: this.actualBaseStakeCents,
        autoplayActive,
        autoplayRemaining: snapshot.autoplayRemaining,
        bonusActive: this.previousBonus.active,
        winPresentations: this.pendingWinGains.splice(0),
        bonusProgress: `${snapshot.providerState}:${snapshot.counterValue}:${snapshot.totalWinVisible}:${snapshot.bonus.gainCents}`,
        roundActive: !settledAfterZeroCounter && !snapshot.idle && !snapshot.blockingDialogVisible && !this.previousBonus.active,
        roundPayoutsCents: autoplayRounds === 0
          ? []
          : Array.from({ length: autoplayRounds }, (_, index) => index === autoplayRounds - 1 ? snapshot.lastSpinWinCents : null),
      };
    }
    if (this.provider === "pragmatic") {
      let snapshot = await this.readPragmatic();
      const presentation = await this.inspectPragmaticWinPresentation(snapshot, observeStartedAt);
      if (observeGeneration !== this.pragmaticWinGeneration || this.provider !== "pragmatic") throw new Error("Observation Pragmatic obsolète après remplacement du jeu.");
      if (presentation.presentationActive) {
        this.pragmaticOcrCandidate = null;
        this.pragmaticFinalStateSince = null;
        snapshot = this.pragmaticWinLatestSnapshot ?? snapshot;
        const events = !this.previousBonus.active && snapshot.bonus.active ? this.updateBonus({ active: true, gainCents: null }) : [];
        return { idle: false, roundsPlayed: this.roundsPlayed, events, baseStakeCents: this.actualBaseStakeCents, autoplayActive: snapshot.autoplayActive, autoplayRemaining: snapshot.autoplayRemaining, bonusActive: this.previousBonus.active || snapshot.bonus.active, roundActive: false, roundPayoutsCents: [] };
      }
      if (presentation.status !== "idle" && presentation.status !== "throttled") snapshot = await this.readPragmatic(Math.max(1, Math.min(1_500, observeStartedAt + 12_000 - Date.now())));
      // Runtime counters can progress behind a residual canvas window.
      if (this.now() - this.pragmaticOverlayLastCheckedAt >= 5_000) {
        this.pragmaticOverlayLastCheckedAt = this.now();
        const screen = await this.readPragmaticOverlay();
        if (screen.kind === "intro" || screen.kind === "recap" && !this.previousBonus.active && this.lastBonusGainCents !== null) {
          if (!await this.clearPragmaticOverlay(!this.previousBonus.active && this.lastBonusGainCents !== null, observeStartedAt + 12_000)) {
            this.pragmaticOverlayUnresolvedSince ??= this.now();
            if (this.now()-this.pragmaticOverlayUnresolvedSince >= 30_000) throw new Error("PRAGMATIC_OVERLAY_UNRESOLVED: fermeture non confirmée après 30 secondes de relectures.");
            await this.options.onMilestone?.("Transition bonus Pragmatic encore instable : attente bornée et nouvelle lecture, aucun spin payant.");
            const events=this.updateBonus(snapshot.bonus);
            return {idle:false,roundsPlayed:this.roundsPlayed,events,baseStakeCents:this.actualBaseStakeCents,autoplayActive:snapshot.autoplayActive,autoplayRemaining:snapshot.autoplayRemaining,bonusActive:this.previousBonus.active,roundActive:false,roundPayoutsCents:[]};
          }
          this.pragmaticOverlayUnresolvedSince=null;
          snapshot = await this.readPragmatic();
        }
      }
      if (
        !this.previousBonus.active && !snapshot.bonus.active && !snapshot.autoplayActive &&
        snapshot.spinBusy !== true && snapshot.readyToSpin === false
      ) {
        if (await this.declinePragmaticSpinGambleIfActive()) snapshot = await this.readPragmatic();
      }
      if (
        !this.previousBonus.active && snapshot.spinBusy !== true &&
        this.now() - this.pragmaticPromoLastCheckedAt >= 15_000
      ) {
        this.pragmaticPromoLastCheckedAt = this.now();
        await this.dismissPragmaticPromoOverlay();
      }
      if (
        this.previousBonus.active &&
        snapshot.freeSpinsLeft === 0 &&
        !snapshot.customBonusCollectPending &&
        (snapshot.bonus.gainCents === null || snapshot.bonus.active) &&
        this.now() - this.bonusDetectedAt >= 3_000 &&
        this.now() - this.pragmaticLastOcrAt >= 3_000
      ) {
        this.pragmaticOcrAttempts += 1;
        this.pragmaticLastOcrAt = this.now();
        const ocr = await this.readPragmaticRecap();
        if (observeGeneration !== this.pragmaticWinGeneration || this.provider !== "pragmatic" || Date.now() >= observeStartedAt + 12_000) throw new Error("Récapitulatif Pragmatic obsolète ou observation expirée.");
        if (ocr.gainCents !== null) {
          if (this.pragmaticOcrCandidate?.gainCents === ocr.gainCents && this.now() - this.pragmaticOcrCandidate.since >= 1_500) {
            this.pragmaticOcrGainCents = ocr.gainCents;
            this.pragmaticOcrCandidate = null;
            await this.options.onMilestone?.(`Gain final Pragmatic confirmé par deux lectures OCR du récapitulatif: ${(ocr.gainCents / 100).toFixed(2)} €.`);
          } else this.pragmaticOcrCandidate = { gainCents: ocr.gainCents, since: this.now() };
        } else {
          this.pragmaticOcrCandidate = null;
          if (this.pragmaticOcrAttempts <= 3 || this.pragmaticOcrAttempts % 10 === 0) {
            await this.options.onMilestone?.(
              `OCR du récapitulatif Pragmatic encore illisible (tentative ${this.pragmaticOcrAttempts})${ocr.error ? `: ${ocr.error}` : "."}`,
            );
          }
        }
      }
      const waitingForReadableBonusEnd =
        this.previousBonus.active && !snapshot.bonus.active &&
        snapshot.bonus.gainCents === null && this.pragmaticOcrGainCents === null;
      const finalStateKnown = !snapshot.bonus.active && !snapshot.playingFreeSpins && snapshot.freeSpinsLeft === 0 &&
        snapshot.blockingDialogVisible === false && snapshot.gambleActive !== true && !snapshot.winPresentationCandidate &&
        ((snapshot.winPresentationRuntimeKnown && snapshot.waitInResultForBigWin === false) || (snapshot.readyToSpin === true && snapshot.spinBusy === false));
      if (finalStateKnown) this.pragmaticFinalStateSince ??= this.now();
      else this.pragmaticFinalStateSince = null;
      const finalStateStable = this.pragmaticFinalStateSince !== null && this.now() - this.pragmaticFinalStateSince >= 1_500;
      const paidAutoplayResumedAfterBonus =
        waitingForReadableBonusEnd && finalStateStable &&
        snapshot.autoplayActive &&
        (snapshot.autoplayRemaining ?? 0) > 0 &&
        snapshot.playingFreeSpins === false &&
        snapshot.freeSpinsLeft === 0 &&
        this.pragmaticOcrAttempts >= 3 &&
        this.lastBonusGainCents !== null;
      if (paidAutoplayResumedAfterBonus) {
        const recoveredGainCents = this.lastBonusGainCents;
        if (recoveredGainCents === null) throw new Error("Gain télémétrique Pragmatic perdu pendant la reprise autoplay.");
        this.pragmaticOcrGainCents = recoveredGainCents;
        await this.options.onMilestone?.(
          `Récapitulatif Pragmatic déjà refermé; gain final récupéré depuis la dernière télémétrie fiable: ` +
          `${(recoveredGainCents / 100).toFixed(2)} €.`
        );
      }
      // Le gain du dernier tour ne remplace jamais un total de bonus illisible.
      if (observeGeneration !== this.pragmaticWinGeneration || this.provider !== "pragmatic") throw new Error("Gain Pragmatic obsolète après remplacement du jeu.");
      const observedBonus = this.pragmaticOcrGainCents !== null
        ? { active: false, gainCents: this.pragmaticOcrGainCents }
        : waitingForReadableBonusEnd ? { active: true, gainCents: null } : snapshot.bonus;
      const events = this.updateBonus(observedBonus);
      const autoplayRounds = this.updateAutoplayProgress(snapshot);
      const zeroCounterCandidate = snapshot.autoplayRemaining === 0 && snapshot.spinBusy === false && !snapshot.bonus.active;
      if (zeroCounterCandidate) this.pragmaticZeroAutoplaySince ??= this.now();
      else {
        this.pragmaticZeroAutoplaySince = null;
        this.pragmaticZeroAutoplayLogged = false;
      }
      const settledAfterZeroCounter = isPragmaticZeroCounterSettled({
        remaining: snapshot.autoplayRemaining,
        busy: snapshot.spinBusy,
        bonusActive: snapshot.bonus.active,
        since: this.pragmaticZeroAutoplaySince,
        now: this.now(),
      });
      if (settledAfterZeroCounter && !this.pragmaticZeroAutoplayLogged) {
        this.pragmaticZeroAutoplayLogged = true;
        await this.options.onMilestone?.("Autoplay Pragmatic à zéro et écran stable 12 s: dernier spin considéré réglé.");
      }
      if (this.spinPending && !this.nativeAutoplay) {
        if (snapshot.spinBusy === true || snapshot.readyToSpin === false) this.pendingSawBusy = true;
        const resultChanged =
          (snapshot.resultSignature !== null && snapshot.resultSignature !== this.spinBaselineSignature) ||
          snapshot.telemetryCount > this.spinBaselineTelemetry;
        if (resultChanged && this.pendingResultSeenAt === null) this.pendingResultSeenAt = this.now();
        const settledByReady = this.pendingSawBusy && (snapshot.spinBusy === false || snapshot.readyToSpin === true);
        const settledByResult = this.pendingResultSeenAt !== null && this.now() - this.pendingResultSeenAt >= 1_000 &&
          snapshot.spinBusy !== true && snapshot.readyToSpin !== false;
        if (snapshot.bonus.active || settledByReady || settledByResult) {
          this.roundsPlayed += 1;
          this.spinPending = false;
        } else if (this.now() - this.spinStartedAt > this.options.runnerConfig.safety.settlementTimeoutMs) {
          throw new Error("Spin Pragmatic non réglé dans le délai de sécurité.");
        }
      }
      this.lastPragmatic = snapshot;
      const idle = !snapshot.autoplayActive && !this.spinPending && !snapshot.bonus.active && snapshot.spinBusy !== true &&
        (snapshot.readyToSpin !== false || settledAfterZeroCounter);
      return {
        idle,
        roundsPlayed: this.roundsPlayed,
        events,
        baseStakeCents: this.actualBaseStakeCents,
        autoplayActive: snapshot.autoplayActive,
        autoplayRemaining: snapshot.autoplayRemaining,
        bonusActive: this.previousBonus.active,
        winPresentations: this.pendingWinGains.splice(0),
        bonusProgress: `${snapshot.freeSpinsLeft}:${snapshot.spinResultIsBigWin}:${snapshot.waitInResultForBigWin}:${snapshot.bonus.gainCents}`,
        roundActive: snapshot.spinBusy === true,
        // Le compteur peut baisser au début du tour suivant, une fois le HUD remis à zéro.
        // Sans ID de résultat attribuable au tour terminé, ce zéro n'est pas une preuve de perte.
        roundPayoutsCents: Array.from({ length: autoplayRounds }, () => null),
      };
    }
    throw new Error("Aucun provider actif à observer.");
  }

  public async spin(): Promise<void> {
    try { await this.performSpin(); } finally { await this.parkPresentationPointer(); }
  }

  private async performSpin(): Promise<void> {
    if (this.pendingBaseGameConfig !== null) throw new Error("Spin interdit avant la résolution du bonus présent à l’ouverture.");
    if (this.pragmaticWinHolding) throw new Error("Spin interdit pendant une présentation de gain non terminée.");
    await this.ensureVpnFresh();
    if (this.provider === "nolimit") {
      if (this.nolimitDriver === null) throw new Error("Driver Nolimit absent.");
      await this.nolimitDriver.spin();
      return;
    }
    if (this.spinPending) throw new Error("Un spin est déjà en attente de règlement.");
    if (this.previousBonus.active) throw new Error("Nouveau spin interdit pendant un bonus.");
    if (this.provider === "pragmatic" && !await this.clearPragmaticOverlay(this.lastBonusGainCents !== null)) throw new Error("PRAGMATIC_OVERLAY_UNRESOLVED: spin interdit, écran pas encore visuellement dégagé.");
    this.spinPending = true;
    this.spinStartedAt = this.now();
    this.pendingSawBusy = false;
    this.pendingResultSeenAt = null;
    this.spinLastBalanceCents = this.lastHacksaw?.balanceCents ?? null;
    try {
      if (this.provider === "hacksaw") {
        const frame = this.hacksawFrame();
        const button = frame.locator("#PlaceBetBtn");
        const deadline = this.now()+2_500;
        while(this.now()<=deadline){
          const fresh=await this.readHacksaw();
          if(fresh.bonus.active){this.spinPending=false;this.lastHacksaw=fresh;return;}
          if(fresh.idle && (await button.count())===1 && await button.isVisible() && await button.isEnabled()){
            const clicked=await button.evaluate((element)=>{
              const control=element as HTMLButtonElement;
              const state=document.querySelector('#hacksaw-casino')?.getAttribute('data-state')??'';
              if(control.disabled||control.getAttribute('aria-disabled')==='true'||control.classList.contains('is-disabled')||/^(?:gameRoundEnter|gameRoundExit|play|spin|winPresentation)(?:$|[-_])|^feature/i.test(state))return false;
              control.click();return true;
            });
            if(clicked)return;
          }
          await frame.page().waitForTimeout(100);
        }
        throw new Error("Bouton Spin Hacksaw non disponible après 2,5 s de vérification native; aucun clic envoyé.");
      }
      if (this.provider === "pragmatic") {
        const frame = await this.pragmaticFrame();
        this.spinBaselineSignature = this.lastPragmatic?.resultSignature ?? null;
        this.spinBaselineTelemetry = this.lastPragmatic?.telemetryCount ?? 0;
        const triggered = await frame.evaluate(() => {
          const runtime = window as unknown as { Vars?: Record<string, unknown>; XT?: { TriggerEvent?: (...args: unknown[]) => unknown } };
          const event = runtime.Vars?.Evt_DataToCode_SpinButtonPressed;
          const trigger = runtime.XT?.TriggerEvent;
          if (typeof event !== "string" || typeof trigger !== "function") return false;
          Reflect.apply(trigger, runtime.XT, [event]);
          return true;
        });
        if (!triggered) throw new Error("Événement sémantique Spin Pragmatic indisponible.");
        return;
      }
      throw new Error("Aucun provider actif pour lancer un spin.");
    } catch (error) {
      this.spinPending = false;
      throw error;
    }
  }

  public async startAutoplay(spins: number): Promise<number> {
    try { return await this.performStartAutoplay(spins); } finally { await this.parkPresentationPointer(); }
  }

  private async performStartAutoplay(spins: number): Promise<number> {
    if (this.pendingBaseGameConfig !== null) throw new Error("Autoplay interdit avant la résolution du bonus présent à l’ouverture.");
    if (this.pragmaticWinHolding) throw new Error("Autoplay interdit pendant une présentation de gain non terminée.");
    await this.ensureVpnFresh();
    if (!Number.isSafeInteger(spins) || spins <= 0) throw new Error(`Nombre de spins autoplay invalide: ${spins}.`);
    if (this.spinPending || this.nativeAutoplay) throw new Error("Un autoplay ou un spin est déjà actif.");
    if (this.previousBonus.active) throw new Error("Autoplay interdit pendant un bonus.");
    if (this.provider === "pragmatic" && !await this.clearPragmaticOverlay(this.lastBonusGainCents !== null)) {
      await this.requireGamePage().waitForTimeout(400);
      if(!await this.clearPragmaticOverlay(this.lastBonusGainCents !== null))throw new Error("PRAGMATIC_OVERLAY_UNRESOLVED: autoplay interdit, écran pas encore visuellement dégagé après relecture.");
    }

    if (this.provider === "nolimit") {
      if (this.nolimitDriver === null) throw new Error("Driver Nolimit absent.");
      return this.nolimitDriver.startAutoplay(spins);
    }

    if (this.provider === "hacksaw") {
      const frame = this.hacksawFrame();
      const featureMenu = frame.locator("#FeatureBuyWindow");
      if (await featureMenu.isVisible().catch(() => false)) {
        const featureToggle = frame.locator("#FeatureBuyToggle");
        if ((await featureToggle.count()) !== 1) throw new Error("Menu FeatureSpin Hacksaw ouvert et impossible à fermer.");
        await featureToggle.evaluate((element) => (element as HTMLElement).click());
        await featureMenu.waitFor({ state: "hidden", timeout: 3_000 });
      }
      if (await frame.locator("#DialogWindow").isVisible().catch(() => false)) {
        throw new Error("Dialogue Hacksaw bloquant encore ouvert avant l’autoplay.");
      }
      const choices = await frame.locator(".AutoplayValue").evaluateAll((elements) => elements
        .map((element) => Number((element.textContent ?? "").replace(/\D+/g, "")))
        .filter((value) => Number.isSafeInteger(value) && value > 0));
      const batch = selectLargestAutoplayBatch(choices, spins);
      if (batch === 0) return 0;
      await this.options.onMilestone?.(`Autoplay Hacksaw: sélection d’un lot de ${batch} spins.`);

      const menuButton = frame.locator("#AutoplayBtn");
      if ((await menuButton.count()) !== 1 || !(await menuButton.isVisible()) || !(await menuButton.isEnabled())) {
        await this.options.onMilestone?.(
          "Bouton autoplay Hacksaw temporairement indisponible; fallback sûr sur un spin manuel.",
        );
        await this.spin();
        return 1;
      }
      const menu = frame.locator("#AutoplayNav");
      let menuOpened = false;
      for (let attempt = 1; attempt <= 3 && !menuOpened; attempt += 1) {
        const clicked = await menuButton.evaluate((element) => {
          if (!(element instanceof HTMLButtonElement) || element.disabled || element.getAttribute("aria-disabled") === "true" || element.classList.contains("is-disabled")) {
            return false;
          }
          element.click();
          return true;
        }).catch(() => false);
        if (clicked) {
          menuOpened = await menu.waitFor({ state: "visible", timeout: 3_000 }).then(() => true).catch(() => false);
        }
        if (!menuOpened && attempt < 3) await frame.page().waitForTimeout(1_000);
      }
      if (!menuOpened) {
        await this.options.onMilestone?.(
          "Menu autoplay Hacksaw non rouvert après la fin d’un lot; fallback sûr sur un spin manuel.",
        );
        await this.spin();
        return 1;
      }
      const choice = frame.locator(".AutoplayValue").filter({ hasText: new RegExp(`^\\s*${batch}\\s*$`) });
      if ((await choice.count()) !== 1) throw new Error(`Choix autoplay Hacksaw ${batch} non unique.`);
      await choice.evaluate((element) => (element as HTMLElement).click());

      const stopOnFeature = frame.locator("#StopOnFeatureToggle");
      if ((await stopOnFeature.count()) === 1 && await stopOnFeature.isVisible()) {
        const enabled = await stopOnFeature.evaluate((element) => {
          if (element instanceof HTMLInputElement) return element.checked;
          return element.getAttribute("aria-checked") === "true" || element.classList.contains("active") || element.classList.contains("selected");
        });
        if (!enabled) await stopOnFeature.evaluate((element) => (element as HTMLElement).click());
      }

      const start = frame.locator("#StartAutoplayBtn");
      await start.waitFor({ state: "visible", timeout: 5_000 });
      if (!(await start.isEnabled())) throw new Error("Démarrage autoplay Hacksaw désactivé.");
      await start.evaluate((element) => {
        if (element instanceof HTMLButtonElement && element.disabled) throw new Error("Démarrage autoplay Hacksaw désactivé.");
        (element as HTMLElement).click();
      });
      const deadline = this.now() + 5_000;
      let snapshot = await this.readHacksaw();
      while (!snapshot.autoplayActive && this.now() <= deadline) {
        await frame.page().waitForTimeout(100);
        snapshot = await this.readHacksaw();
      }
      if (!snapshot.autoplayActive) throw new Error("Autoplay Hacksaw non confirmé après démarrage.");
      await this.options.onMilestone?.(`Autoplay Hacksaw confirmé: ${snapshot.autoplayRemaining ?? batch} spins restants.`);
      this.nativeAutoplay = true;
      this.nativeAutoplayStopRequested = false;
      this.autoplayLastRemaining = snapshot.autoplayRemaining ?? batch;
      this.lastHacksaw = snapshot;
      return batch;
    }

    if (this.provider === "pragmatic") {
      const batch = spins;
      await this.options.onMilestone?.(`Autoplay Pragmatic: demande de ${batch} spins.`);
      const frame = await this.pragmaticFrame();
      let snapshot = await this.readPragmatic();
      for (let attempt = 1; attempt <= 3 && !snapshot.autoplayActive; attempt += 1) {
        const started = await frame.evaluate((requested) => {
          const runtime = window as unknown as {
            Vars?: Record<string, unknown>;
            XT?: {
              SetInt?: (...args: unknown[]) => unknown;
              GetInt?: (...args: unknown[]) => unknown;
              TriggerEvent?: (...args: unknown[]) => unknown;
            };
          };
          const key = runtime.Vars?.AutoplaySpinsRequested;
          const event = runtime.Vars?.Evt_DataToCode_StartAutoplay;
          const setInt = runtime.XT?.SetInt;
          const getInt = runtime.XT?.GetInt;
          const trigger = runtime.XT?.TriggerEvent;
          if (typeof key !== "string" || typeof event !== "string" || typeof setInt !== "function" || typeof trigger !== "function") return false;
          Reflect.apply(setInt, runtime.XT, [key, requested]);
          if (typeof getInt === "function" && Reflect.apply(getInt, runtime.XT, [key]) !== requested) return false;
          Reflect.apply(trigger, runtime.XT, [event]);
          return true;
        }, batch);
        if (!started) {
          await this.options.onMilestone?.(
            "Commande autoplay Pragmatic indisponible; fallback sûr sur un spin manuel.",
          );
          await this.spin();
          return 1;
        }
        const deadline = this.now() + 5_000;
        snapshot = await this.readPragmatic();
        while (!snapshot.autoplayActive && this.now() <= deadline) {
          await frame.page().waitForTimeout(100);
          snapshot = await this.readPragmatic();
        }
        if (!snapshot.autoplayActive && attempt < 3) {
          if (snapshot.spinBusy === true || snapshot.readyToSpin === false || snapshot.bonus.active) {
            // Le moteur peut accepter la commande et démarrer le premier round avant
            // d'exposer son compteur autoplay. Ne jamais renvoyer une seconde commande
            // pendant ce round: le suivre comme un spin manuel jusqu'à son règlement.
            this.spinPending = true;
            this.spinStartedAt = this.now();
            this.pendingSawBusy = snapshot.spinBusy === true || snapshot.readyToSpin === false;
            this.pendingResultSeenAt = null;
            this.spinBaselineSignature = snapshot.resultSignature;
            this.spinBaselineTelemetry = snapshot.telemetryCount;
            await this.options.onMilestone?.(
              "Autoplay Pragmatic sans compteur mais round engagé; suivi sûr du spin courant avant toute relance.",
            );
            return 1;
          }
          await this.options.onMilestone?.(`Autoplay Pragmatic ignoré par le moteur; nouvelle tentative sûre (${attempt + 1}/3).`);
          await frame.page().waitForTimeout(750);
        }
      }
      if (!snapshot.autoplayActive) {
        await this.options.onMilestone?.(
          "Autoplay Pragmatic non confirmé après 3 tentatives; fallback sûr sur un spin manuel.",
        );
        await this.spin();
        return 1;
      }
      await this.options.onMilestone?.(`Autoplay Pragmatic confirmé: ${snapshot.autoplayRemaining ?? batch} spins restants.`);
      this.nativeAutoplay = true;
      this.nativeAutoplayStopRequested = false;
      this.autoplayLastRemaining = snapshot.autoplayRemaining ?? batch;
      this.lastPragmatic = snapshot;
      return batch;
    }
    throw new Error("Aucun provider actif pour lancer l’autoplay.");
  }

  public async advanceBonus(): Promise<void> {
    try { await this.performAdvanceBonus(); } finally { await this.parkPresentationPointer(); }
  }

  private async recoverHacksawFinalRecap(canvas: Locator): Promise<boolean> {
    if (this.hacksawBonusCollectCenterClicked) return false;
    const fresh = await this.readHacksaw();
    if (!/^featureExit(?:-[a-z0-9_-]+)?$/i.test(fresh.providerState ?? "") ||
        !fresh.totalWinVisible || fresh.bonus.gainCents === null || fresh.blockingDialogVisible ||
        (fresh.counterValue ?? 0) !== 0) return false;
    const box = await canvas.boundingBox();
    if (box === null) return false;
    this.hacksawBonusCollectCenterClicked = true;
    await canvas.click({ force: true, position: { x: Math.round(box.width / 2), y: Math.round(box.height / 2) } });
    await this.options.onMilestone?.("Récapitulatif final Hacksaw confirmé : clic central de récupération unique, puis relecture du moteur.");
    const deadline = this.now() + 5_000;
    while (this.now() < deadline) {
      await this.requireGamePage().waitForTimeout(250);
      const after = await this.readHacksaw();
      if (!after.totalWinVisible && !after.blockingDialogVisible &&
          /^(?:idle|autoplay|gameRound(?:Enter|Play|End|Exit))(?:-[a-z0-9_-]+)?$/i.test(after.providerState ?? "")) {
        this.bonusCollectAdvanced = true;
        this.hacksawBonusCollectDetectedAt = null;
        this.lastHacksaw = after;
        await this.options.onMilestone?.("Récupération Hacksaw confirmée : récapitulatif fermé et retour au jeu de base.");
        return true;
      }
    }
    await this.options.onMilestone?.("Clic de récupération sans retour confirmé ; aucun second clic central envoyé.");
    return false;
  }

  private async performAdvanceBonus(): Promise<void> {
    if (this.provider === "pragmatic" && (this.pragmaticWinHolding || this.pragmaticOcrCandidate !== null)) return;
    if (this.provider === "nolimit") {
      if (this.nolimitDriver === null) throw new Error("Driver Nolimit absent.");
      // Nolimit possède son propre anti-rebond basé sur la progression du
      // bonus. Ne pas appliquer ici le throttle générique: la lecture du gain
      // final peut survenir moins de 750 ms après le dernier CONTINUE et le
      // service attend que ce récapitulatif soit réellement acquitté.
      await this.nolimitDriver.advanceBonus();
      this.lastAdvanceAt = this.now();
      return;
    }
    if (this.now() - this.lastAdvanceAt < 750) return;
    if (this.provider === "pragmatic") {
      const snapshot = this.lastPragmatic;
      if (snapshot === null) return;
      const pragmaticFrame = await this.pragmaticFrame();
      if (snapshot.customBonusCollectPending) {
        const current = await this.readPragmatic();
        if (!current.customBonusCollectPending || current.spinBusy === true || current.waitInResultForBigWin === true) return;
        const collectState = await pragmaticFrame.evaluate<ReturnType<typeof pragmaticCustomCollect>>(`(${pragmaticCustomCollect.toString()})(window)`);
        if (collectState.uiCollect) {
          const canvas = await this.pragmaticOverlayCanvas();
          if (canvas === null) return;
          const image = await captureCanvasSnapshot(canvas).catch(()=>null);
          const target = image === null ? null : await findPragmaticDeclaredCollect(image);
          if (target === null) throw new Error('PRAGMATIC_DECLARED_COLLECT_NOT_LOCATED: aucun clic sans texte COLLECT unique et contexte natif.');
          const fresh = await pragmaticFrame.evaluate<ReturnType<typeof pragmaticCustomCollect>>(`(${pragmaticCustomCollect.toString()})(window)`);
          const safe = await this.readPragmatic();
          if (!fresh.uiCollect || fresh.path !== collectState.path || safe.spinBusy === true || safe.waitInResultForBigWin === true) return;
          const box = await canvas.boundingBox();
          if (box === null) return;
          await pragmaticFrame.page().mouse.click(box.x + box.width * target.x / target.imageWidth, box.y + box.height * target.y / target.imageHeight);
        } else {
          const result = await pragmaticFrame.evaluate<{triggered: boolean}>(`(${pragmaticCustomCollect.toString()})(window, true)`);
          if (result.triggered !== true) return;
        }
        this.lastAdvanceAt = this.now();
        const deadline = this.now() + 8_000;
        while (this.now() <= deadline) {
          await pragmaticFrame.page().waitForTimeout(250);
          const after = await this.readPragmatic();
          if (!after.customBonusCollectPending && (after.freeSpinsLeft > 0 || after.playingFreeSpins)) {
            await this.options.onMilestone?.("Choix de bonus Pragmatic : COLLECT garanti acquitté sur le contrôle identifié; free spins confirmés, aucun gamble.");
            this.lastPragmatic = after;
            return;
          }
        }
        throw new Error("PRAGMATIC_CUSTOM_COLLECT_UNCONFIRMED: bouton garanti actionné une fois mais free spins non confirmés; aucun gamble ni répétition aveugle.");
      }
      if (snapshot.playingFreeSpins && snapshot.freeSpinsLeft > 0 && snapshot.gambleActive === false) return;
      const pragmaticCanvases: Array<{ canvas: Locator; area: number }> = [];
      for (const canvas of await pragmaticFrame.locator("canvas").all()) {
        if (!(await canvas.isVisible().catch(() => false))) continue;
        const box = await canvas.boundingBox();
        if (box !== null && box.width > 0 && box.height > 0) pragmaticCanvases.push({ canvas, area: box.width * box.height });
      }
      pragmaticCanvases.sort((left, right) => right.area - left.area);
      const pragmaticCanvas = pragmaticCanvases[0]?.canvas;
      if (pragmaticCanvas !== undefined) {
        const before = await captureCanvasSnapshot(pragmaticCanvas).catch(() => null);
        const collect = before === null ? null : await findPragmaticGambleCollect(before).catch(() => null);
        if (collect !== null) {
          const semanticCollect = await pragmaticFrame.evaluate<string | null>(`(() => {
            const runtime = window;
            const candidates = [
              "Evt_DataToCode_BonusResultWindow_PressedCollect",
              "Evt_DataToCode_Pressed_GambleCollect",
            ];
            const trigger = runtime.XT?.TriggerEvent;
            if (typeof trigger !== "function") return null;
            const selected = candidates.find((name) => typeof runtime.Vars?.[name] === "string");
            if (selected === undefined) return null;
            Reflect.apply(trigger, runtime.XT, [runtime.Vars[selected]]);
            return selected;
          })()`);
          if (semanticCollect === null) {
            throw new Error("Écran Gamble Pragmatic reconnu mais événement sémantique COLLECT absent; aucun clic risqué envoyé.");
          }
          const deadline = this.now() + 7_000;
          let closed = false;
          while (this.now() <= deadline) {
            await pragmaticFrame.page().waitForTimeout(250);
            const after = await captureCanvasSnapshot(pragmaticCanvas).catch(() => null);
            if (after !== null && await findPragmaticGambleCollect(after).catch(() => null) === null) {
              closed = true;
              break;
            }
          }
          if (!closed) throw new Error("Gamble Pragmatic: action sémantique COLLECT envoyée mais écran toujours visible après 7 secondes; slot abandonnée sans gamble.");
          await this.options.onMilestone?.(
            `Gamble Pragmatic refusé: écran reconnu par OCR, ${semanticCollect} envoyé et disparition vérifiée.`,
          );
          this.lastAdvanceAt = this.now();
          return;
        }
      }
      const pragmaticGambleDeclined = await pragmaticFrame.evaluate<{
        active: boolean;
        triggered: string | null;
        candidates: string[];
      }>(`(() => {
        const runtime = window;
        const vars = runtime.Vars ?? {};
        const getBool = runtime.XT?.GetBool;
        const active = ["CanGamble_Spin", "CanGamble_FreeSpin", "CanGamble_Bonus"]
          .some((name) => {
            const key = vars[name] ?? name;
            if (typeof key !== "string" || typeof getBool !== "function") return false;
            try { return Reflect.apply(getBool, runtime.XT, [key]) === true; } catch { return false; }
          });
        if (!active) return { active: false, triggered: null, candidates: [] };
        const candidates = [
          "Evt_DataToCode_Pressed_GambleCollect",
          "Evt_ToServer_RequestGambleClose",
          "Evt_Internal_GambleCloseCurrentResultWindow",
        ].filter((name) => typeof vars[name] === "string");
        const trigger = runtime.XT?.TriggerEvent;
        if (typeof trigger !== "function" || candidates[0] === undefined) {
          return { active: true, triggered: null, candidates };
        }
        Reflect.apply(trigger, runtime.XT, [vars[candidates[0]]]);
        return { active: true, triggered: candidates[0], candidates };
      })()`);
      if (pragmaticGambleDeclined.active) {
        if (pragmaticGambleDeclined.triggered === null) {
          throw new Error(
            `Gamble Pragmatic actif mais action COLLECT/fermeture introuvable (${pragmaticGambleDeclined.candidates.join(",") || "aucune"}).`,
          );
        }
        await this.options.onMilestone?.(
          `Gamble Pragmatic refusé sans prise de risque via ${pragmaticGambleDeclined.triggered}.`,
        );
        let gambleClosed = false;
        const gambleDeadline = this.now() + 5_000;
        while (this.now() <= gambleDeadline) {
          gambleClosed = await pragmaticFrame.evaluate<boolean>(`(() => {
            const runtime = window;
            const vars = runtime.Vars ?? {};
            const getBool = runtime.XT?.GetBool;
            return !["CanGamble_Spin", "CanGamble_FreeSpin", "CanGamble_Bonus"].some((name) => {
              const key = vars[name] ?? name;
              if (typeof key !== "string" || typeof getBool !== "function") return false;
              try { return Reflect.apply(getBool, runtime.XT, [key]) === true; } catch { return false; }
            });
          })()`);
          if (gambleClosed) break;
          await pragmaticFrame.page().waitForTimeout(250);
        }
        if (!gambleClosed) {
          throw new Error("Gamble Pragmatic: action COLLECT envoyée mais fermeture non confirmée après 5 secondes.");
        }
        this.lastAdvanceAt = this.now();
        return;
      }
      let eventNames: string[] = [];
      let mode: "start" | "collect" | null = null;
      const firstPragmaticStartClick = !this.bonusStartAdvanced;
      const retryPragmaticStartClick =
        this.bonusStartAdvanced &&
        this.pragmaticStartCanvasClicks === 1 &&
        this.pragmaticStartFreeSpinsLeft === snapshot.freeSpinsLeft &&
        this.now() - this.pragmaticStartCanvasClickedAt >= 3_000;
      if (
        this.previousBonus.active &&
        !snapshot.playingFreeSpins &&
        snapshot.freeSpinsLeft > 0 &&
        (firstPragmaticStartClick || retryPragmaticStartClick)
      ) {
        mode = "start";
        eventNames = ["Evt_DataToCode_FreeSpinsWindowStartPressed", "Evt_DataToCode_FreeSpinsWindowPlayPressed"];
      } else if (!this.previousBonus.active && snapshot.freeSpinsLeft === 0 && this.lastBonusGainCents !== null && !this.bonusCollectAdvanced) {
        mode = "collect";
        eventNames = this.lastBonusGainCents > 0
          ? ["Evt_DataToCode_FreeSpinsWindowWinCollectPressed"]
          : ["Evt_DataToCode_FreeSpinsWindowLoseCollectPressed"];
      }
      if (eventNames.length === 0 || mode === null) return;
      const cleared = await this.clearPragmaticOverlay(mode === "collect");
      if (!cleared) return;
      const after = await this.readPragmatic();
      if (mode === "collect") {
        if (after.bonus.active || after.playingFreeSpins || after.freeSpinsLeft !== 0) return;
        this.bonusCollectAdvanced = true;
        await this.options.onMilestone?.("Récapitulatif Pragmatic fermé : disparition visuelle et fin du bonus vérifiées.");
      } else {
        // A readable HUD can coexist with an introduction missed by OCR.
        // Do not latch the start as acknowledged without free-spin progress.
        if (!after.playingFreeSpins && after.spinBusy !== true &&
            after.freeSpinsLeft >= snapshot.freeSpinsLeft) return;
        this.bonusStartAdvanced = true;
        await this.options.onMilestone?.("Introduction Pragmatic fermée : poursuite du bonus, sans nouveau spin payant.");
      }
      this.lastAdvanceAt = this.now();
      return;
    }
    if (this.provider === "hacksaw") {
      if (this.hacksawReplayPending && !this.hacksawReplayDone) {
        await this.reopenHacksawForReplay();
        return;
      }
      const snapshot = this.lastHacksaw;
      if (snapshot === null) return;
      const hacksawFrame = this.hacksawFrame();
      if (this.previousBonus.active && (snapshot.counterValue ?? 0) > 0 && this.hacksawGambleOffer === null) {
        const state = await hacksawFrame.locator("#hacksaw-casino").getAttribute("data-state");
        // Known free-spin play needs no CONTINUE/gamble scan. Keep observing
        // promptly so short count-ups are not missed behind repeated DOM work.
        if (/^featurePlay(?:-(?!gamble)[a-z0-9_-]+)?$/i.test(state ?? "")) { this.bonusStartAdvanced=true; this.hacksawBonusStartDetectedAt=null; return; }
      }
      if (this.hacksawGambleOffer !== null) {
        const canvases: Array<{ canvas: Locator; area: number }> = [];
        for (const canvas of await hacksawFrame.locator("#GameWrapper canvas").all()) {
          if (!(await canvas.isVisible().catch(() => false))) continue;
          const box = await canvas.boundingBox();
          if (box !== null && box.width > 0 && box.height > 0) canvases.push({ canvas, area: box.width * box.height });
        }
        canvases.sort((left, right) => right.area - left.area);
        const selected = exactlyOne(canvases.slice(0, 1), "Canvas gamble Hacksaw");
        const box = await selected.canvas.boundingBox();
        if (box === null) throw new Error("Zone du gamble Hacksaw illisible.");
        const safeChoice = this.hacksawGambleOffer.safeChoice;
        await selected.canvas.click({
          force: true,
          position: { x: Math.round(box.width * safeChoice.xRatio), y: Math.round(box.height * safeChoice.yRatio) },
        });
        const deadline = this.now() + 7_000;
        let closed = false;
        while (this.now() <= deadline) {
          await hacksawFrame.page().waitForTimeout(250);
          const image = await captureCanvasSnapshot(selected.canvas).catch(() => null);
          const offer = image === null ? null : await findHacksawGambleOffer(image).catch(() => null);
          if (offer === null) { closed = true; break; }
        }
        if (!closed) throw new Error("Gamble Hacksaw: FREE SPINS sélectionné mais écran toujours visible après 7 secondes.");
        this.hacksawGambleOffer = null;
        this.hacksawBonusPurchasePending = false;
        this.bonusStartAdvanced = false;
        await this.options.onMilestone?.("Gamble Hacksaw refusé: FREE SPINS garantis sélectionnés et disparition vérifiée.");
        this.lastAdvanceAt = this.now();
        return;
      }
      let visibleGambleMarker = false;
      for (const marker of await hacksawFrame.getByText(/gamble/i).all()) {
        if (!(await marker.isVisible().catch(() => false))) continue;
        const label = ((await marker.textContent().catch(() => "")) ?? "").replace(/\s+/g, " ").trim();
        if (/\bgamble\b/i.test(label) && label.length <= 160) { visibleGambleMarker = true; break; }
      }
      if (visibleGambleMarker) {
        const declineButtons: Locator[] = [];
        for (const button of await hacksawFrame.locator("button").all()) {
          if (!(await button.isVisible().catch(() => false)) || !(await button.isEnabled().catch(() => false))) continue;
          const label = ((await button.textContent().catch(() => "")) ?? "").replace(/\s+/g, " ").trim();
          if (isExplicitSafeGambleDeclineLabel(label)) declineButtons.push(button);
        }
        if (declineButtons.length === 1 && declineButtons[0] !== undefined) {
          await declineButtons[0].evaluate((element) => (element as HTMLElement).click());
          const deadline = this.now() + 5_000;
          let closed = false;
          while (this.now() <= deadline) {
            const visible = await hacksawFrame.getByText(/gamble/i).all().then(async (markers) => {
              for (const candidate of markers) {
                if (!(await candidate.isVisible().catch(() => false))) continue;
                const text = ((await candidate.textContent().catch(() => "")) ?? "").replace(/\s+/g, " ").trim();
                if (/\bgamble\b/i.test(text) && text.length <= 160) return true;
              }
              return false;
            });
            if (!visible) { closed = true; break; }
            await hacksawFrame.page().waitForTimeout(250);
          }
          if (!closed) throw new Error("Gamble Hacksaw: refus envoyé mais dialogue toujours visible après 5 secondes.");
          await this.options.onMilestone?.("Gamble Hacksaw refusé via l’unique action sûre COLLECT/NO/SKIP.");
          this.lastAdvanceAt = this.now();
          return;
        }
        if (declineButtons.length > 1) {
          throw new Error(`Gamble Hacksaw détecté mais actions de refus ambiguës (${declineButtons.length}); aucun clic.`);
        }
        throw new Error("Gamble Hacksaw détecté sans action explicite COLLECT/NO/SKIP/KEEP; aucun clic risqué envoyé.");
      }
      const shouldStart = this.previousBonus.active && !this.bonusStartAdvanced && (snapshot.counterValue ?? 0) > 0;
      const shouldCollect = !this.bonusCollectAdvanced && snapshot.totalWinVisible && (snapshot.counterValue ?? 0) === 0;
      if (!shouldStart && !shouldCollect) return;
      if (shouldCollect) {
        if (snapshot.bonus.gainCents === null) return; // Keep the recap until its final total is captured.
        // Zero is shown while the final free spin is still resolving. Wait for
        // the actual result screen before counting failed OCR attempts.
        const state = await hacksawFrame.locator("#hacksaw-casino").getAttribute("data-state");
        if (!/^featureExit(?:-[a-z0-9_-]+)?$/i.test(state ?? "")) return;
        this.hacksawBonusCollectDetectedAt ??= this.now();
      }
      if (shouldStart && this.hacksawBonusStartDetectedAt === null) this.hacksawBonusStartDetectedAt = this.now();
      const continueButtons: Locator[] = [];
      for (const button of await hacksawFrame.locator("#ContinueBtn").all()) {
        if (await button.isVisible().catch(() => false) && await button.isEnabled().catch(() => false)) continueButtons.push(button);
      }
      let continuedByOcr = false;
      if (continueButtons.length === 1 && continueButtons[0] !== undefined) {
        await continueButtons[0].click({ force: true });
        this.hacksawContinueOcrMisses = 0;
      } else if (continueButtons.length === 0) {
        const canvases: Array<{ canvas: Locator; area: number }> = [];
        for (const canvas of await hacksawFrame.locator("#GameWrapper canvas").all()) {
          if (!(await canvas.isVisible().catch(() => false))) continue;
          const box = await canvas.boundingBox();
          if (box !== null && box.width > 0 && box.height > 0) canvases.push({ canvas, area: box.width * box.height });
        }
        canvases.sort((left, right) => right.area - left.area);
        const selected = exactlyOne(canvases.slice(0, 1), "Canvas Continue Hacksaw");
        const box = await selected.canvas.boundingBox();
        const enterState = await hacksawFrame.locator("#hacksaw-casino").getAttribute("data-state");
        if (shouldStart && enterState === "featureEnter" && !snapshot.blockingDialogVisible && !this.hacksawBonusStartCenterClicked && box !== null) {
          // A stable native entry plus a positive counter identifies this family.
          // Avoid repeated canvas screenshots/OCR while its transition is loading.
          if (this.now() - (this.hacksawBonusStartDetectedAt ?? this.now()) < 750) return;
          this.hacksawBonusStartCenterClicked = true;
          await selected.canvas.click({ force:true, position:{x:box.width/2,y:box.height/2} });
          const deadline = this.now() + 8_000;
          while (this.now() < deadline) {
            await hacksawFrame.page().waitForTimeout(250);
            const next = await this.readHacksaw();
            const state = await hacksawFrame.locator("#hacksaw-casino").getAttribute("data-state");
            if (isHacksawBonusStartProgress({state,counterValue:next.counterValue,baselineCounter:snapshot.counterValue!})) {
              this.bonusStartAdvanced=true;this.hacksawBonusStartDetectedAt=null;this.lastHacksaw=next;
              await this.options.onMilestone?.("Introduction Hacksaw native : clic unique, progression des free spins confirmée sans OCR.");
              return;
            }
          }
          this.lastAdvanceAt = this.now();
          await this.options.onMilestone?.("Introduction Hacksaw inchangée après clic central : bonus conservé, recherche du vrai CONTINUE au prochain passage.");
          return;
        }
        const image = await captureCanvasSnapshot(selected.canvas).catch(() => null);
        const action = image === null ? null : await findHacksawContinue(image).catch(() => null);
        if (box === null || action === null) {
          this.hacksawContinueOcrMisses += 1;
          if (shouldUseHacksawCenterStartFallback({
            bonusStart: shouldStart,
            detectedAt: this.hacksawBonusStartDetectedAt,
            now: this.now(),
            alreadyClicked: this.hacksawBonusStartCenterClicked,
            canvasAvailable: box !== null,
          }) && box !== null) {
            await selected.canvas.click({
              force: true,
              position: { x: Math.round(box.width / 2), y: Math.round(box.height / 2) },
            });
            this.hacksawBonusStartCenterClicked = true;
            this.lastAdvanceAt = this.now();
            await this.options.onMilestone?.("Écran de démarrage bonus Hacksaw: OCR indisponible après 5 s; clic central unique envoyé, vérification bornée pendant 8 s.");
            const baselineCounter = snapshot.counterValue ?? 0;
            const verificationDeadline = this.now() + 8_000;
            while (this.now() < verificationDeadline) {
              await hacksawFrame.page().waitForTimeout(250);
              const afterClick = await this.readHacksaw();
              const nativeState = await hacksawFrame.locator("#hacksaw-casino").getAttribute("data-state");
              if (isHacksawBonusStartProgress({state:nativeState,counterValue:afterClick.counterValue,baselineCounter})) {
                this.bonusStartAdvanced = true;
                this.hacksawBonusStartDetectedAt = null;
                this.lastHacksaw = afterClick;
                await this.options.onMilestone?.(`Clic central Hacksaw validé: état ${nativeState}, compteur free spins ${baselineCounter} → ${afterClick.counterValue}.`);
                return;
              }
            }
            throw new Error("HACKSAW_BONUS_START_STALLED: le clic central unique n'a pas confirmé une lecture native ou une baisse du compteur en 8 s; passage à la slot suivante.");
          }
          if (shouldCollect && this.hacksawBonusCollectDetectedAt !== null && this.now() - this.hacksawBonusCollectDetectedAt >= 1_500) {
            if (await this.recoverHacksawFinalRecap(selected.canvas)) return;
          }
          if ((shouldStart && this.hacksawBonusStartDetectedAt !== null && this.now() - this.hacksawBonusStartDetectedAt < 45_000) || this.hacksawContinueOcrMisses < 4 || (shouldCollect && this.hacksawBonusCollectDetectedAt !== null && this.now() - this.hacksawBonusCollectDetectedAt < 12_000)) {
            if (this.hacksawContinueOcrMisses === 1) {
              await this.options.onMilestone?.("CLICK TO CONTINUE Hacksaw pas encore lisible; nouvelle lecture sûre sans redémarrage.");
            }
            return;
          }
          throw new Error(
            `Bonus Hacksaw ${shouldCollect ? "à collecter" : "à démarrer"}, bouton natif absent et CLICK TO CONTINUE OCR non unique après ${this.hacksawContinueOcrMisses} lectures; aucun clic canvas envoyé.`,
          );
        }
        await selected.canvas.click({
          force: true,
          position: { x: Math.round(box.width * action.xRatio), y: Math.round(box.height * action.yRatio) },
        });
        this.hacksawContinueOcrMisses = 0;
        continuedByOcr = true;
        await this.options.onMilestone?.("Bonus Hacksaw avancé via CLICK TO CONTINUE reconnu par OCR.");
      } else {
        throw new Error(
          `Bonus Hacksaw ${shouldCollect ? "à collecter" : "à démarrer"}, boutons Continue natifs ambigus (${continueButtons.length}); aucun clic canvas envoyé.`,
        );
      }
      if (shouldCollect) {
        const closed = await hacksawFrame.locator("#FeatureTotalWinItem")
          .waitFor({ state: "hidden", timeout: 5_000 })
          .then(() => true)
          .catch(() => false);
        if (closed) {
          this.bonusCollectAdvanced = true;
          this.hacksawBonusCollectDetectedAt = null;
          await this.options.onMilestone?.("Récapitulatif Hacksaw fermé (CLICK TO CONTINUE).");
        } else {
          await this.options.onMilestone?.("Récapitulatif Hacksaw encore visible après le clic; nouvelle tentative sûre au prochain passage.");
        }
      } else {
        this.bonusStartAdvanced = true;
        this.hacksawBonusStartDetectedAt = null;
        await this.options.onMilestone?.(continuedByOcr
          ? "Bonus Hacksaw lancé via le CLICK TO CONTINUE visuel vérifié."
          : "Bonus Hacksaw lancé via le bouton natif Continue.");
      }
      this.lastAdvanceAt = this.now();
    }
  }

  public async buyNolimitBonusForValidation(maxCostCents: number): Promise<{ id: string; costCents: number }> {
    if (this.provider !== "nolimit" || this.nolimitDriver === null) {
      throw new Error("Aucune slot Nolimit active pour l'achat de validation.");
    }
    return this.nolimitDriver.buyCheapestBonusForValidation(maxCostCents);
  }

  public async inspectBonusShop():Promise<BonusShopOffer[]> {
    if(this.provider==='pragmatic'){
      const frame=await this.pragmaticFrame(),config=this.shopBaseConfig;
      if(!config)throw Error('SHOP_MENU_UNAVAILABLE: configuration de mise absente.');
      const before=await this.readPragmatic();
      if(before.bonus.active||before.playingFreeSpins||before.spinBusy===true||before.autoplayActive||before.readyToSpin!==true)throw Error('SHOP_MENU_NOT_IDLE: attendre la fin du round ou du bonus.');
      let openedQuote:BonusShopOffer|null=null;
      try{
        await this.configurePragmaticEnhanced(config,frame,false,false);
        await frame.page().waitForTimeout(150);
        const base=await this.readPragmaticTotalBetCents(frame);
        if(base===null||base!==this.actualBaseStakeCents)throw Error('SHOP_MENU_BASE_UNCONFIRMED: mise normale non confirmée.');
        const result=await frame.evaluate<{offers:BonusShopOffer[];error:string|null;diagnostic?:Record<string,unknown>}>(`(()=>{function __name(f){return f;}return (${pragmaticNativeShop.toString()})(window,${base});})()`);
        if(result.error)throw Error(`SHOP_MENU_UNAVAILABLE: ${result.error}${result.diagnostic?' '+JSON.stringify(result.diagnostic):''}`);
        const offers=checkedBonusShopOffers(result.offers);
        if(offers.every(o=>/^pragmatic-(legacy|grm)-/.test(o.id))){
          const labels=await frame.evaluate<Record<string,string>>(`(()=>{function __name(f){return f;}return (${pragmaticNativeShopLabels.toString()})(window);})()`);
          return offers.map(o=>({...o,label:labels[o.id]??o.label}));
        }
        const opened=await frame.evaluate<{triggered:boolean;error:string|null;controls?:unknown[]}>(`(()=>{function __name(f){return f;}return (${pragmaticNativeShopClick.toString()})(window,${JSON.stringify(offers[0])},'open',${pragmaticNativeShop.toString()});})()`);
        if(!opened.triggered)throw Error(`SHOP_MENU_UNAVAILABLE: ouverture du menu: ${opened.error} ${JSON.stringify(opened.controls??[])}`);
        openedQuote=offers[0]!;await frame.page().waitForTimeout(800);
        const labels=await frame.evaluate<Record<string,string>>(`(()=>{function __name(f){return f;}return (${pragmaticNativeShopLabels.toString()})(window);})()`);
        return offers.map(o=>({...o,label:labels[o.id]??o.label}));
      }finally{
        if(openedQuote){
          const closed=await frame.evaluate<{triggered:boolean;error:string|null}>(`(()=>{function __name(f){return f;}return (${pragmaticNativeShopClick.toString()})(window,${JSON.stringify(openedQuote)},'close',${pragmaticNativeShop.toString()});})()`);
          if(!closed.triggered)throw Error(`SHOP_MENU_CLOSE_UNCONFIRMED: ${closed.error}`);
          await frame.page().waitForTimeout(700);
        }
        await this.configurePragmaticEnhanced(config,frame,undefined,true,this.actualBaseStakeCents);
      }
    }
    if(this.provider!=="hacksaw")throw Error("SHOP_MENU_UNSUPPORTED: famille de menu non validée pour ce provider.");
    const config=this.shopBaseConfig,baseStake=this.actualBaseStakeCents;
    if(!config||baseStake===null)throw Error("SHOP_MENU_BASE_UNCONFIRMED: configuration de mise absente.");
    const normalConfig=structuredClone(config);normalConfig.enhancedSpins.hacksaw.enabled=false;
    const frame=this.hacksawFrame(),menu=frame.locator("#FeatureBuyWindow"),toggle=frame.locator("#FeatureBuyToggle");
    if((await toggle.count())!==1)throw Error("SHOP_MENU_UNAVAILABLE: menu d’achat absent.");
    try {
      await this.configureHacksawEnhanced(normalConfig,baseStake);
      if(!(await menu.isVisible())){
        await toggle.evaluate(el=>(el as HTMLElement).click());
        await menu.waitFor({state:"visible",timeout:3000});
      }
      const base=parseCurrencyCents(await frame.locator("#BetAmountValue").textContent()??'');
      if(base===null||base!==baseStake)throw Error("SHOP_MENU_BASE_UNCONFIRMED: mise normale non confirmée.");
      const raw=await frame.evaluate(()=>Array.from(document.querySelectorAll(".FeatureBuyItem:not(.FeatureSpinItem)"))
        .map(item=>({id:item.querySelector("button[data-feature-buy-id-cta]")?.getAttribute("data-feature-buy-id-cta")??'',
          label:(item.querySelector('[class*="Title"],[class*="Name"],h2,h3')?.textContent??item.textContent??'').replace(/\s+/g,' ').trim(),
          text:item.textContent?.replace(/\s+/g,' ').trim()??''})));
      return checkedBonusShopOffers(raw.map(o=>({id:o.id,label:o.label.slice(0,160),costCents:parseCurrencyCents(o.text)??0,baseStakeCents:base})));
    } finally {
      try {
        if(await menu.isVisible()){
          await toggle.evaluate(el=>(el as HTMLElement).click());
          await menu.waitFor({state:"hidden",timeout:3000});
        }
      } finally { await this.configureHacksawEnhanced(config,baseStake); }
    }
  }

  public async purchaseBonusShop(quote:BonusShopOffer):Promise<void> {
    const actual=(await this.inspectBonusShop()).find(o=>o.id===quote.id);
    if(!actual||!sameBonusQuote(actual,quote))throw Error("SHOP_QUOTE_CHANGED: prix ou variante modifié, aucun achat.");
    if(this.provider==='pragmatic'){
      const frame=await this.pragmaticFrame(),config=this.shopBaseConfig;
      if(!config)throw Error('SHOP_MENU_UNAVAILABLE: configuration absente.');
      await this.configurePragmaticEnhanced(config,frame,false,false);
      await frame.page().waitForTimeout(150);
      const base=await this.readPragmaticTotalBetCents(frame);
      if(base!==quote.baseStakeCents)throw Error('SHOP_QUOTE_CHANGED: mise normale modifiée avant achat.');
      const steps:('open'|'select'|'confirm')[]=/^pragmatic-(legacy|grm)-/.test(quote.id)?['select','confirm']:['open','select','confirm'];
      for(const step of steps){
        let sent:{triggered:boolean;error:string|null;controls?:unknown[]};const visibleDeadline=this.now()+5000;
        do{
          sent=await frame.evaluate(`(()=>{function __name(f){return f;}return (${pragmaticNativeShopClick.toString()})(window,${JSON.stringify(quote)},${JSON.stringify(step)},${pragmaticNativeShop.toString()});})()`);
          if(sent.triggered||sent.error!=='shop-control-not-unique-or-visible')break;
          await frame.page().waitForTimeout(200);
        }while(this.now()<visibleDeadline);
        if(!sent.triggered)throw Error(`SHOP_BUY_NOT_TRIGGERED: ${step}: ${JSON.stringify(sent)}`);
        await frame.page().waitForTimeout(600);
      }
      // Restore the ordinary Golden/stake settings only once the purchased bonus ends.
      this.pendingBaseGameConfig=structuredClone(config);
      const deadline=this.now()+15000;
      while(this.now()<deadline){
        const snapshot=await this.readPragmatic();
        if(snapshot.bonus.active||snapshot.playingFreeSpins||snapshot.freeSpinsLeft>0)return;
        await frame.page().waitForTimeout(150);
      }
      throw Error('SHOP_BUY_UNCONFIRMED: bonus Pragmatic non confirmé ; aucun nouveau clic.');
    }
    const config=this.shopBaseConfig;
    if(!config||this.actualBaseStakeCents!==quote.baseStakeCents)throw Error("SHOP_QUOTE_CHANGED: mise normale modifiée avant achat.");
    const normalConfig=structuredClone(config);normalConfig.enhancedSpins.hacksaw.enabled=false;
    await this.configureHacksawEnhanced(normalConfig,quote.baseStakeCents);
    if(parseCurrencyCents(await this.hacksawFrame().locator("#BetAmountValue").textContent()??'')!==quote.baseStakeCents)throw Error("SHOP_QUOTE_CHANGED: coût majoré encore actif avant achat.");
    this.pendingBaseGameConfig=structuredClone(config);
    await this.buyHacksawBonusForValidation(quote.costCents,quote.id,quote.costCents);
    const deadline=this.now()+10000;
    while(this.now()<deadline){
      const snapshot=await this.readHacksaw();
      if(snapshot.bonus.active)return;
      await this.requireGamePage().waitForTimeout(150);
    }
    throw Error('SHOP_BUY_UNCONFIRMED: aucun bonus confirmé après achat ; ne pas rejouer le clic.');
  }

  public async buyHacksawBonusForValidation(maxCostCents: number, featureId?: string, expectedCostCents?:number): Promise<{ id: string; costCents: number }> {
    if (this.provider !== "hacksaw") throw new Error("Aucune slot Hacksaw active pour l'achat de validation.");
    if (!Number.isSafeInteger(maxCostCents) || maxCostCents <= 0) throw new Error("Plafond d'achat bonus Hacksaw invalide.");
    const frame = this.hacksawFrame();
    const menu = frame.locator("#FeatureBuyWindow");
    if (!(await menu.isVisible().catch(() => false))) {
      const toggle = frame.locator("#FeatureBuyToggle");
      if ((await toggle.count()) !== 1 || !(await toggle.isVisible())) throw new Error("Menu Feature Buy Hacksaw indisponible.");
      await toggle.evaluate((element) => (element as HTMLElement).click());
      await menu.waitFor({ state: "visible", timeout: 3_000 });
    }
    const options = await frame.evaluate(() => Array.from(document.querySelectorAll(".FeatureBuyItem:not(.FeatureSpinItem)"))
      .map((item) => {
        const button = item.querySelector<HTMLButtonElement>("button[data-feature-buy-id-cta]");
        return button === null ? null : {
          id: button.getAttribute("data-feature-buy-id-cta") ?? "",
          description: item.textContent?.replace(/\s+/g, " ").trim() ?? "",
        };
      })
      .filter((value): value is { id: string; description: string } => value !== null));
    const selected = options
      .map((option) => ({ ...option, costCents: parseCurrencyCents(option.description) }))
      .filter((option): option is typeof option & { costCents: number } => option.costCents !== null && option.costCents <= maxCostCents && (featureId === undefined || option.id === featureId))
      .sort((left, right) => left.costCents - right.costCents)[0];
    if (selected === undefined) throw new Error(`Aucun bonus Hacksaw disponible sous ${(maxCostCents / 100).toFixed(2)} €.`);
    if(expectedCostCents!==undefined&&selected.costCents!==expectedCostCents)throw Error("SHOP_QUOTE_CHANGED: prix modifié avant clic.");
    const button = frame.locator(`button[data-feature-buy-id-cta="${selected.id}"]`);
    if ((await button.count()) !== 1 || !(await button.isVisible())) throw new Error("Bouton d'achat bonus Hacksaw non unique.");
    await this.options.onMilestone?.(
      `Validation Hacksaw: achat ${selected.id} à ${(selected.costCents / 100).toFixed(2)} € sélectionné; aucun gamble ne sera accepté.`,
    );
    this.hacksawBonusPurchasePending = true;
    await button.evaluate((element) => (element as HTMLElement).click());
    const deadline = this.now() + 5_000;
    let confirmed = false;
    while (this.now() <= deadline) {
      const okButtons: Locator[] = [];
      for (const candidate of await frame.locator("button").all()) {
        if (!(await candidate.isVisible().catch(() => false)) || !(await candidate.isEnabled().catch(() => false))) continue;
        const label = ((await candidate.textContent().catch(() => "")) ?? "").replace(/\s+/g, " ").trim();
        if (/^(?:ok|buy|confirm)$/i.test(label)) okButtons.push(candidate);
      }
      if (okButtons.length > 1) throw new Error(`Confirmation achat bonus Hacksaw ambiguë (${okButtons.length}); aucun clic.`);
      if (okButtons[0] !== undefined) {
        await okButtons[0].evaluate((element) => (element as HTMLElement).click());
        confirmed = true;
        break;
      }
      await frame.page().waitForTimeout(100);
    }
    if (!confirmed) throw new Error("Confirmation d'achat bonus Hacksaw introuvable.");
    await frame.page().waitForTimeout(750);
    return { id: selected.id, costCents: selected.costCents };
  }

  private async dismissPragmaticPromoOverlay(): Promise<void> {
    const frame = await this.pragmaticFrame();
    const candidates: Array<{ canvas: Locator; area: number; topmost: boolean }> = [];
    for (const canvas of await frame.locator("canvas").all()) {
      if (!(await canvas.isVisible().catch(() => false))) continue;
      const box = await canvas.boundingBox();
      if (box === null || box.width <= 0 || box.height <= 0) continue;
      const topmost = await canvas.evaluate((element) => {
        const rect = element.getBoundingClientRect();
        return document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2) === element;
      }).catch(() => false);
      candidates.push({ canvas, area: box.width * box.height, topmost });
    }
    candidates.sort((left, right) => Number(right.topmost) - Number(left.topmost) || right.area - left.area);
    const canvas = candidates[0]?.canvas;
    if (canvas === undefined) return;
    const box = await canvas.boundingBox();
    if (box === null) return;
    const screenshot = await captureCanvasSnapshot(canvas).catch(() => null);
    if (screenshot === null) return;
    const button = await findPragmaticPromoOk(screenshot).catch(() => null);
    if (button === null) return;
    const x = button.x * box.width / button.imageWidth;
    const y = button.y * box.height / button.imageHeight;
    // The OCR must identify the unique promo heading and a single OK control before any click.
    await canvas.click({ force: true, position: { x, y } });
    await this.requireGamePage().waitForTimeout(900);
    const after = await captureCanvasSnapshot(canvas).catch(() => null);
    const stillVisible = after === null ? null : await findPragmaticPromoOk(after).then((result) => result !== null).catch(() => null);
    await this.options.recorder.event("pragmatic-promo-overlay-dismissed", {
      eventCardsRecognized: true,
      confirmationClickSent: true,
      clickX: Math.round(x),
      clickY: Math.round(y),
      verifiedClosed: stillVisible === false,
    });
    if (stillVisible !== false) {
      throw new Error("Fenêtre événementielle Pragmatic reconnue mais fermeture visuelle non confirmée; aucun spin lancé.");
    }
    await this.options.onMilestone?.("Événement Pragmatic Weekly Wheel / Daily Tournament fermé; disparition vérifiée.");
  }

  private async reopenHacksawForReplay(): Promise<void> {
    const item = this.activeItem;
    if (item === null || item.provider !== "hacksaw") throw new Error("Machine Hacksaw à rejouer inconnue.");
    this.hacksawReplayPending = false;
    await this.options.onMilestone?.("BONUS OBTENU");
    await this.options.recorder.event("hacksaw-bonus-obtained", { slotName: item.slotName, roundsPlayed: this.roundsPlayed });

    const previousPage = this.requireGamePage();
    this.provider = null;
    await previousPage.reload({ waitUntil: "domcontentloaded", timeout: 60_000 });
    const page = previousPage;
    const celsius = new CelsiusAdapter(page, this.options.runnerConfig.baseUrl, this.options.recorder, this.options.onMilestone);
    const deadline = this.now() + 25_000;
    let replayConfirmed = false;
    while (this.now() <= deadline) {
      const entry = await enterProviderGame(page, new URL(this.options.runnerConfig.baseUrl).origin, { hacksawInterruptedRound: "replay" });
      if (entry.provider !== "hacksaw") throw new Error(`Provider ${entry.provider} ouvert au rejeu de ${item.slotName}.`);
      if (entry.action === "replay-confirmed") { replayConfirmed = true; break; }
      await page.waitForTimeout(500);
    }
    if (!replayConfirmed) throw new Error("Option de rejeu du bonus Hacksaw non détectée après rechargement.");
    await celsius.ensureGameFullscreen(page, item.slotName);
    await this.options.videoCapture?.attach(page);

    this.gamePage = page;
    this.provider = "hacksaw";
    this.hacksawReplayDone = true;
    this.bonusStartAdvanced = false;
    this.bonusCollectAdvanced = false;
    this.lastAdvanceAt = this.now();
    const activeDeadline = this.now() + 20_000;
    let snapshot = await this.readHacksaw();
    while (!snapshot.bonus.active && this.now() <= activeDeadline) {
      await page.waitForTimeout(250);
      snapshot = await this.readHacksaw();
    }
    if (!snapshot.bonus.active) throw new Error("Bonus Hacksaw non actif après confirmation du rejeu.");
    this.lastHacksaw = snapshot;
    this.previousBonus = snapshot.bonus;
    await this.options.onMilestone?.("BONUS REJOUÉ");
    await this.options.recorder.event("hacksaw-bonus-replay-confirmed", { slotName: item.slotName });
  }

  public async stop(): Promise<void> {
    try { await this.performStop(); } finally { await this.parkPresentationPointer(); }
  }

  private async performStop(): Promise<void> {
    this.nativeAutoplayStopRequested = true;
    if (this.provider === "nolimit") {
      await this.nolimitDriver?.stop();
    } else if (this.provider === "hacksaw") {
      const frame = this.hacksawFrame();
      const readNativeHacksawAutoplayState = async (): Promise<{ state: string; stopVisible: boolean; featureVisible: boolean }> =>
        frame.evaluate<{ state: string; stopVisible: boolean; featureVisible: boolean }>(`(() => {
          const visible = (element) => {
            if (!(element instanceof HTMLElement)) return false;
            const rect = element.getBoundingClientRect();
            const style = getComputedStyle(element);
            return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
          };
          const container = document.querySelector("#hacksaw-casino");
          return {
            state: container?.getAttribute("data-state") ?? "",
            stopVisible: visible(document.querySelector("#StopAutoplayBtn")),
            featureVisible: visible(document.querySelector("#FeatureCounterItem")) || visible(document.querySelector("#FeatureTotalWinItem")),
          };
        })()`);
      const dispatchNativeHacksawStop = async (): Promise<void> => frame.evaluate<void>(`(() => {
        const state = document.querySelector("#hacksaw-casino")?.getAttribute("data-state") ?? "";
        if (/^feature/i.test(state)) return;
        // Native STOP publishes ui.stopAutoplay. Dispatching keys or transformed
        // pointer coordinates alone is unreliable in the isolated presentation.
        const ui = window.hacksawCasino?.PubSub?.getChannel?.("ui");
        if (typeof ui?.publish !== "function") throw new Error("Hacksaw native stop channel unavailable");
        ui.publish("stopAutoplay");
        // The button's own handler also updates the displayed state/counter.
        const button = document.querySelector("#StopAutoplayBtn");
        if (button instanceof HTMLElement) button.click();
      })()`);
      // A feature takes ownership of the controls during the final paid spin.
      // Yield to observe()/advanceBonus(); waiting for idle here deadlocks entry.
      const yieldToFeature = async (state: { state: string; featureVisible: boolean }): Promise<boolean> => {
        if (!/^feature(?:Enter|Play|Exit)(?:-[a-z0-9_-]+)?$/i.test(state.state) && !state.featureVisible) return false;
        this.nativeAutoplayStopRequested = false;
        await this.options.recorder.event("hacksaw-stop-yield-to-bonus", { state: state.state });
        await this.options.onMilestone?.("Bonus détecté pendant l’arrêt autoplay; priorité à sa progression.");
        return true;
      };
      if (await yieldToFeature(await readNativeHacksawAutoplayState())) return;
      const visibleStopButtons: Locator[] = [];
      for (const candidate of await frame.locator("#StopAutoplayBtn").all()) {
        if (await candidate.isVisible().catch(() => false)) visibleStopButtons.push(candidate);
      }
      if (visibleStopButtons.length > 1) {
        throw new Error(`Contrôle STOP Hacksaw visible non unique (${visibleStopButtons.length}).`);
      }
      if (visibleStopButtons[0] !== undefined) {
        // Certains builds Hacksaw (notamment SixSixSix) écoutent les événements
        // pointeur et ignorent HTMLElement.click(). Un clic Playwright exact sur
        // l'unique contrôle visible reproduit la vraie interaction utilisateur.
        await dispatchNativeHacksawStop();
      }
      let stopped = !this.nativeAutoplay;
      const stopDeadline = this.now() + Math.min(8_000, this.options.runnerConfig.safety.settlementTimeoutMs);
      while (!stopped && this.now() <= stopDeadline) {
        const nativeState = await readNativeHacksawAutoplayState();
        if (await yieldToFeature(nativeState)) return;
        if (/^(?:autoplayend|idle)$/i.test(nativeState.state) && !nativeState.stopVisible) {
          stopped = true;
          break;
        }
        // Pendant gameRoundEnter/play, le raccourci est volontairement ignoré
        // par Hacksaw. On le réémet donc seulement lorsque le spin courant rend
        // l'état autoplay, puis on exige autoplayEnd/idle comme postcondition.
        await dispatchNativeHacksawStop();
        await frame.page().waitForTimeout(100);
      }
      if (this.nativeAutoplay && !stopped) {
        throw new Error("HACKSAW_AUTOPLAY_STOP_PENDING: règlement du round ou entrée de bonus encore attendu.");
      }
      if (stopped) await this.options.onMilestone?.("Autoplay Hacksaw coupé; règlement du spin courant attendu.");
      // Après un bonus, Hacksaw peut rendre le menu autoplay visible alors
      // que le lot est déjà arrêté. Ce menu masque #PlaceBetBtn et ferait
      // croire indéfiniment au service qu'un round est encore actif.
      const menu = frame.locator("#AutoplayNav");
      if ((await menu.count()) === 1 && await menu.isVisible().catch(() => false)) {
        const toggle = frame.locator("#AutoplayBtn");
        if ((await toggle.count()) !== 1 || !(await toggle.isVisible().catch(() => false))) {
          throw new Error("Menu autoplay Hacksaw ouvert sans contrôle de fermeture unique.");
        }
        await toggle.evaluate((element) => (element as HTMLElement).click());
        await menu.waitFor({ state: "hidden", timeout: 3_000 });
        await this.options.onMilestone?.("Menu autoplay Hacksaw fermé après arrêt du lot.");
      }
    } else if (this.provider === "pragmatic") {
      const frame = await this.pragmaticFrame();
      await frame.evaluate(() => {
        const runtime = window as unknown as {
          Vars?: Record<string, unknown>;
          XT?: { TriggerEvent?: (...args: unknown[]) => unknown };
          HPFUNC?: { stopAutoplay?: (...args: unknown[]) => unknown };
        };
        const event = runtime.Vars?.Evt_DataToCode_StopAutoplay;
        const trigger = runtime.XT?.TriggerEvent;
        if (typeof event === "string" && typeof trigger === "function") {
          Reflect.apply(trigger, runtime.XT, [event]);
          return;
        }
        const fallback = runtime.HPFUNC?.stopAutoplay;
        if (typeof fallback === "function") Reflect.apply(fallback, runtime.HPFUNC, []);
      });
    }
    if (this.spinPending && this.now() - this.spinStartedAt < 60_000) {
      await this.options.recorder.event("automod-stop-pending-round", { provider: this.provider });
    }
  }

  public async captureDiagnostics(reason: string): Promise<string | null> {
    const page = this.gamePage;
    if (page === null || page.isClosed()) return null;
    const capturedAt = new Date().toISOString();
    const domInventory = await this.options.recorder.captureWithNavigationRetry(page).catch(() => null);
    let providerState: unknown = null;
    if (this.provider === "hacksaw") {
      providerState = await this.hacksawFrame().evaluate(() => {
        const visible = (selector: string) => {
          const element = document.querySelector(selector);
          if (!(element instanceof HTMLElement)) return false;
          const style = getComputedStyle(element);
          const rect = element.getBoundingClientRect();
          return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden";
        };
        return {
          featureMenuVisible: visible("#FeatureBuyWindow"),
          dialogVisible: visible("#DialogWindow"),
          autoplayMenuVisible: visible("#AutoplayNav"),
          autoplayStopVisible: visible("#StopAutoplayBtn"),
          featureToggleText: document.querySelector("#FeatureBuyToggle")?.textContent?.replace(/\s+/g, " ").trim() ?? null,
          autoplayCounter: document.querySelector("#AutoplayCounter")?.textContent?.trim() ?? null,
          featureOptions: Array.from(document.querySelectorAll(".FeatureBuyItem")).map((item) => ({
            className: item.getAttribute("class"),
            selected: item.classList.contains("is-selected"),
            text: item.textContent?.replace(/\s+/g, " ").trim() ?? "",
            action: item.querySelector("button[data-feature-buy-id-cta]")?.textContent?.replace(/\s+/g, " ").trim() ?? null,
          })),
        };
      }).catch(() => null);
    } else if (this.provider === "pragmatic") {
      const snapshot = await this.readPragmatic().catch(() => null);
      const frame = await this.pragmaticFrame();
      const runtime = await frame.evaluate(() => {
        // tsx/esbuild peut entourer les fonctions locales sérialisées par son
        // helper __name, absent du contexte isolé Playwright.
        Object.defineProperty(globalThis, "__name", {
          configurable: true,
          value: Function("value", "return value"),
        });
        const root = window as unknown as Record<string, unknown>;
        const interesting = /ante|gold|enhanc|bet|stake|win|payout|award|feature|bonus|free.?spin|gamble|double|collect|buy/i;
        const primitive = (value: unknown): unknown => {
          if (value === null || ["string", "number", "boolean"].includes(typeof value)) return value;
          return undefined;
        };
        const inspect = (value: unknown): Record<string, unknown> => {
          if ((typeof value !== "object" && typeof value !== "function") || value === null) return {};
          const output: Record<string, unknown> = {};
          const names = new Set<string>();
          let cursor: object | null = value as object;
          for (let depth = 0; depth < 3 && cursor !== null; depth += 1) {
            try {
              for (const name of Object.getOwnPropertyNames(cursor)) if (interesting.test(name)) names.add(name);
              cursor = Object.getPrototypeOf(cursor) as object | null;
            } catch {
              cursor = null;
            }
          }
          for (const name of [...names].slice(0, 250)) {
            try {
              const member = (value as Record<string, unknown>)[name];
              const direct = primitive(member);
              output[name] = direct !== undefined
                ? direct
                : typeof member === "function"
                  ? { type: "function", arity: member.length }
                  : { type: typeof member };
            } catch {
              output[name] = { type: "unreadable" };
            }
          }
          return output;
        };
        const hpvars = root.HPVARS;
        const coinManager = root.CoinManager;
        const purchaseRuntime = Object.fromEntries([
          "FeaturePurchaseItem", "FeaturePurchaseVars", "FeaturePurchaseData", "FeaturePurchaseManager",
          "FeaturePurchaseV2", "FeaturePurchaseWindow", "FeaturePurchaseOption", "BonusGamble_PoT",
        ].map((name) => [name, inspect(root[name])]));
        const inspectAll = (value: unknown): Record<string, unknown> => {
          if ((typeof value !== "object" && typeof value !== "function") || value === null) return {};
          const output: Record<string, unknown> = {};
          for (const name of Object.getOwnPropertyNames(value as object).slice(0, 250)) {
            try {
              const member = (value as Record<string, unknown>)[name];
              const direct = primitive(member);
              output[name] = direct !== undefined
                ? direct
                : typeof member === "function"
                  ? { type: "function", arity: member.length }
                  : { type: typeof member };
            } catch {
              output[name] = { type: "unreadable" };
            }
          }
          return output;
        };
        const purchasePrototypes = Object.fromEntries([
          "FeaturePurchaseManager", "FeaturePurchaseV2", "FeaturePurchaseWindow", "BonusGamble_PoT",
        ].map((name) => {
          const candidate = root[name];
          const prototype = typeof candidate === "function"
            ? (candidate as { prototype?: unknown }).prototype
            : null;
          return [name, inspectAll(prototype)];
        }));
        return {
          windowKeys: Object.getOwnPropertyNames(window).filter((name) => interesting.test(name)).slice(0, 250),
          hpvars: inspect(hpvars),
          hpfunc: inspect(root.HPFUNC),
          vars: inspect(root.Vars),
          coinManager: inspect(coinManager),
          coinManagerInstance: inspect(typeof coinManager === "object" && coinManager !== null
            ? (coinManager as Record<string, unknown>).instance
            : null),
          purchaseRuntime,
          purchasePrototypes,
          featurePurchaseState: inspect(typeof hpvars === "object" && hpvars !== null
            ? (hpvars as Record<string, unknown>).FeaturePurchase
            : null),
          receivedSpinResponse: inspect(typeof hpvars === "object" && hpvars !== null
            ? (hpvars as Record<string, unknown>).ReceivedSpinResponse
            : null),
          receivedFreeSpinsResponse: inspect(typeof hpvars === "object" && hpvars !== null
            ? (hpvars as Record<string, unknown>).ReceivedFreeSpinsResponse
            : null),
          visibleText: document.body?.innerText?.replace(/\s+/g, " ").trim().slice(0, 4_000) ?? "",
        };
      }).catch((error: unknown) => ({
        diagnosticError: error instanceof Error ? error.message : String(error),
      }));
      providerState = snapshot === null ? null : {
        autoplayActive: snapshot.autoplayActive,
        autoplayRemaining: snapshot.autoplayRemaining,
        readyToSpin: snapshot.readyToSpin,
        spinBusy: snapshot.spinBusy,
        bonusActive: snapshot.bonus.active,
        freeSpinsLeft: snapshot.freeSpinsLeft,
        telemetryCount: snapshot.telemetryCount,
        lastSpinWinCents: snapshot.lastSpinWinCents,
        runtime,
        telemetry: await readProviderTelemetry(this.requireGamePage()).catch(() => []),
      };
    } else if (this.provider === "nolimit") {
      providerState = this.nolimitDriver?.snapshot() ?? null;
    }
    const statePath = await this.options.recorder.writeJson(`provider-state-${Date.now()}.json`, {
      capturedAt,
      reason,
      activeItem: this.activeItem,
      provider: this.provider,
      roundsPlayed: this.roundsPlayed,
      nativeAutoplay: this.nativeAutoplay,
      autoplayLastRemaining: this.autoplayLastRemaining,
      baseStakeCents: this.actualBaseStakeCents,
      chargedStakeCents: this.provider === "hacksaw"
        ? this.hacksawChargedStakeCents
        : this.provider === "nolimit"
          ? this.nolimitDriver?.snapshot().chargedStakeCents ?? null
          : this.expectedChargedStakeCents.pragmatic,
      providerState,
      domInventory,
    });
    await this.options.recorder.event("automod-diagnostic-captured", { reason, statePath, domInventory });
    return this.options.recorder.directory;
  }

  /** Explicit benchmark-only action, before autoplay; never used by normal Automod. */
  public async configureMinimumHacksawStakeForBenchmark(): Promise<ActiveSlotConfiguration> {
    if (this.provider !== "hacksaw") throw new Error("Benchmark minimal réservé à Hacksaw.");
    const frame = this.hacksawFrame();
    const configuration = await this.activeConfiguration();
    if (configuration.enhancedMultiplier !== 1) throw new Error("Golden Bet encore active; aucun benchmark.");
    const enhancedNoticeVisible = await frame.evaluate(() => {
      const notice = document.querySelector("#FeatureBuyActiveModifierNotice");
      if (!(notice instanceof HTMLElement)) return false;
      const style = getComputedStyle(notice), rect = notice.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" &&
        style.opacity !== "0" && /activated|activé|disable|désactiver/i.test(notice.textContent ?? "");
    });
    if (enhancedNoticeVisible) throw new Error("Indicateur FeatureSpins actif malgré configuration OFF; aucun benchmark.");
    const ready = await frame.locator("#PlaceBetBtn").evaluate(element => {
      const style = getComputedStyle(element), rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none" &&
        !element.classList.contains("is-disabled") && !(element instanceof HTMLButtonElement && element.disabled);
    });
    if (!ready) throw new Error("Machine non idle avant mise minimale; aucun spin de benchmark.");
    const minimum = await selectMinimumStake({
      read: async () => parseCurrencyCents((await frame.locator("#BetAmountValue").textContent()) ?? "") ?? NaN,
      canDecrease: async () => {
        const button = frame.locator("#BetAmountDecrease");
        if (!(await button.isVisible())) throw new Error("Contrôle de mise absent; minimum non prouvé.");
        return await button.isEnabled() && !(await button.evaluate(element =>
          element.classList.contains("is-disabled") || element.classList.contains("is-reached") || element.getAttribute("aria-disabled") === "true"));
      },
      decrease: async () => { await frame.locator("#BetAmountDecrease").click(); },
      wait: async () => { await frame.page().waitForTimeout(100); },
    });
    this.actualBaseStakeCents = minimum;
    this.hacksawVerifiedBaseStakeCents = minimum;
    this.expectedChargedStakeCents.hacksaw = minimum;
    const result = await this.activeConfiguration();
    if (result.chargedStakeCents !== minimum || result.enhancedMultiplier !== 1) throw new Error("Coût minimal sans Golden non confirmé.");
    return result;
  }

  public async activeConfiguration(): Promise<ActiveSlotConfiguration> {
    const baseStakeCents = this.actualBaseStakeCents;
    if (!Number.isSafeInteger(baseStakeCents) || baseStakeCents <= 0) throw new Error("Mise de base active inconnue.");
    if (this.provider === "hacksaw") {
      const frame = this.hacksawFrame();
      const chargedText = await frame.locator("#FeatureBuyAmountValue").textContent().catch(() => null);
      const normalText = await frame.locator("#BetAmountValue").textContent().catch(() => null);
      const charged = this.hacksawEnhancedActive
        ? this.hacksawChargedStakeCents ?? parseCurrencyCents(chargedText ?? "")
        : parseCurrencyCents(normalText ?? "");
      if (charged === null || charged < baseStakeCents) throw new Error("Coût réel Hacksaw illisible.");
      return { provider: "hacksaw", baseStakeCents, chargedStakeCents: charged, enhancedMultiplier: charged / baseStakeCents };
    }
    if (this.provider === "pragmatic") {
      const charged = await this.readPragmaticTotalBetCents(await this.pragmaticFrame());
      if (charged === null || charged < baseStakeCents) throw new Error("Coût réel Pragmatic illisible.");
      return { provider: "pragmatic", baseStakeCents, chargedStakeCents: charged, enhancedMultiplier: charged / baseStakeCents };
    }
    if (this.provider === "nolimit") {
      const snapshot = this.nolimitDriver?.snapshot();
      const charged = snapshot?.chargedStakeCents;
      if (charged === null || charged === undefined || charged < baseStakeCents) throw new Error("Coût réel Nolimit illisible.");
      return { provider: "nolimit", baseStakeCents, chargedStakeCents: charged, enhancedMultiplier: charged / baseStakeCents };
    }
    throw new Error("Aucune machine active.");
  }

  public async close(): Promise<void> {
    this.invalidateWinPresentation();
    // Ne publie jamais le lobby, une navigation intermédiaire ou une page en
    // cours de démontage. open() rattache la capture après le plein écran.
    await this.options.videoCapture?.stop().catch(() => undefined);
    await this.restoreHacksawScenePresentation();
    const page = this.gamePage;
    this.provider = null;
    this.activeItem = null;
    this.resetSlotState();
    if (page === null || page.isClosed()) {
      this.gamePage = null;
      return;
    }
    if (page !== this.lobbyPage) {
      await page.close().catch(() => undefined);
      const lobby = this.lobbyPage;
      this.gamePage = lobby !== null && !lobby.isClosed() ? lobby : null;
      return;
    }
    // La page Celsius qui héberge la slot reste ouverte. Le prochain open() utilise
    // directement sa recherche interne, sans détour par l'accueil ni perte du VPN.
    this.gamePage = page;
  }

  public async dispose(): Promise<void> {
    this.invalidateWinPresentation();
    await this.options.videoCapture?.stop().catch(() => undefined);
    await this.close().catch(() => undefined);
    await this.browser?.close().catch(() => undefined);
    this.browser = null;
    this.lobbyPage = null;
    await this.profileLock?.release().catch(() => undefined);
    this.profileLock = null;
  }

  public async restartSession(): Promise<void> {
    await this.options.onMilestone?.("Récupération Automod: redémarrage complet de Chrome.");
    await this.dispose();
  }

  private requireGamePage(): Page {
    if (this.gamePage === null || this.gamePage.isClosed()) throw new Error("Page de jeu active absente.");
    return this.gamePage;
  }

  public context(): BrowserContext | null { return this.browser?.context ?? null; }

  public expectChargedStake(provider: ProviderKey, chargedStakeCents: number): void {
    if (!Number.isSafeInteger(chargedStakeCents) || chargedStakeCents <= 0) throw new Error("Coût attendu invalide.");
    this.expectedChargedStakeCents[provider] = chargedStakeCents;
  }
}


