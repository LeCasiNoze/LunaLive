import { reduceAutomod, type AutomodItem, type AutomodRuntimeState } from "./automod-domain.js";
import type { AutomodConfig } from "./automod-config.js";
import { AutomodStateStore } from "./automod-store.js";
import type { BigWinRecorder } from "./big-win-store.js";
import type { ProviderKey } from "./provider-capabilities.js";
import type { GainJournal, GainRecord } from "./gain-journal.js";
import type { SessionStatsStore, SessionStats } from "./session-stats-store.js";
import type { SessionDataJournal } from "./session-data-journal.js";
import type { ContextRecoveryResult } from "./context-recovery.js";
import type { AutomodShop } from './automod-shop.js';
import type { BonusShopOffer } from './bonus-shop.js';

export interface AutomodQueue {
  nextSupportedCall(
    allowedProviders: ReadonlySet<ProviderKey>,
    onSkipped?: (call: { id: string; slotName: string }, reason: string) => void | Promise<void>,
  ): Promise<AutomodItem | null>;
  randomSlot(allowedProviders: ReadonlySet<ProviderKey>, excludeNames?: readonly string[]): Promise<AutomodItem>;
  removeCall(callId: string): Promise<boolean>;
  isCallProcessed?(callId: string): Promise<boolean>;
  isCallPending?(callId: string): Promise<boolean>;
}

export type SlotEvent =
  | { type: "bonus-started" }
  | { type: "bonus-ended"; gainCents: number };

export interface SlotObservation {
  idle: boolean;
  roundsPlayed: number;
  events: SlotEvent[];
  baseStakeCents?: number;
  autoplayActive?: boolean;
  autoplayRemaining?: number | null;
  bonusActive?: boolean;
  roundActive?: boolean;
  roundPayoutsCents?: Array<number | null>;
  winPresentations?: Array<{ id: string; gainCents: number | null; source: string }>;
  bonusProgress?: string;
}

export interface SlotExecutor {
  inspectBonusShop?():Promise<BonusShopOffer[]>;
  purchaseBonusShop?(quote:BonusShopOffer):Promise<void>;
  activeConfiguration?(): Promise<{ baseStakeCents: number; chargedStakeCents: number; enhancedMultiplier: number }>;
  open(item: AutomodItem, config: AutomodConfig): Promise<{ existingBonus: boolean } | void>;
  prepareBaseGame?(): Promise<boolean>;
  openCapturedBonus?(item: AutomodItem, config: AutomodConfig): Promise<void>;
  /** Résout seulement après refus NON et preuve idle, bonus inactif, sans nouveau spin. */
  discardCapturedHacksawBonus?(item: AutomodItem, config: AutomodConfig): Promise<void>;
  startAutoplay(spins: number): Promise<number>;
  observe(): Promise<SlotObservation>;
  spin(): Promise<void>;
  advanceBonus(): Promise<void>;
  stop(): Promise<void>;
  close(): Promise<void>;
  captureDiagnostics?(reason: string): Promise<string | null>;
  restartSession?(): Promise<void>;
  recoverContext?(): Promise<ContextRecoveryResult>;
}

export interface AutomodServiceOptions {
  config: AutomodConfig;
  stateStore: AutomodStateStore;
  queue: AutomodQueue;
  executor: SlotExecutor;
  now?: () => number;
  sleep?: (ms: number) => Promise<void>;
  onState?: (state: AutomodRuntimeState) => void | Promise<void>;
  onLog?: (message: string) => void | Promise<void>;
  onSessionStats?: (stats: { bonusCount: number; bigWinCents: number | null }) => void;
  bigWinRecorder?: BigWinRecorder;
  gainJournal?: Pick<GainJournal, "record">;
  sessionStatsStore?: SessionStatsStore;
  sessionDataJournal?: SessionDataJournal;
  pointsOutbox?: { record(event: import("./session-data-journal.js").SessionDataEvent): Promise<unknown> };
  shop?:AutomodShop;
  keepSlotOpenOnStop?: boolean;
  executorActionTimeoutMs?: number;
  executorOpenTimeoutMs?: number;
  progressTimeoutMs?: number;
}

const ROUND_DRAIN_TIMEOUT_MS = 60_000;

export class AutomodService {
  private readonly now: () => number;
  private readonly sleep: (ms: number) => Promise<void>;
  private readonly executorActionTimeoutMs: number;
  private readonly executorOpenTimeoutMs: number;
  private readonly progressTimeoutMs: number;
  private state: AutomodRuntimeState | null = null;
  private stopping = false;
  private recentRandomSlots: string[] = [];
  private activeBaseStakeCents: number;
  private pendingConfig: AutomodConfig | null = null;
  private visitConfig:AutomodConfig|null=null;
  private get currentConfig():AutomodConfig{return this.visitConfig??this.options.config;}
  private executorRoundOffset = 0;
  private controlRequest: "skip" | "restart" | null = null;
  private exitDrainStarted = false;
  private exitDrainStartedAt: number | null = null;
  private lastObservedPayoutCents: number | null = null;
  private settledPayoutLabel(): string {
    return this.lastObservedPayoutCents === null ? "non confirmé" : `${(this.lastObservedPayoutCents / 100).toFixed(2)} €`;
  }
  private sessionBonusCount = 0;
  private sessionBigWinCents: number | null = null;
  private durableStats: SessionStats | null = null;
  private readonly observedBonuses = new Set<string>();

  private async recordData(kind: string, data: Record<string, unknown>, identity: string, context = this.state): Promise<void> {
    if (!this.durableStats || !this.options.sessionDataJournal) return;
    const event = { schemaVersion: 1 as const, id: `${kind}:${context?.visitId ?? "session"}:${identity}`,
      sessionId: this.durableStats.sessionId, recordedAt: new Date(this.now()).toISOString(), kind,
      visitId: context?.visitId ?? null, item: context?.active ?? null,
      data: { ...data, baseStakeCents: context?.verifiedBaseStakeCents ?? data.baseStakeCents ?? null,
        inheritedBonus: context?.entryBonusPending === true, purchaseOrderId: (context?.bonus?.endedAt===null||kind==='bonus-ended'?context?.bonus?.purchaseOrderId:null) ?? context?.shopVisit?.purchaseOrderId ?? null,
        bonusActive: context?.bonus?.endedAt === null } };
    await this.options.sessionDataJournal.record(event);
    await this.options.pointsOutbox?.record(event);
  }

  private async countActiveBonus(): Promise<void> {
    if (!this.state?.active || !this.state.bonus) return;
    const id = `${this.state.active.key}:${this.state.bonus.startedAt}`;
    if (this.observedBonuses.has(id)) return;
    if (this.options.sessionStatsStore) this.durableStats = await this.options.sessionStatsStore.bonusStarted(id);
    this.observedBonuses.add(id);
    this.sessionBonusCount += 1;
    this.publishSessionStats();
  }

  private async recordGain(value: GainRecord): Promise<void> {
    const item = this.state?.active;
    const gain: GainRecord = { ...value, sessionId: this.durableStats?.sessionId,
      itemKey: item?.key, itemSource: item?.source, callId: item?.callId ?? null,
      requestedBy: item?.requestedBy ?? null, imageUrl: item?.imageUrl ?? null,
      baseStakeCents: this.state?.verifiedBaseStakeCents ?? null,
      inheritedBonus: this.state?.entryBonusPending === true };
    await this.options.gainJournal?.record(gain);
    await this.recordData("gain", { ...gain }, gain.id);
    if (this.options.sessionStatsStore) this.durableStats = await this.options.sessionStatsStore.record(gain);
    this.publishSessionStats(value.gainCents ?? undefined);
  }

  private publishSessionStats(gainCents?: number): void {
    if (gainCents !== undefined && Number.isSafeInteger(gainCents) && gainCents >= 0) {
      this.sessionBigWinCents = Math.max(this.sessionBigWinCents ?? 0, gainCents);
    }
    this.options.onSessionStats?.({
      bonusCount: this.durableStats?.bonusCount ?? this.sessionBonusCount,
      bigWinCents: this.durableStats ? this.durableStats.bigWinCents : this.sessionBigWinCents,
    });
  }
  private waitingForBonusEndLogged = false;
  private consecutiveErrors = 0;
  private chromeRecoveriesWithoutProgress = 0;
  private lastRoundProgressAt = 0;
  private lastBonusProgressKey: string | null = null;
  private lastBonusProgressAt = 0;
  private contextRecoveryKey: string | null = null;
  private contextClickAttempts = 0;
  private contextReopens = 0;

  public constructor(private readonly options: AutomodServiceOptions) {
    this.now = options.now ?? Date.now;
    this.sleep = options.sleep ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
    this.executorActionTimeoutMs = options.executorActionTimeoutMs ?? 15_000;
    this.executorOpenTimeoutMs = options.executorOpenTimeoutMs ?? 90_000;
    this.progressTimeoutMs = options.progressTimeoutMs ?? 60_000;
    this.activeBaseStakeCents = options.config.stakeCents;
  }

  private async executorAction<T>(label: string, action: () => Promise<T>, timeoutMs = this.executorActionTimeoutMs): Promise<T> {
    // Nolimit's bounded visual fallback and legacy CPU presentations can take
    // more than 15 s. Keep caller-specified budgets unchanged; only observation
    // and bonus advancement receive this measured provider-specific allowance.
    if (this.options.executorActionTimeoutMs === undefined && this.state?.active?.provider === "nolimit" &&
        (label === "observation provider" || label === "progression bonus")) timeoutMs = 45_000;
    let timer: NodeJS.Timeout | undefined;
    try {
      return await Promise.race([
        action(),
        new Promise<never>((_resolve, reject) => {
          timer = setTimeout(
            () => reject(new Error(`EXECUTOR_TIMEOUT: ${label} bloqué plus de ${timeoutMs} ms.`)),
            timeoutMs,
          );
        }),
      ]);
    } finally {
      if (timer !== undefined) clearTimeout(timer);
    }
  }

  private async restartBrowserAfterRepeatedErrors(): Promise<boolean> {
    if (this.consecutiveErrors < 2 || this.options.executor.restartSession === undefined) return false;
    this.consecutiveErrors = 0;
    try {
      await this.executorAction("redémarrage Chrome", () => this.options.executor.restartSession?.() ?? Promise.resolve(), 30_000);
      this.chromeRecoveriesWithoutProgress += 1;
      await this.options.onLog?.(`Deux erreurs consécutives: Chrome a été redémarré (${this.chromeRecoveriesWithoutProgress}/2) avant de poursuivre.`);
      if (this.chromeRecoveriesWithoutProgress >= 2) {
        throw new Error("SERVICE_RESTART_REQUIRED: deux cycles de récupération Chrome sans spin validé.");
      }
      return true;
    } catch (error) {
      if (error instanceof Error && error.message.includes("SERVICE_RESTART_REQUIRED")) throw error;
      this.chromeRecoveriesWithoutProgress += 1;
      const message = error instanceof Error ? error.message : String(error);
      await this.options.onLog?.(`Échec du redémarrage Chrome (${this.chromeRecoveriesWithoutProgress}/2): ${message}`);
      if (this.chromeRecoveriesWithoutProgress >= 2) {
        throw new Error(`SERVICE_RESTART_REQUIRED: deux redémarrages Chrome ont échoué: ${message}`);
      }
      return false;
    }
  }

  private async discardPersistedHacksawBonus(): Promise<void> {
    const item = this.state?.active;
    if (item?.provider !== "hacksaw" || this.state?.bonus === null || this.state?.bonus?.endedAt !== null) throw new Error("Aucun bonus Hacksaw persistant à refuser.");
    const discard = this.options.executor.discardCapturedHacksawBonus;
    if (discard === undefined) throw new Error("Le refus du bonus Hacksaw persistant exige une preuve idle et bonus inactif; exécuteur incompatible.");
    await this.executorAction("refus NON du bonus Hacksaw persistant", () => discard.call(this.options.executor, item, this.options.config), this.executorOpenTimeoutMs);
    const reason = "Bonus Hacksaw persistant refusé par NON après vérification idle et bonus inactif; gain final non mesuré.";
    await this.transition({ type: "bonus-abandoned", now: this.now(), reason });
    await this.options.onLog?.(reason);
  }

  public snapshot(): AutomodRuntimeState | null { return this.state === null ? null : structuredClone(this.state); }

  public requestStop(): void { this.stopping = true; }
  public requestSkip(): void { this.controlRequest = "skip"; }
  public requestRestart(): void { if (this.controlRequest !== "skip") this.controlRequest = "restart"; }
  public updateNextSlotConfig(config: AutomodConfig): void { this.pendingConfig = { ...config, enabled: true }; }

  private async transition(event: Parameters<typeof reduceAutomod>[1]): Promise<void> {
    if (this.state === null) throw new Error("Automod non initialisé.");
    const previous = this.state;
    if(event.type==='bonus-started'&&this.state.shopVisit?.purchaseConfirmed&&this.state.shopVisit.purchaseOrderId)event={...event,purchaseOrderId:this.state.shopVisit.purchaseOrderId};
    this.state = reduceAutomod(this.state, event);
    if (!["tick", "round-settled", "spin-intent"].includes(event.type)) {
      const context = this.state.active ? this.state : previous;
      await this.recordData(event.type, { phase: this.state.phase, roundsPlayed: this.state.roundsPlayed,
        deadlineAt: context.slotDeadlineAt, bonus: context.bonus,
        errorCode: event.type === "failure" ? event.message.match(/^[A-Z_]+(?=:)/)?.[0] ?? "UNKNOWN" : null },
        event.type.startsWith("bonus-") ? String(context.bonus?.startedAt ?? event.now) : String(event.now), context);
    }
    await this.options.stateStore.save(this.state);
    if (event.type === "bonus-started" || event.type === "slot-ready" && event.existingBonus) await this.countActiveBonus();
    await this.options.onState?.(structuredClone(this.state));
  }

  private async selectItem(): Promise<AutomodItem | null> {
    const allowed = new Set(this.options.config.allowedProviders);
    const call = await this.options.queue.nextSupportedCall(allowed, async (skipped, reason) => {
      await this.options.onLog?.(`Call ${skipped.id} (${skipped.slotName}) retiré: ${reason}.`);
    });
    if (call !== null) return call;
    if (!this.options.config.randomWhenQueueEmpty) return null;
    const random = await this.options.queue.randomSlot(allowed, [...new Set(this.recentRandomSlots)]);
    this.recentRandomSlots = [...this.recentRandomSlots, random.slotName].slice(-20);
    return random;
  }

  private remainingAutoplaySpins(): number {
    const limit = this.options.config.maxSpinsPerSlot;
    return limit === null ? 1_000 : Math.max(0, limit - (this.state?.roundsPlayed ?? 0));
  }

  private async startNextAutoplayBatch(options: { initial?: boolean } = {}): Promise<boolean> {
    if (this.options.executor.prepareBaseGame !== undefined &&
        !await this.executorAction("vérification jeu de base", () => this.options.executor.prepareBaseGame!(), 30_000)) {
      // La boucle d'observation poursuit le bonus/la transition ; aucune commande de mise.
      return true;
    }
    if (this.state?.entryBonusPending) {
      if (this.state.bonus?.endedAt == null) return true;
      await this.transition({ type: "entry-bonus-finished", now: this.now(), durationMs: this.currentConfig.slotDurationMs });
      this.lastRoundProgressAt = this.now();
      await this.options.onLog?.("Bonus trouvé à l’ouverture terminé et jeu de base confirmé : réglages validés, démarrage de la rotation normale.");
    }
    if(this.state&&this.options.shop){
      await this.options.shop.prepare(this.options.executor,this.state,this.currentConfig);
      await this.options.stateStore.save(this.state);
      if(this.options.shop.hasChosenPurchase()){
        const observation=await this.options.executor.observe();
        if(observation.bonusActive||observation.events.length)return true;
        const held=await this.options.shop.tick(this.options.executor,this.state,observation,()=>this.options.stateStore.save(this.state!),this.stopping||this.controlRequest!==null,
          ()=>this.transition({type:'bonus-started',now:this.now(),purchaseOrderId:this.state!.shopVisit!.purchaseOrderId}));
        if(held)return true;
      }
    }
    const remaining = this.remainingAutoplaySpins();
    if (remaining <= 0) return false;
    const deadline = this.state?.slotDeadlineAt ?? null;
    if (deadline !== null) {
      const timeLeft = deadline - (this.state?.recoveryPausedAt ?? this.now());
      if (options.initial !== true && timeLeft <= 15_000) {
        if (timeLeft > 0) {
          await this.options.onLog?.(
            `Fin de rotation dans ${timeLeft} ms: aucun nouveau lot autoplay lancé; attente idle jusqu’à l’échéance.`,
          );
          await this.sleep(timeLeft);
        }
        return false;
      }
    }
    if (this.options.executor.activeConfiguration && this.state) {
      const actual = await this.executorAction("lecture des mises pour les statistiques", () => this.options.executor.activeConfiguration!());
      this.state.verifiedBaseStakeCents = actual.baseStakeCents;
      this.state.verifiedChargedStakeCents = actual.chargedStakeCents;
      await this.options.stateStore.save(this.state);
      await this.recordData("stake-verified", actual, String(this.now()));
    }
    const batch = await this.executorAction("démarrage autoplay", () => this.options.executor.startAutoplay(remaining), 30_000);
    if (batch <= 0) {
      await this.options.onLog?.(`Autoplay natif: aucun lot compatible avec les ${remaining} spins restants.`);
      return false;
    }
    await this.options.onLog?.(`Autoplay natif lancé: ${batch} spins (${remaining} restants autorisés).`);
    return true;
  }

  public async run(): Promise<void> {
    this.durableStats = await this.options.sessionStatsStore?.snapshot() ?? null;
    this.publishSessionStats();
    this.stopping = false;
    this.state = await this.options.stateStore.load();
    if (this.state.active && !this.state.visitId) {
      this.state.visitId = `${this.state.active.key}:${this.state.slotStartedAt ?? this.state.updatedAt}`;
      await this.options.stateStore.save(this.state);
    }
    await this.recordData("session-config", { stakeCents: this.options.config.stakeCents,
      slotDurationMs: this.options.config.slotDurationMs, spinMode: this.options.config.spinMode,
      enhancedSpins: this.options.config.enhancedSpins }, String(this.now()));
    const persistedCallId = this.state.active?.callId;
    const hasUnfinishedBonus = this.state.bonus !== null && this.state.bonus.endedAt === null;
    let persistedCallPending: boolean | null = null;
    if (
      persistedCallId !== null &&
      persistedCallId !== undefined &&
      !hasUnfinishedBonus &&
      this.options.queue.isCallPending !== undefined
    ) {
      try {
        persistedCallPending = await this.options.queue.isCallPending(persistedCallId);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        await this.options.onLog?.(`Réconciliation de la file impossible; reprise prudente de ${this.state.active?.slotName ?? persistedCallId}: ${message}`);
      }
    }
    if (
      persistedCallId !== null &&
      persistedCallId !== undefined &&
      !hasUnfinishedBonus &&
      ((this.options.queue.isCallProcessed !== undefined && await this.options.queue.isCallProcessed(persistedCallId)) || persistedCallPending === false)
    ) {
      await this.options.onLog?.(
        persistedCallPending === false
          ? `Reprise ignorée: le call ${persistedCallId} (${this.state.active?.slotName ?? "machine inconnue"}) n'est plus dans la file LunaLive.`
          : `Reprise ignorée: le call ${persistedCallId} est déjà marqué traité.`,
      );
      await this.transition({ type: "discard-processed-item", now: this.now() });
    }
    if (this.state.phase === "disabled") await this.transition({ type: "enable", now: this.now() });
    else if (this.state.phase === "paused") await this.transition({ type: "resume", now: this.now() });
    else if (this.state.phase === "recovering") await this.transition({ type: "retry", now: this.now() });

    if (this.state.spinInFlight) {
      await this.transition({ type: "round-settled", now: this.now(), roundsPlayed: this.state.roundsPlayed });
      await this.options.onLog?.("Reprise après interruption : résultat du spin engagé inconnu, aucun round ni gain ajouté sans confirmation.");
    }

    let restorePending = (this.state.phase === "playing" || this.state.phase === "waiting-bonus-end") && this.state.active !== null;
    while (true) {
      let restoring = false;
      try {
        if (restorePending && this.state.active !== null) {
          restorePending = false;
          restoring = true;
          this.visitConfig=this.options.shop?await this.options.shop.config(this.state.active,this.options.config,this.state):this.options.config;
          await this.options.stateStore.save(this.state);
          this.executorRoundOffset = this.state.roundsPlayed;
          if (this.state.active.provider === "hacksaw" && this.state.bonus?.endedAt === null && !this.state.bonus.purchaseOrderId) {
            await this.discardPersistedHacksawBonus();
          } else if (this.state.bonus?.endedAt === null) {
            if (this.options.executor.openCapturedBonus === undefined) throw new Error("La reprise d’un bonus exige un exécuteur compatible.");
            await this.executorAction("reprise bonus", () => this.options.executor.openCapturedBonus!(this.state!.active!, this.currentConfig), this.executorOpenTimeoutMs);
          } else {
            const opened = await this.executorAction("ouverture slot reprise", () => this.options.executor.open(this.state!.active!, this.currentConfig), this.executorOpenTimeoutMs);
            if (opened?.existingBonus) {
              await this.transition({ type: "restart-item", now: this.now() });
              await this.transition({ type: "slot-ready", now: this.now(), durationMs: this.currentConfig.slotDurationMs, existingBonus: true });
            } else if (!(await this.startNextAutoplayBatch())) {
              await this.transition({ type: "finish-item", now: this.now() });
            }
          }
          this.lastRoundProgressAt = this.now();
          this.lastBonusProgressAt = this.now();
          await this.options.onLog?.(`Session reprise sur ${this.state.active.slotName} sans réinitialiser ses limites.`);
          restoring = false;
        }
        if (this.stopping && !["playing", "waiting-bonus-end"].includes(this.state.phase)) break;

        if (this.state.phase === "waiting") {
          const item = await this.selectItem();
          if (item === null) {
            await this.sleep(this.options.config.queuePollMs);
            continue;
          }
          await this.transition({ type: "item-selected", now: this.now(), item });
        }

        if (this.state.phase === "preparing") {
          if (this.state.active === null) throw new Error("Machine active absente en préparation.");
          if (this.pendingConfig !== null) {
            this.options.config = this.pendingConfig;
            this.pendingConfig = null;
            this.activeBaseStakeCents = this.options.config.stakeCents;
            await this.options.onLog?.("Nouveaux paramètres appliqués à la machine suivante.");
          }
          this.exitDrainStarted = false;
          this.exitDrainStartedAt = null;
          this.lastObservedPayoutCents = null;
          this.waitingForBonusEndLogged = false;
          this.lastBonusProgressKey = null;
          this.executorRoundOffset = this.state.roundsPlayed;
          this.visitConfig=this.options.shop?await this.options.shop.config(this.state.active,this.options.config,this.state):this.options.config;
          await this.options.stateStore.save(this.state);
          const opened = await this.executorAction("ouverture slot", () => this.options.executor.open(this.state!.active!, this.currentConfig), this.executorOpenTimeoutMs);
          await this.transition({ type: "slot-ready", now: this.now(), durationMs: this.currentConfig.slotDurationMs, existingBonus: opened?.existingBonus });
          if (opened?.existingBonus) await this.options.onLog?.("Bonus déjà présent à l’ouverture : attente de sa fin et lecture du gain avant réglage de mise ou autoplay.");
          this.lastRoundProgressAt = this.now();
          if (!opened?.existingBonus && !(await this.startNextAutoplayBatch({ initial: this.state.slotDeadlineAt === null }))) {
            await this.transition({ type: "finish-item", now: this.now() });
          }
        }

        if (this.state.phase === "playing" || this.state.phase === "waiting-bonus-end") {
          const observation = await this.executorAction("observation provider", () => this.options.executor.observe());
          if (observation.bonusActive && this.state.bonus?.endedAt === null) await this.countActiveBonus();
          if (!this.state.entryBonusPending && this.state.bonus?.endedAt !== null && Number.isSafeInteger(observation.baseStakeCents) && (observation.baseStakeCents ?? 0) > 0 && this.state.verifiedBaseStakeCents !== observation.baseStakeCents) {
            this.state.verifiedBaseStakeCents = observation.baseStakeCents;
            await this.options.stateStore.save(this.state);
          }
          if (observation.bonusActive || (this.state.bonus !== null && this.state.bonus.endedAt === null)) {
            if (this.lastBonusProgressKey === null || observation.bonusProgress !== undefined && observation.bonusProgress !== this.lastBonusProgressKey) {
              this.lastBonusProgressKey = observation.bonusProgress ?? "active";
              this.lastBonusProgressAt = this.now();
            } else if (this.now() - this.lastBonusProgressAt > 120_000 && !observation.events.some(event => event.type === "bonus-ended")) {
              this.lastBonusProgressAt = this.now();
              throw new Error("BONUS_STALLED: aucune progression confirmée du bonus depuis deux minutes ; reprise de la même machine.");
            }
          } else this.lastBonusProgressKey = null;
          // A win can arrive with the first bonus observation. Associate it with
          // that bonus, never with the last completed bonus retained in state.
          if ((observation.bonusActive || observation.events.some(event => event.type === "bonus-started")) && this.state.bonus?.endedAt !== null) {
            await this.transition({ type: "bonus-started", now: this.now() });
          }
          for (const win of observation.winPresentations ?? []) {
            if (win.gainCents !== null) this.publishSessionStats(win.gainCents);
            const active = this.state.active;
            if (active === null) throw new Error("Présentation de gain sans machine active.");
            await this.recordGain({ ...win, kind: "win-presentation", recordedAt: new Date(this.now()).toISOString(), slotName: active.slotName, provider: active.provider, bonusStartedAt: this.state.bonus?.endedAt === null ? this.state.bonus.startedAt : null });
            await this.options.onLog?.(`GROS GAIN ${active.slotName}: ${win.gainCents === null ? "montant non confirmé" : `${(win.gainCents / 100).toFixed(2)} €`} (${win.source}).`);
          }
          const absoluteRounds = this.executorRoundOffset + observation.roundsPlayed;
          if (this.state.recoveryPausedAt != null && !observation.bonusActive &&
              (observation.autoplayActive === true || absoluteRounds > this.state.roundsPlayed)) {
            await this.transition({ type: "recovery-resumed", now: this.now() });
            await this.options.onLog?.("Spins repris : chrono réactivé, durée de l’incident compensée une seule fois.");
          }
          if (absoluteRounds > this.state.roundsPlayed) {
            this.contextClickAttempts = 0;
            this.contextReopens = 0;
            if (this.state.slotDeadlineAt === null && !this.state.entryBonusPending && !this.state.shopVisit?.purchaseOrderId) {
              await this.transition({ type: "first-spin-settled", now: this.now(), durationMs: this.currentConfig.slotDurationMs });
              await this.options.shop?.applyBoosts(this.options.executor,this.state,this.currentConfig);
              await this.options.onLog?.("Premier spin terminé : démarrage du compte à rebours de changement de machine.");
            }
            this.consecutiveErrors = 0;
            this.chromeRecoveriesWithoutProgress = 0;
            this.lastRoundProgressAt = this.now();
            const previousRounds = this.state.roundsPlayed;
            const count = absoluteRounds - previousRounds;
            const payouts = observation.roundPayoutsCents ?? [];
            for (let index = 0; index < count; index += 1) {
              const payout = payouts[payouts.length - count + index] ?? null;
              if (index === count - 1) this.lastObservedPayoutCents = payout;
              if (payout !== null) this.publishSessionStats(payout);
              await this.recordData("round", { roundNumber: previousRounds + index + 1, gainCents: payout,
                gainKnown: payout !== null, baseStakeCents: this.state.verifiedBaseStakeCents ?? null,
                configuredChargeCents: this.state.verifiedChargedStakeCents ?? null,
                bonusStartedAt: this.state.bonus?.endedAt === null ? this.state.bonus.startedAt : null,
                countingSource: "provider-round-counter", observationBatchSize: count,
                // A configured charge is not independent evidence of a wallet debit.
                debitConfirmedCents: null }, String(previousRounds + index + 1));
              await this.options.onLog?.(
                `Spin #${previousRounds + index + 1}: gain ${payout === null ? "illisible" : `${(payout / 100).toFixed(2)} €`}.`,
              );
            }
            await this.transition({ type: "round-settled", now: this.now(), roundsPlayed: absoluteRounds });
          }
          if (Number.isSafeInteger(observation.baseStakeCents) && (observation.baseStakeCents ?? 0) > 0) {
            this.activeBaseStakeCents = observation.baseStakeCents as number;
          }
          let bonusEndedThisTick = false;
          for (const event of observation.events) {
            if (event.type === "bonus-started" && this.state.bonus?.endedAt !== null) {
              await this.transition({ type: "bonus-started", now: this.now() });
            } else if (event.type === "bonus-ended" && this.state.bonus !== null && this.state.bonus.endedAt === null) {
              this.publishSessionStats(event.gainCents);
              bonusEndedThisTick = true;
              await this.options.onLog?.(`GAIN FINAL BONUS: ${this.state.active?.slotName ?? "machine active"} = ${(event.gainCents / 100).toFixed(2)} €.`);
              const active = this.state.active;
              if (active !== null) await this.recordGain({
                id: `bonus:${active.key}:${this.state.bonus?.startedAt}`, kind: "bonus-total", recordedAt: new Date(this.now()).toISOString(),
                slotName: active.slotName, provider: active.provider, gainCents: event.gainCents,
                source: "provider-bonus-completion", bonusStartedAt: this.state.bonus?.startedAt ?? null,
              });
              // Persist the confirmed total before marking the bonus complete.
              // If the process stops here, replaying this identity is idempotent.
              await this.transition({ type: "bonus-ended", now: this.now(), gainCents: event.gainCents });
              const multiplier = event.gainCents / this.activeBaseStakeCents;
              if (
                active?.source === "lunalive" &&
                active.callId !== null &&
                active.requestedBy !== null &&
                multiplier >= this.options.config.bigWinThresholdMultiplier
              ) {
                await this.options.bigWinRecorder?.record({
                  id: `${active.callId}:${this.state.bonus?.startedAt ?? 0}`,
                  recordedAt: new Date(this.now()).toISOString(),
                  callId: active.callId,
                  username: active.requestedBy,
                  slotName: active.slotName,
                  provider: active.provider,
                  stakeCents: this.activeBaseStakeCents,
                  gainCents: event.gainCents,
                  multiplier: Math.round(multiplier * 100) / 100,
                });
              }
            }
          }
          if (bonusEndedThisTick) {
            // Free spins and their recap legitimately suspend paid-round
            // progress. Give the resumed batch its normal progress window.
            this.lastRoundProgressAt = this.now();
            await this.options.executor.advanceBonus();
            await this.sleep(750);
            await this.options.onLog?.("Gain du bonus conservé ; relecture de l’écran avant toute reprise ou sortie.");
            // L'observation courante décrit encore l'écran de récapitulatif.
            // Toujours relire le provider avant de relancer l'autoplay ou de swapper.
            continue;
          }
          if(this.options.shop&&await this.options.shop.tick(this.options.executor,this.state,observation,()=>this.options.stateStore.save(this.state!),this.stopping||this.controlRequest!==null,
            ()=>this.transition({type:'bonus-started',now:this.now(),purchaseOrderId:this.state!.shopVisit!.purchaseOrderId}))){
            this.lastRoundProgressAt=this.now();await this.sleep(250);continue;
          }
          const deadline = this.state.slotDeadlineAt;
          const spinLimit = this.options.config.maxSpinsPerSlot;
          const stopOnBonus = this.options.config.stopAfterFirstBonus && !this.state.entryBonusPending && this.state.bonus?.endedAt != null;
          const shouldFinish = stopOnBonus || (deadline !== null && this.state.recoveryPausedAt == null && this.now() >= deadline) || (spinLimit !== null && this.state.roundsPlayed >= spinLimit);
          const bonusActive = this.state.bonus !== null && this.state.bonus.endedAt === null;
          if (!bonusActive && !this.exitDrainStarted && !(shouldFinish && observation.idle) &&
              this.now() - this.lastRoundProgressAt > this.progressTimeoutMs) {
            throw new Error(`AUTOPLAY_STALLED: aucun spin réglé depuis ${this.progressTimeoutMs} ms.`);
          }
          if (bonusActive) {
            // A bonus discovered during stop must own the controls until its recap
            // is collected. Afterwards autoplay must be stopped again if resumed.
            this.exitDrainStarted = false;
            this.exitDrainStartedAt = null;
          }
          const autoplayActive = observation.autoplayActive === true;
          const controlNeedsStop = this.stopping || this.controlRequest !== null || shouldFinish;
          if (controlNeedsStop && !bonusActive && !this.exitDrainStarted) {
            if (autoplayActive) {
              try {
                await this.executorAction("arrêt autoplay", () => this.options.executor.stop());
              } catch (error) {
                if (!(error instanceof Error) || !error.message.startsWith("HACKSAW_AUTOPLAY_STOP_PENDING:")) throw error;
                this.exitDrainStartedAt ??= this.now();
                if (this.now() - this.exitDrainStartedAt > ROUND_DRAIN_TIMEOUT_MS) {
                  throw new Error("Arrêt autoplay Hacksaw sans règlement ni bonus après 60 secondes.");
                }
                await this.options.onLog?.("Arrêt autoplay en cours; relecture du round et du bonus sans recharger la slot.");
                await this.sleep(250);
                continue;
              }
            }
            this.exitDrainStarted = true;
            this.exitDrainStartedAt = this.now();
            await this.options.onLog?.("Autoplay coupé; attente du règlement du dernier spin (gain 0 ou X) avant changement de machine.");
          }
          if (
            this.exitDrainStartedAt !== null &&
            !observation.idle &&
            !bonusActive &&
            this.now() - this.exitDrainStartedAt > ROUND_DRAIN_TIMEOUT_MS
          ) {
            throw new Error("Dernier spin non réglé après 60 secondes; diagnostic et reprise de la même machine.");
          }
          if (shouldFinish && bonusActive && !this.waitingForBonusEndLogged) {
            this.waitingForBonusEndLogged = true;
            await this.options.onLog?.("Limite atteinte pendant un bonus: aucun swap avant la fin du bonus et la lecture de son gain.");
          }
          // Ne ferme jamais un jeu au milieu d'un round normal. Si ce round révèle
          // un bonus, le tick basculera vers waiting-bonus-end au lieu de quitter.
          if (!this.stopping && shouldFinish && (observation.idle || bonusActive)) {
            if (observation.idle && this.exitDrainStarted) {
              await this.options.onLog?.(
                `Dernier spin réglé: gain ${this.settledPayoutLabel()}; changement de machine autorisé.`,
              );
            }
            if (stopOnBonus && observation.idle && !bonusActive) await this.transition({ type: "finish-item", now: this.now() });
            else await this.transition({ type: "tick", now: Math.max(this.now(), deadline ?? this.now()) });
          }
          if (this.state.bonus !== null && this.state.bonus.endedAt === null) {
            await this.executorAction("progression bonus", () => this.options.executor.advanceBonus());
          } else if (this.stopping && observation.idle) {
            break;
          } else if (this.controlRequest === "skip" && observation.idle && this.state.phase === "playing") {
            this.controlRequest = null;
            await this.options.onLog?.(
              `Dernier spin réglé: gain ${this.settledPayoutLabel()}; skip autorisé.`,
            );
            await this.options.onLog?.(`Skip manuel: ${this.state.active?.slotName ?? "machine active"}.`);
            await this.transition({ type: "finish-item", now: this.now() });
          } else if (this.controlRequest === "restart" && observation.idle && this.state.phase === "playing") {
            this.controlRequest = null;
            await this.options.onLog?.(
              `Dernier spin réglé: gain ${this.settledPayoutLabel()}; relance autorisée.`,
            );
            await this.executorAction("fermeture slot", () => this.options.executor.close());
            if (this.options.executor.restartSession) {
              await this.executorAction("redémarrage Chrome demandé", () => this.options.executor.restartSession!(),30_000);
            }
            this.exitDrainStarted = false;
            this.exitDrainStartedAt = null;
            await this.transition({ type: "restart-item", now: this.now() });
            await this.options.onLog?.(`Relance manuelle: ${this.state.active?.slotName ?? "machine active"}, limites conservées.`);
          } else if (!this.stopping && this.state.phase === "playing" && observation.idle && !shouldFinish) {
            if (!(await this.startNextAutoplayBatch())) {
              await this.transition({ type: "finish-item", now: this.now() });
            }
          }
          await this.sleep(250);
        }

        if (this.state.phase === "completing") {
          await this.executorAction("arrêt autoplay", () => this.options.executor.stop());
          await this.options.shop?.finish(this.state);
          const callId = this.state.active?.callId;
          if (callId !== null && callId !== undefined) await this.options.queue.removeCall(callId);
          await this.transition({ type: "item-completed", now: this.now() });
        }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        await this.options.shop?.fault(this.state);
        await this.options.stateStore.save(this.state);
        if (this.state.active) await this.options.stateStore.recordIssue(this.state, message);
        // Shutdown failures are not slot failures: preserve the current call.
        if (this.stopping) break;
        if (/HACKSAW_WALLET_DISCONNECTED|something went wrong|AUTOPLAY_STALLED/i.test(message)) {
          await this.transition({ type: "recovery-paused", now: this.now() });
        }
        if (this.options.executor.recoverContext !== undefined && this.state.active !== null && !this.stopping) {
          if (this.contextRecoveryKey !== this.state.active.key) {
            this.contextRecoveryKey = this.state.active.key;
            this.contextClickAttempts = 0;
            this.contextReopens = 0;
          }
          await this.options.onLog?.(`Incident de contexte sur ${this.state.active.slotName} : ${message}. Réconciliation avant tout abandon.`);
          const diagnostic = await this.options.executor.captureDiagnostics?.(message).catch(() => null);
          if (diagnostic) await this.options.onLog?.(`Diagnostic avant récupération : ${diagnostic}`);
          let recovery: ContextRecoveryResult | null = null;
          if (this.contextClickAttempts < 1) {
            this.contextClickAttempts++;
            recovery = await this.executorAction("récupération contextuelle", () => this.options.executor.recoverContext!(), 20_000).catch(() => null);
          }
          if (recovery?.action === "blocked") {
            const reason = `AUTOMOD_BLOCKED_${recovery.context.reason ?? "EXTERNAL"}`;
            await this.transition({ type: "failure", now: this.now(), message: reason });
            throw new Error(`${reason}: intervention requise, aucun clic ni nouveau spin.`);
          }
          if (!restoring && recovery?.action === "resume" && (this.state.phase === "playing" || this.state.phase === "waiting-bonus-end")) {
            this.lastRoundProgressAt = this.now();
            this.lastBonusProgressAt = this.now();
            await this.options.onLog?.(`Contexte reconnu (${recovery.context.kind}) : reprise de ${this.state.active.slotName}, chrono et file conservés.`);
            continue;
          }
          const activeBonus = this.state.bonus !== null && this.state.bonus.endedAt === null;
          const expired = this.state.recoveryPausedAt == null && this.state.slotDeadlineAt !== null && this.now() >= this.state.slotDeadlineAt;
          if (this.contextReopens < 2 && !activeBonus && this.state.phase !== "completing" && !expired) {
            this.contextReopens++;
            await this.executorAction("réouverture de la même machine", () => this.options.executor.close()).catch(() => undefined);
            if (this.state.recoveryPausedAt == null && this.state.slotDeadlineAt !== null && this.now() >= this.state.slotDeadlineAt && this.state.phase === "playing") {
              if (this.state.spinInFlight) {
                await this.recordData("round-unconfirmed", { gainCents:null, reason:message },String(this.now()));
                await this.transition({ type:"round-settled", now:this.now(), roundsPlayed:this.state.roundsPlayed });
              }
              await this.transition({ type:"finish-item", now:this.now() });
              continue;
            }
            if (this.contextReopens === 2 && this.options.executor.restartSession) {
              await this.executorAction("redémarrage navigateur pour réconciliation", () => this.options.executor.restartSession!(), 30_000);
            }
            await this.transition({ type: "context-reopen", now: this.now() });
            await this.options.onLog?.(`Réouverture ${this.contextReopens}/2 de la machine prévue, sans consommer le call ni réinitialiser le chrono.`);
            continue;
          }
          if (this.contextReopens < 2 && activeBonus && this.state.active.provider !== "hacksaw" && this.options.executor.openCapturedBonus) {
            this.executorRoundOffset = this.state.roundsPlayed;
            let reopened = false;
            while (this.contextReopens < 2 && !this.stopping) {
              this.contextReopens++;
              try {
                await this.executorAction("réouverture du bonus à terminer", () => this.options.executor.openCapturedBonus!(this.state!.active!, this.currentConfig), this.executorOpenTimeoutMs);
                reopened = true;
                break;
              } catch (reopenError) {
                await this.options.onLog?.(`Réouverture du bonus ${this.contextReopens}/2 non aboutie : ${String(reopenError)}.`);
              }
            }
            if (reopened) {
              this.lastBonusProgressAt = this.now();
              await this.options.onLog?.("Bonus repris sur la même machine ; gain final toujours attendu et chrono conservé.");
              continue;
            }
          }
          if (["preparing", "playing", "waiting-bonus-end", "completing"].includes(this.state.phase)) {
            const failedItem = this.state.active;
            await this.executorAction("fermeture machine en échec", () => this.options.executor.close());
            if (this.state.spinInFlight && (this.state.phase === "playing" || this.state.phase === "waiting-bonus-end")) {
              await this.recordData("round-unconfirmed", { gainCents: null, reason: message }, String(this.now()));
              await this.transition({ type: "round-settled", now: this.now(), roundsPlayed: this.state.roundsPlayed });
            }
            if (failedItem.callId !== null) await this.options.queue.removeCall(failedItem.callId);
            this.recentRandomSlots = [...this.recentRandomSlots, failedItem.slotName].slice(-20);
            if (activeBonus) {
              await this.recordData("bonus-abandoned", { reason: message, gainCents: null }, String(this.now()));
              await this.transition({ type: "bonus-abandoned", now: this.now(), reason: message });
              await this.transition({ type: "item-completed", now: this.now() });
            } else if (this.state.phase === "completing") {
              await this.transition({ type: "item-completed", now: this.now() });
            } else {
              await this.transition({ type: "skip-failed-item", now: this.now(), message });
            }
            await this.options.onLog?.(`Machine en échec journalisée puis retirée: ${failedItem.slotName}; passage au call suivant ou aléatoire.`);
            continue;
          }
          const reason = activeBonus ? "AUTOMOD_BLOCKED_BONUS_UNRESOLVED" : "AUTOMOD_BLOCKED_CONTEXT_UNRESOLVED";
          await this.transition({ type: "failure", now: this.now(), message: `${reason}: ${message}` });
          throw new Error(`${reason}: récupération bornée épuisée, état et file conservés.`);
        }
        if (restoring) throw error; // Legacy executors cannot reconcile an interrupted initialization.
        if (
          message.startsWith("HACKSAW_BONUS_START_STALLED:") &&
          this.state.active !== null &&
          this.state.bonus !== null && this.state.bonus.endedAt === null &&
          !this.state.spinInFlight &&
          (this.state.phase === "playing" || this.state.phase === "waiting-bonus-end")
        ) {
          const failedItem = this.state.active;
          await this.options.onLog?.(`Bonus Hacksaw non démarré sur ${failedItem.slotName} après un clic central et 5 s de vérification; abandon explicite du bonus, gain final non mesuré, passage à la slot suivante.`);
          await this.transition({ type: "bonus-abandoned", now: this.now() });
          await this.executorAction("fermeture slot Hacksaw bloquée", () => this.options.executor.close()).catch(() => undefined);
          if (failedItem.callId !== null) {
            await this.options.queue.removeCall(failedItem.callId).catch(async (removeError) => {
              const removeMessage = removeError instanceof Error ? removeError.message : String(removeError);
              await this.options.onLog?.(`Impossible d'acquitter le call ${failedItem.callId} après abandon du bonus: ${removeMessage}`);
            });
          } else {
            this.recentRandomSlots = [...this.recentRandomSlots, failedItem.slotName].slice(-20);
          }
          await this.transition({ type: "item-completed", now: this.now() });
          continue;
        }
        const inaccessibleRandomSlot =
          (this.state.phase === "preparing" || this.state.phase === "playing") &&
          this.state.active?.source === "random" && this.state.roundsPlayed === 0 && !this.state.spinInFlight &&
          /RANDOM_SLOT_INACCESSIBLE|device and\/or browser is not compatible|not available in your country|n’est pas disponible dans votre pays|Carte normale .* au slug exact non unique \(0\)|Autoplay (?:Pragmatic|Hacksaw|Nolimit) non confirmé après démarrage/i.test(message);
        if (inaccessibleRandomSlot && this.state.active !== null) {
          const slotName = this.state.active.slotName;
          this.recentRandomSlots = [...this.recentRandomSlots, slotName].slice(-20);
          await this.executorAction("fermeture slot", () => this.options.executor.close()).catch(() => undefined);
          await this.transition({ type: "skip-random-item", now: this.now() });
          await this.options.onLog?.(
            `Slot aléatoire indisponible écartée sans pénaliser la récupération: ${slotName}; sélection immédiate de la suivante.`,
          );
          continue;
        }
        this.consecutiveErrors += 1;
        await this.options.onLog?.(`Erreur Automod: ${message}`);
        const diagnostic = await this.executorAction(
          "capture diagnostic",
          () => this.options.executor.captureDiagnostics?.(message) ?? Promise.resolve(null),
        ).catch(() => null);
        if (diagnostic) await this.options.onLog?.(`Diagnostic enregistré: ${diagnostic}`);
        if (this.state.spinInFlight && (this.state.phase === "playing" || this.state.phase === "waiting-bonus-end")) {
          await this.recordData("round-unconfirmed", { roundNumber: this.state.roundsPlayed + 1,
            gainCents: null, debitConfirmedCents: null, reason: "recovery-after-error" }, String(this.state.roundsPlayed + 1));
          await this.transition({ type: "round-settled", now: this.now(), roundsPlayed: this.state.roundsPlayed + 1 });
          await this.options.onLog?.("Spin en statut incertain compté par sécurité après erreur.");
        }
        const failedItem = this.state.active;
        const canSkipFailedItem =
          !message.startsWith("HACKSAW_WALLET_DISCONNECTED:") &&
          !message.startsWith("PRAGMATIC_OVERLAY_UNRESOLVED:") &&
          failedItem !== null &&
          (this.state.phase === "preparing" || this.state.phase === "playing") &&
          !this.state.spinInFlight &&
          !(this.state.bonus !== null && this.state.bonus.endedAt === null);
        if (canSkipFailedItem) {
          await this.executorAction("fermeture slot", () => this.options.executor.close()).catch(() => undefined);
          if (failedItem.callId !== null) {
            await this.options.queue.removeCall(failedItem.callId).catch(async (removeError) => {
              const removeMessage = removeError instanceof Error ? removeError.message : String(removeError);
              await this.options.onLog?.(`Impossible d'acquitter le call ${failedItem.callId} après erreur: ${removeMessage}`);
            });
          } else {
            this.recentRandomSlots = [...this.recentRandomSlots, failedItem.slotName].slice(-20);
          }
          await this.transition({ type: "skip-failed-item", now: this.now(), message });
          await this.options.onLog?.(`Machine écartée après erreur: ${failedItem.slotName}; passage à la suivante.`);
          await this.restartBrowserAfterRepeatedErrors();
          continue;
        }
        const bonusStillActive = this.state.bonus !== null && this.state.bonus.endedAt === null;
        if (this.state.phase !== "disabled") await this.transition({ type: "failure", now: this.now(), message });
        if (!bonusStillActive) {
          await this.executorAction("fermeture slot", () => this.options.executor.close()).catch(() => undefined);
        } else {
          await this.options.onLog?.("Erreur pendant un bonus: la page reste ouverte pour préserver et reprendre le bonus.");
        }
        const browserRestarted = await this.restartBrowserAfterRepeatedErrors();
        await this.sleep(2_000);
        if (!this.stopping && this.state.phase === "recovering") {
          await this.transition({ type: "retry", now: this.now() });
          if (browserRestarted && this.state.active?.provider === "hacksaw" && this.state.bonus !== null && this.state.bonus.endedAt === null) await this.discardPersistedHacksawBonus();
          else if (browserRestarted && this.state.active !== null && this.state.bonus !== null && this.state.bonus.endedAt === null) {
            if (this.options.executor.openCapturedBonus === undefined) throw new Error("Reprise du bonus après redémarrage indisponible.");
            await this.executorAction("réouverture du bonus après redémarrage", () => this.options.executor.openCapturedBonus!(this.state!.active!, this.currentConfig), this.executorOpenTimeoutMs);
          }
        }
      }
    }
    await this.executorAction("arrêt final", () => this.options.executor.stop()).catch(() => undefined);
    if (this.options.keepSlotOpenOnStop !== true) {
      await this.executorAction("fermeture finale", () => this.options.executor.close()).catch(() => undefined);
    }
    if (this.state.phase !== "disabled") await this.transition({ type: "disable", now: this.now() });
  }
}


