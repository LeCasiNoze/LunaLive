import type { AutomodItem } from "./automod-domain.js";
import { LunaLiveClient, normalizeAutomodProvider, type LunaLiveCall } from "./lunalive-client.js";
import type { ProviderKey } from "./provider-capabilities.js";
import { BonusHuntStore } from "./bonus-hunt-store.js";
import { randomUUID } from "node:crypto";
import { mkdir, readFile, writeFile, rename, unlink } from "node:fs/promises";
import path from "node:path";

export interface ResolvedCall extends LunaLiveCall {
  resolvedProvider: ProviderKey | null;
  supported: boolean;
  unsupportedReason: string | null;
}

export interface CallsSnapshot {
  calls: ResolvedCall[];
  count: number;
  limited: boolean;
  queueWritable: boolean;
  phase: string | null;
}

export class AutomodQueueGateway {
  private writable: boolean;
  private readonly allowed = new Set<ProviderKey>(["pragmatic", "hacksaw", "nolimit"]);

  public constructor(
    private readonly client: LunaLiveClient,
    private readonly store: BonusHuntStore,
    _token: string | undefined,
    private readonly runtimeRoot?: string,
  ) {
    this.writable = false;
  }

  public get queueWritable(): boolean { return this.writable; }

  public setToken(token: string | undefined): void {
    this.client.setToken(token);
    this.writable = false;
  }

  public setServiceCredential(value: { serviceId: string; secret: string } | undefined): void {
    this.client.setServiceCredential(value);
    this.writable = false;
  }

  public async isCallProcessed(callId: string): Promise<boolean> {
    return this.store.isProcessed(callId);
  }

  public async isCallPending(callId: string): Promise<boolean> {
    const calls = await this.client.listCalls().catch(async () => (await this.client.publicQueue()).calls);
    return calls.some((call) => call.id === callId);
  }

  public async listResolved(): Promise<CallsSnapshot> {
    let calls: LunaLiveCall[];
    let limited = false;
    let count: number;
    let phase: string | null = null;
    try {
      calls = await this.client.listCalls();
      count = calls.length;
      this.writable = true;
    } catch (error) {
      const publicQueue = await this.client.publicQueue().catch(() => { throw error; });
      calls = publicQueue.calls;
      count = publicQueue.count;
      phase = publicQueue.phase;
      limited = true;
      this.writable = false;
    }
    const resolved = await Promise.all(calls.map(async (call): Promise<ResolvedCall> => {
      const provider = normalizeAutomodProvider(call.provider) ?? await this.client.resolveProvider(call.slotName).catch(() => null);
      const supported = provider !== null && this.allowed.has(provider);
      return {
        ...call,
        resolvedProvider: provider,
        supported,
        unsupportedReason: supported ? null : provider === null ? "Provider inconnu" : `${provider} non pris en charge`,
      };
    }));
    return { calls: resolved, count, limited, queueWritable: this.queueWritable, phase };
  }

  public async nextSupportedCall(
    allowedProviders: ReadonlySet<ProviderKey>,
    onSkipped?: (call: LunaLiveCall, reason: string) => void | Promise<void>,
  ): Promise<AutomodItem | null> {
    const snapshot = await this.listResolved();
    for (const call of snapshot.calls) {
      if (await this.store.isProcessed(call.id)) {
        if (this.queueWritable) await this.client.removeCall(call.id);
        continue;
      }
      const provider = call.resolvedProvider;
      if (provider === null || !this.allowed.has(provider) || !allowedProviders.has(provider)) {
        await this.completeCall(call.id);
        await onSkipped?.(call, provider === null ? "provider-inconnu" : `provider-interdit:${provider}`);
        continue;
      }
      return {
        key: `call:${call.id}`,
        callId: call.id,
        source: "lunalive",
        slotName: call.slotName,
        provider,
        requestedBy: call.username || null,
        ...(call.rumbleUserId ? { requestedByRumbleId: call.rumbleUserId } : {}),
        ...(call.userId === 0 && call.username === "Automod" ? { automodGenerated: true } : {}),
        ...(call.userId ? { requestedById: call.userId } : {}),
        ...(call.imageUrl ? { imageUrl: call.imageUrl } : {}),
      };
    }
    return null;
  }

  public async completeCall(callId: string): Promise<boolean> {
    await this.store.markProcessed(callId);
    if (this.queueWritable) {
      const removed = await this.client.removeCall(callId);
      return removed;
    }
    return false;
  }

  public async removeCall(callId: string): Promise<boolean> {
    return this.completeCall(callId);
  }

  public async syncSessionStats(stats: unknown): Promise<number | undefined> {
    return await this.client.syncSessionStats(stats);
  }

  public async shopRequest<T>(method: "GET" | "POST", path: string, body?: unknown): Promise<T> {
    return this.client.shopRequest<T>(method, path, body);
  }

  public async callsSettings(): Promise<Record<string, unknown>> {
    return this.client.callsSettings();
  }

  public async randomSlot(allowedProviders: ReadonlySet<ProviderKey>, excludeNames: readonly string[] = []): Promise<AutomodItem> {
    if (!this.runtimeRoot) throw Error("Stockage de la demande de call aléatoire absent.");
    const allowed = new Set([...allowedProviders].filter(provider => this.allowed.has(provider)));
    const file = path.join(this.runtimeRoot, "automod-pending-random-call.json");
    for (let attempt = 0; attempt < 3; attempt++) {
      let pending: { requestId: string; item: AutomodItem } | null = null;
      try { pending = JSON.parse(await readFile(file, "utf8")); }
      catch (error) { if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error; }
      if (!pending) {
        pending = { requestId: randomUUID(), item: await this.client.randomSlot(allowed, excludeNames) };
        await mkdir(this.runtimeRoot, { recursive: true });
        await writeFile(file + ".tmp", JSON.stringify(pending), { mode: 0o600, flush: true });
        await rename(file + ".tmp", file);
      }
      if (!/^[a-zA-Z0-9-]{16,80}$/.test(pending.requestId) || !pending.item?.slotName) throw Error("Demande de call aléatoire persistée invalide.");
      // Persist before POST. A timeout leaves the same identity for the next
      // attempt; the server remembers it even after the call was removed.
      await this.client.enqueueAutomodCall(pending.item, pending.requestId);
      await unlink(file);
      // Read the real queue again: a viewer/moderator may have acted during the
      // round trip. Never start the unqueued candidate or assume it is first.
      const head = await this.nextSupportedCall(allowed);
      if (head) return head;
    }
    throw Error("Aucun call jouable confirmé après insertion/réconciliation Automod.");
  }
}
